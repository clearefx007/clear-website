// Rotate Selected Layer 90° Clockwise
{
    app.beginUndoGroup("Rotate 90 Clockwise");

    var comp = app.project.activeItem;

    if (comp && comp instanceof CompItem) {
        var sel = comp.selectedLayers;

        if (sel.length > 0) {
            for (var i = 0; i < sel.length; i++) {
                var layer = sel[i];
                // Get current rotation and add 90°
                if (layer.property("Rotation") !== null) {
                    layer.property("Rotation").setValue(layer.property("Rotation").value + 90);
                } else if (layer.property("Transform").property("Rotation") !== null) {
                    layer.property("Transform").property("Rotation").setValue(layer.property("Transform").property("Rotation").value + 90);
                }
            }
        } else {
            alert("Please select at least one layer.");
        }
    } else {
        alert("Please open a composition and select a layer.");
    }

    app.endUndoGroup();
}
