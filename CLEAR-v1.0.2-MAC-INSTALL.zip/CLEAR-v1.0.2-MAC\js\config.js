(function () {
    "use strict";

    window.CLEAR_CONFIG = {
        name: "CLEAR",
        version: "1.0.2",
        accent: "#A855F7",
        inactivityMinutes: 5,
        links: {
            feedback: "https://t.me/clearfx007"
        },
        sections: [
            {
                id: "layers",
                title: "Layer Tools",
                icon: "icons/precompose.svg",
                tools: [
                    { id: "precompose", name: "Precompose", icon: "icons/precompose.svg" },
                    { id: "precomposeIndividual", name: "Precompose Individual", icon: "icons/precompose individual.svg" },
                    { id: "decompose", name: "Decompose", icon: "icons/de precompose.svg" },
                    { id: "addAdjustment", name: "Add Adjustment Layer", icon: "icons/add adjustment.svg" },
                    { id: "addNull", name: "Null", icon: "icons/null.svg" },
                    { id: "fitLayer", name: "Fit Layer Into Comp", icon: "icons/fit layer into comp.svg" },
                    { id: "topToBottom", name: "Top To Bottom", icon: "icons/top to bottom.svg" },
                    { id: "linkToParent", name: "Link To Parent", icon: "icons/link.svg" },
                    { id: "rotateCW", name: "Rotate CW", icon: "icons/rotate cw.svg" }
                ]
            },
            {
                id: "effects",
                title: "Effects",
                icon: "icons/fast color.svg",
                searchable: true,
                tools: [
                    { id: "pasteEffects", name: "Paste Effects", icon: "icons/paste effects.svg" },
                    { id: "deleteAllEffects", name: "Delete All Effects", icon: "icons/delete all effects.svg" },
                    { id: "deleteParticularEffect", name: "Delete Particular Effect", icon: "icons/delete perticular effect.svg", panelAction: true },
                    { id: "colorAudio", name: "Color Audio", icon: "icons/color audio.svg" },
                    { id: "fadeInOut", name: "Fade In Out", icon: "icons/fade in out.svg" }
                ]
            },
            {
                id: "text",
                title: "Text Tools",
                icon: "icons/case-sensitive.svg",
                tools: [
                    { id: "sentenceCase", name: "Sentence Case", icon: "icons/case-sensitive.svg" },
                    { id: "lowerCase", name: "Lower Case", icon: "icons/lower case.svg" },
                    { id: "upperCase", name: "Upper Case", icon: "icons/upper case.svg" },
                    { id: "splitText", name: "Split Text", icon: "icons/split text.svg" }
                ]
            },
            {
                id: "shape",
                title: "Shape & Design",
                icon: "icons/round corner.svg",
                tools: [
                    { id: "roundCorner", name: "Round Corner", icon: "icons/round corner.svg" }
                ]
            },
            {
                id: "composition",
                title: "Composition",
                icon: "icons/camera.svg",
                tools: [
                    { id: "camera", name: "Camera", icon: "icons/camera.svg" },
                    { id: "toggle3D", name: "3D", icon: "icons/3d.svg" },
                    { id: "pngRender", name: "PNG Render", icon: "icons/png render.svg" }
                ]
            }
        ]
    };
}());
