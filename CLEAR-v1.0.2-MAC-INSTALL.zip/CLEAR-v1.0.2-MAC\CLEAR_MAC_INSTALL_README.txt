CLEAR for Mac
Version: 1.0.2

Compatibility:
Adobe After Effects 2020 through 2026 on macOS.

This Mac package includes the CLEAR CEP panel, SVG icons, JSX tools, Quick Colors, timers, settings, and support/update buttons.

Not included in this Mac build:
- Fast Color Picker
- Floating Quick Search
- Global J/K Marker Navigation

These three features use Windows native helper EXE files in the Windows build, so they are disabled in this Mac package.


HOW TO INSTALL ON MAC

1. Close Adobe After Effects.

2. Unzip:

   CLEAR-v1.0.2-MAC-INSTALL.zip

3. Copy the folder:

   CLEAR-v1.0.2-MAC

4. Paste it here:

   ~/Library/Application Support/Adobe/CEP/extensions/

5. Rename the copied folder to:

   CLEAR

Final path should be:

   ~/Library/Application Support/Adobe/CEP/extensions/CLEAR


ENABLE UNSIGNED CEP PANEL

Open Terminal and run:

defaults write com.adobe.CSXS.9 PlayerDebugMode 1
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
defaults write com.adobe.CSXS.13 PlayerDebugMode 1
defaults write com.adobe.CSXS.14 PlayerDebugMode 1
defaults write com.adobe.CSXS.15 PlayerDebugMode 1
defaults write com.adobe.CSXS.16 PlayerDebugMode 1
defaults write com.adobe.CSXS.17 PlayerDebugMode 1
defaults write com.adobe.CSXS.18 PlayerDebugMode 1
defaults write com.adobe.CSXS.19 PlayerDebugMode 1
defaults write com.adobe.CSXS.20 PlayerDebugMode 1


OPEN IN AFTER EFFECTS

1. Restart After Effects.
2. Go to:

   Window > Extensions > CLEAR

3. Dock the panel where you want.


MAC BUILD FEATURES

Layer Tools:
- Precompose
- Precompose Individual
- Decompose
- Add Adjustment Layer
- Add Null
- Fit Layer Into Comp
- Top To Bottom
- Link To Parent
- Rotate CW

Effects:
- Paste Effects
- Delete All Effects
- Delete Particular Effect
- Color Audio
- Fade In Out

Text Tools:
- Sentence Case
- Lower Case
- Upper Case
- Split Text

Shape & Design:
- Round Corner
- Anchor Point Grid
- Align Toolbar
- Dual Center Align
- Quick Colors

Composition:
- Camera
- 3D Toggle
- PNG Render

Workflow:
- Project Session Timer
- Total Project Time Tracking
- Accent Color Setting
- Category View ON/OFF
- Remove and Restore Tools
- Feedback links
- Support page
- Update button


SUPPORT

Telegram:
@clearfx007

Instagram:
https://www.instagram.com/clear7.fx/

Discord:
https://discord.gg/WDeZWH8Ees
