/* CLEAR - After Effects CEP host bridge */
if (typeof CLEAR === "undefined") {
    CLEAR = {};
}

(function (api) {
    api.version = "1.0.2";
    if (typeof api._threeDMode === "undefined") {
        api._threeDMode = false;
    }
    api._known3DLayers = api._known3DLayers || {};
    api._threeDTaskId = api._threeDTaskId || 0;
    api._threeDProjectReference = api._threeDProjectReference || null;
    if (typeof api._parentLinkMode === "undefined") {
        api._parentLinkMode = false;
    }
    if (typeof api._parentLinkColorGrouping === "undefined") {
        api._parentLinkColorGrouping = true;
    }
    if (typeof api._parentLinkOrganize === "undefined") {
        api._parentLinkOrganize = true;
    }
    api._parentLinkChildLabels = api._parentLinkChildLabels || {};
    api._parentLinkKnownPairs = api._parentLinkKnownPairs || {};
    api._parentLinkGroupLabels = api._parentLinkGroupLabels || {};
    api._parentLinkUsedLabels = api._parentLinkUsedLabels || {};
    api._parentLinkTaskId = api._parentLinkTaskId || 0;
    api._markerNavigationCache = api._markerNavigationCache || { comp: null, updatedAt: 0, times: [] };
    api.enforce3DMode = function () { return enforce3DMode(); };
    api.enforceParentLinkMode = function () { return enforceParentLinkMode(); };
    api.navigateMarkerFast = function (direction) { return navigateMarker(direction); };
    api._projectSerial = api._projectSerial || 0;
    api._projectReference = api._projectReference || null;
    if (typeof api._effectControlsOpenedByClear === "undefined") {
        api._effectControlsOpenedByClear = false;
    }

    api.invoke = function (method, argsJSON) {
        var args;
        var value;
        try {
            args = parseJSON(argsJSON || "[]");
            if (!api._methods[method]) {
                return stringify({ ok: false, error: "Unknown method" });
            }
            value = api._methods[method].apply(api, args);
            return stringify({ ok: true, value: value });
        } catch (error) {
            return stringify({ ok: false, error: error && error.toString ? error.toString() : "Command failed" });
        }
    };

    api._methods = {
        runCommand: runCommand,
        getEffects: getEffects,
        applyEffect: applyEffect,
        getSelectedEffects: getSelectedEffects,
        deleteEffects: deleteEffects,
        getProjectState: getProjectState,
        getProjectTime: getProjectTime,
        setProjectTime: setProjectTime,
        navigateMarker: navigateMarker,
        get3DModeState: get3DModeState,
        getParentLinkState: getParentLinkState,
        getSelectionState: getSelectionState,
        getFastColorContext: getFastColorContext,
        applyQuickColor: applyQuickColor,
        pickQuickColor: pickQuickColor
    };

    function runCommand(command, options) {
        var commands = {
            precompose: precompose,
            precomposeIndividual: precomposeIndividual,
            decompose: decompose,
            addAdjustment: addAdjustment,
            addNull: addNull,
            fitLayer: fitLayer,
            topToBottom: topToBottom,
            linkToParent: linkToParent,
            anchorPointGrid: anchorPointGrid,
            alignLayers: alignLayers,
            rotateCW: rotateCW,
            pasteEffects: pasteEffects,
            deleteAllEffects: deleteAllEffects,
            fastColor: fastColor,
            colorAudio: colorAudio,
            fadeInOut: fadeInOut,
            sentenceCase: sentenceCase,
            lowerCase: lowerCase,
            upperCase: upperCase,
            splitText: splitText,
            squarePen: squarePen,
            roundCorner: roundCorner,
            camera: addCamera,
            toggle3D: toggle3D,
            pngRender: pngRender
        };
        if (!commands[command]) {
            return false;
        }
        return commands[command](options || {});
    }

    function activeComp() {
        var item = app.project ? app.project.activeItem : null;
        return item && item instanceof CompItem ? item : null;
    }

    function selectedLayers(comp) {
        var result = [];
        var selected = comp ? comp.selectedLayers : [];
        var i;
        for (i = 0; i < selected.length; i += 1) {
            result.push(selected[i]);
        }
        return result;
    }

    function getSelectionState() {
        var comp = activeComp();
        var count = 0;
        try {
            count = comp ? comp.selectedLayers.length : 0;
        } catch (ignoreSelectionState) {}
        return { selectedLayers: count };
    }

    function anchorPointGrid(options) {
        var comp = activeComp();
        var layers;
        var target = options && options.position ? String(options.position) : "";
        var i;
        if (!comp) {
            alert("Please open a composition first.");
            return false;
        }
        layers = selectedLayers(comp);
        if (!layers.length) {
            alert("Please select one or more layers.");
            return false;
        }
        app.beginUndoGroup("CLEAR Anchor Point Grid");
        try {
            for (i = 0; i < layers.length; i += 1) {
                moveLayerAnchorToGrid(layers[i], comp.time, target);
            }
        } catch (ignoreAnchorGrid) {
        } finally {
            app.endUndoGroup();
        }
        return true;
    }

    function moveLayerAnchorToGrid(layer, time, target) {
        var rect = layerSourceRect(layer, time);
        var transform;
        var anchor;
        var oldAnchor;
        var newAnchor;
        var oldCompPoint;
        var newCompPoint;
        var xFactor;
        var yFactor;
        var diff;
        if (!rect || rect.width <= 0 || rect.height <= 0) {
            return false;
        }
        if (target.indexOf("left") >= 0) {
            xFactor = 0;
        } else if (target.indexOf("right") >= 0) {
            xFactor = 1;
        } else {
            xFactor = 0.5;
        }
        if (target.indexOf("top") >= 0) {
            yFactor = 0;
        } else if (target.indexOf("bottom") >= 0) {
            yFactor = 1;
        } else {
            yFactor = 0.5;
        }
        try {
            transform = layer.property("ADBE Transform Group");
            anchor = transform.property("ADBE Anchor Point");
            if (!anchor) {
                return false;
            }
            oldAnchor = anchor.value;
            newAnchor = [
                rect.left + rect.width * xFactor,
                rect.top + rect.height * yFactor
            ];
            if (oldAnchor.length === 3) {
                newAnchor.push(oldAnchor[2]);
            }
            oldCompPoint = sourcePointToCompSafe(layer, oldAnchor);
            newCompPoint = sourcePointToCompSafe(layer, newAnchor);
            if (!oldCompPoint || !newCompPoint) {
                return false;
            }
            diff = [
                newCompPoint[0] - oldCompPoint[0],
                newCompPoint[1] - oldCompPoint[1]
            ];
            anchor.setValue(newAnchor);
            shiftLayerPosition(layer, diff);
            return true;
        } catch (ignoreAnchorLayer) {}
        return false;
    }

    function alignLayers(options) {
        var comp = activeComp();
        var action = options && options.action ? String(options.action) : "";
        var layers = selectedLayers(comp);
        var bounds;
        var layerBounds;
        var delta;
        var i;
        if (!comp || !layers.length || !action) {
            return false;
        }
        app.beginUndoGroup("CLEAR Align");
        try {
            for (i = 0; i < layers.length; i += 1) {
                bounds = layerCompBounds(layers[i], comp.time);
                if (!bounds) {
                    continue;
                }
                layerBounds = bounds;
                delta = [0, 0];
                if (action === "left") {
                    delta[0] = -layerBounds.left;
                } else if (action === "hcenter") {
                    delta[0] = (comp.width / 2) - ((layerBounds.left + layerBounds.right) / 2);
                } else if (action === "right") {
                    delta[0] = comp.width - layerBounds.right;
                } else if (action === "top") {
                    delta[1] = -layerBounds.top;
                } else if (action === "center") {
                    delta[0] = (comp.width / 2) - ((layerBounds.left + layerBounds.right) / 2);
                    delta[1] = (comp.height / 2) - ((layerBounds.top + layerBounds.bottom) / 2);
                } else if (action === "vcenter") {
                    delta[1] = (comp.height / 2) - ((layerBounds.top + layerBounds.bottom) / 2);
                } else if (action === "bottom") {
                    delta[1] = comp.height - layerBounds.bottom;
                }
                if (delta[0] || delta[1]) {
                    shiftLayerPosition(layers[i], delta);
                }
            }
        } catch (ignoreAlign) {
        } finally {
            app.endUndoGroup();
        }
        return true;
    }

    function layerCompBounds(layer, time) {
        var rect = layerSourceRect(layer, time);
        var points;
        var point;
        var left;
        var right;
        var top;
        var bottom;
        var i;
        if (!rect || rect.width <= 0 || rect.height <= 0) {
            return null;
        }
        points = layerMaskSourcePoints(layer);
        if (!points || !points.length) {
            points = [
            [rect.left, rect.top],
            [rect.left + rect.width, rect.top],
            [rect.left + rect.width, rect.top + rect.height],
            [rect.left, rect.top + rect.height]
            ];
        }
        for (i = 0; i < points.length; i += 1) {
            point = sourcePointToCompSafe(layer, points[i]);
            if (!point) {
                return null;
            }
            if (i === 0) {
                left = right = point[0];
                top = bottom = point[1];
            } else {
                left = Math.min(left, point[0]);
                right = Math.max(right, point[0]);
                top = Math.min(top, point[1]);
                bottom = Math.max(bottom, point[1]);
            }
        }
        return { left: left, right: right, top: top, bottom: bottom };
    }

    function layerMaskSourcePoints(layer) {
        var masks;
        var mask;
        var shape;
        var points = [];
        var vertices;
        var i;
        var j;
        try { masks = layer.property("ADBE Mask Parade"); } catch (ignoreMasks) { masks = null; }
        if (!masks || masks.numProperties < 1) {
            return null;
        }
        for (i = 1; i <= masks.numProperties; i += 1) {
            try {
                mask = masks.property(i);
                if (!mask || mask.enabled === false || mask.maskMode === MaskMode.NONE || mask.maskMode === MaskMode.SUBTRACT) {
                    continue;
                }
                shape = mask.property("ADBE Mask Shape").value;
                vertices = shape && shape.vertices ? shape.vertices : [];
                for (j = 0; j < vertices.length; j += 1) {
                    points.push([vertices[j][0], vertices[j][1]]);
                }
            } catch (ignoreMaskVertices) {}
        }
        return points.length ? points : null;
    }

    function layerSourceRect(layer, time) {
        try {
            if (layer instanceof TextLayer || layer.matchName === "ADBE Vector Layer") {
                return layer.sourceRectAtTime(time, false);
            }
        } catch (ignoreRectLayerType) {}
        try {
            if (layer.source && layer.source.width && layer.source.height) {
                return { left: 0, top: 0, width: layer.source.width, height: layer.source.height };
            }
        } catch (ignoreSourceRect) {}
        try {
            return layer.sourceRectAtTime(time, false);
        } catch (ignoreFallbackRect) {}
        return null;
    }

    function sourcePointToCompSafe(layer, point) {
        try {
            if (typeof layer.sourcePointToComp === "function") {
                return layer.sourcePointToComp(point);
            }
        } catch (ignoreSourcePointToComp) {}
        return sourcePointToCompFallback(layer, point);
    }

    function sourcePointToCompFallback(layer, point) {
        var transform;
        var position;
        var scale;
        var anchor;
        var rotation;
        var radians;
        var x;
        var y;
        var rx;
        var ry;
        try {
            transform = layer.property("ADBE Transform Group");
            position = transform.property("ADBE Position").value;
            scale = transform.property("ADBE Scale").value;
            anchor = transform.property("ADBE Anchor Point").value;
            rotation = 0;
            try {
                rotation = transform.property("ADBE Rotate Z") ? transform.property("ADBE Rotate Z").value : transform.property("ADBE Rotation").value;
            } catch (ignoreRotation) {}
            x = (point[0] - anchor[0]) * (scale[0] / 100);
            y = (point[1] - anchor[1]) * (scale[1] / 100);
            radians = rotation * Math.PI / 180;
            rx = x * Math.cos(radians) - y * Math.sin(radians);
            ry = x * Math.sin(radians) + y * Math.cos(radians);
            return [position[0] + rx, position[1] + ry];
        } catch (ignoreCompFallback) {}
        return null;
    }

    function shiftLayerPosition(layer, delta) {
        var transform;
        var position;
        var value;
        var x;
        var y;
        try {
            transform = layer.property("ADBE Transform Group");
            position = transform.property("ADBE Position");
            if (position && position.dimensionsSeparated) {
                x = transform.property("ADBE Position_0");
                y = transform.property("ADBE Position_1");
                if (x) { x.setValue(x.value + delta[0]); }
                if (y) { y.setValue(y.value + delta[1]); }
                return;
            }
            if (position) {
                value = position.value;
                if (value.length === 3) {
                    position.setValue([value[0] + delta[0], value[1] + delta[1], value[2]]);
                } else {
                    position.setValue([value[0] + delta[0], value[1] + delta[1]]);
                }
            }
        } catch (ignoreShiftPosition) {}
    }

    function collectAllMarkerTimes(comp) {
        var markerTimes = [];
        var uniqueTimes = [];
        var epsilon = 0.0001;
        var compMarkers;
        var layer;
        var markerProperty;
        var i;
        var l;
        var j;
        var now = new Date().getTime();
        if (!comp || !(comp instanceof CompItem)) {
            return uniqueTimes;
        }
        if (api._markerNavigationCache.comp === comp &&
                now - api._markerNavigationCache.updatedAt <= 200) {
            return api._markerNavigationCache.times;
        }

        try {
            compMarkers = comp.markerProperty;
            if (compMarkers && compMarkers.numKeys > 0) {
                for (i = 1; i <= compMarkers.numKeys; i += 1) {
                    markerTimes.push(compMarkers.keyTime(i));
                }
            }
        } catch (ignoreCompMarkers) {}

        try {
            for (l = 1; l <= comp.numLayers; l += 1) {
                layer = comp.layer(l);
                markerProperty = layer.property("Marker");
                if (!markerProperty) {
                    markerProperty = layer.property("ADBE Marker");
                }
                if (markerProperty && markerProperty.numKeys > 0) {
                    for (j = 1; j <= markerProperty.numKeys; j += 1) {
                        markerTimes.push(markerProperty.keyTime(j));
                    }
                }
            }
        } catch (ignoreLayerMarkers) {}

        markerTimes.sort(function (a, b) { return a - b; });
        for (i = 0; i < markerTimes.length; i += 1) {
            if (!uniqueTimes.length || Math.abs(markerTimes[i] - uniqueTimes[uniqueTimes.length - 1]) > epsilon) {
                uniqueTimes.push(markerTimes[i]);
            }
        }
        api._markerNavigationCache.comp = comp;
        api._markerNavigationCache.updatedAt = now;
        api._markerNavigationCache.times = uniqueTimes;
        return uniqueTimes;
    }

    function navigateMarker(direction) {
        var comp = activeComp();
        var markerTimes;
        var currentTime;
        var targetTime = null;
        var epsilon = 0.0001;
        var i;
        if (!comp) {
            return false;
        }
        markerTimes = collectAllMarkerTimes(comp);
        if (!markerTimes.length) {
            return false;
        }
        currentTime = comp.time;
        if (direction === "previous") {
            for (i = markerTimes.length - 1; i >= 0; i -= 1) {
                if (markerTimes[i] < currentTime - epsilon) {
                    targetTime = markerTimes[i];
                    break;
                }
            }
        } else if (direction === "next") {
            for (i = 0; i < markerTimes.length; i += 1) {
                if (markerTimes[i] > currentTime + epsilon) {
                    targetTime = markerTimes[i];
                    break;
                }
            }
        }
        if (targetTime === null) {
            return false;
        }
        comp.time = targetTime;
        return true;
    }

    function withUndo(name, callback) {
        var result = false;
        app.beginUndoGroup(name);
        try {
            result = callback();
        } catch (ignore) {
            result = false;
        }
        app.endUndoGroup();
        return result;
    }

    function uniqueItemName(base) {
        var candidate = base;
        var suffix = 2;
        var i;
        var found;
        do {
            found = false;
            for (i = 1; i <= app.project.numItems; i += 1) {
                if (app.project.item(i).name === candidate) {
                    found = true;
                    break;
                }
            }
            if (found) {
                candidate = base + " " + suffix;
                suffix += 1;
            }
        } while (found);
        return candidate;
    }

    function precompose() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        var indices = [];
        var earliestIn;
        var latestOut;
        var topIndex;
        var layerAbove;
        var name;
        var i;
        if (!comp) {
            alert("Open an active composition.");
            return false;
        }
        if (!layers.length) {
            alert("Select one or more layers to precompose.");
            return false;
        }
        for (i = 0; i < layers.length; i += 1) {
            if (layers[i].locked) {
                alert("Unlock selected layers before precomposing.");
                return false;
            }
        }
        earliestIn = layers[0].inPoint;
        latestOut = layers[0].outPoint;
        topIndex = layers[0].index;
        for (i = 0; i < layers.length; i += 1) {
            indices.push(layers[i].index);
            earliestIn = Math.min(earliestIn, layers[i].inPoint);
            latestOut = Math.max(latestOut, layers[i].outPoint);
            topIndex = Math.min(topIndex, layers[i].index);
        }
        if (latestOut <= earliestIn) {
            return false;
        }
        indices.sort(function (a, b) { return a - b; });
        layerAbove = topIndex > 1 ? comp.layer(topIndex - 1) : null;
        name = uniqueItemName((layers[0].name || "Layer") + " Precomp");
        return withUndo("CLEAR Precompose", function () {
            var duration = latestOut - earliestIn;
            var newComp = comp.layers.precompose(indices, name, true);
            var precompLayer = null;
            var inner;
            var l;

            if (!newComp || !(newComp instanceof CompItem)) {
                return false;
            }

            for (l = 1; l <= newComp.numLayers; l += 1) {
                inner = newComp.layer(l);
                inner.startTime -= earliestIn;
            }

            newComp.displayStartTime = 0;
            newComp.duration = duration;
            newComp.workAreaStart = 0;
            newComp.workAreaDuration = duration;

            for (l = 1; l <= comp.numLayers; l += 1) {
                if (comp.layer(l).source === newComp) {
                    precompLayer = comp.layer(l);
                    break;
                }
            }
            if (!precompLayer) {
                return false;
            }

            normalizePrecompPlacement(precompLayer, comp, newComp);
            if (layerAbove) {
                precompLayer.moveAfter(layerAbove);
            } else {
                precompLayer.moveToBeginning();
            }

            // Match AE's "Move all attributes" + "Adjust composition duration
            // to the time span of selected layers": source time 0 appears at
            // the earliest selected in-point, and the outer layer keeps the
            // original selected timeline span.
            precompLayer.startTime = earliestIn;
            precompLayer.inPoint = earliestIn;
            precompLayer.outPoint = latestOut;
            return true;
        });
    }

    function normalizePrecompPlacement(layer, parentComp, sourceComp) {
        var transform;
        var anchor;
        var position;
        var anchorValue;
        var positionValue;
        try {
            transform = layer.property("ADBE Transform Group");
            anchor = transform.property("ADBE Anchor Point");
            position = transform.property("ADBE Position");
            anchorValue = anchor.value;
            positionValue = position.value;
            if (anchorValue.length === 3) {
                anchor.setValue([sourceComp.width / 2, sourceComp.height / 2, anchorValue[2]]);
            } else {
                anchor.setValue([sourceComp.width / 2, sourceComp.height / 2]);
            }
            if (positionValue.length === 3) {
                position.setValue([parentComp.width / 2, parentComp.height / 2, positionValue[2]]);
            } else {
                position.setValue([parentComp.width / 2, parentComp.height / 2]);
            }
        } catch (ignorePlacement) {}
    }

    function precomposeIndividual() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        var records = [];
        var i;
        if (!comp || !layers.length) {
            return false;
        }
        for (i = 0; i < layers.length; i += 1) {
            records.push({ index: layers[i].index, name: layers[i].name });
        }
        records.sort(function (a, b) { return b.index - a.index; });

        return withUndo("CLEAR Precompose Individual", function () {
            var record;
            var layer;
            var segmentStart;
            var segmentEnd;
            var duration;
            var newComp;
            var newLayer;
            var inner;
            var l;
            for (i = 0; i < records.length; i += 1) {
                record = records[i];
                layer = comp.layer(record.index);
                if (!layer) {
                    continue;
                }
                segmentStart = layer.inPoint;
                segmentEnd = layer.outPoint;
                duration = segmentEnd - segmentStart;
                if (duration <= 0) {
                    continue;
                }
                newComp = comp.layers.precompose([record.index], uniqueItemName((record.name || "Layer") + " Precomp"), true);
                if (!newComp || !(newComp instanceof CompItem)) {
                    continue;
                }
                try { newComp.duration = duration; } catch (ignoreDuration) {}
                for (l = 1; l <= newComp.numLayers; l += 1) {
                    inner = newComp.layer(l);
                    try { inner.startTime -= segmentStart; } catch (ignoreStart) {}
                }
                for (l = 1; l <= comp.numLayers; l += 1) {
                    if (comp.layer(l).source === newComp) {
                        newLayer = comp.layer(l);
                        try {
                            newLayer.startTime = segmentStart;
                            newLayer.inPoint = segmentStart;
                            newLayer.outPoint = segmentEnd;
                        } catch (ignoreTiming) {}
                        break;
                    }
                }
            }
            return true;
        });
    }

    function decompose() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        var records = [];
        var i;
        if (!comp || !layers.length) {
            return false;
        }
        for (i = 0; i < layers.length; i += 1) {
            if (layers[i].source && layers[i].source instanceof CompItem) {
                records.push(layers[i]);
            }
        }
        records.sort(function (a, b) { return b.index - a.index; });
        return withUndo("CLEAR Decompose", function () {
            var container;
            var source;
            var offset;
            var copied;
            var copies;
            var parentIndices;
            var originalParents;
            var sourceLayer;
            var sourceStartTime;
            var sourceInPoint;
            var sourceOutPoint;
            var restoredInPoint;
            var restoredOutPoint;
            var l;
            for (i = 0; i < records.length; i += 1) {
                container = records[i];
                source = container.source;
                offset = container.startTime;
                copies = [];
                parentIndices = [];
                originalParents = [];

                for (l = 1; l <= source.numLayers; l += 1) {
                    sourceLayer = source.layer(l);
                    parentIndices[l] = sourceLayer.parent ? sourceLayer.parent.index : 0;
                    originalParents[l] = sourceLayer.parent || null;
                }

                for (l = 1; l <= source.numLayers; l += 1) {
                    sourceLayer = source.layer(l);
                    if (originalParents[l]) {
                        try { sourceLayer.setParentWithJump(null); } catch (ignoreSourceUnparentJump) {
                            try { sourceLayer.parent = null; } catch (ignoreSourceUnparent) {}
                        }
                    }
                }

                for (l = 1; l <= source.numLayers; l += 1) {
                    sourceLayer = source.layer(l);
                    sourceStartTime = sourceLayer.startTime;
                    sourceInPoint = sourceLayer.inPoint;
                    sourceOutPoint = sourceLayer.outPoint;
                    try {
                        copied = copyLayerToComp(sourceLayer, comp);
                        if (!copied) {
                            continue;
                        }
                        restoredInPoint = Math.max(sourceInPoint + offset, container.inPoint);
                        restoredOutPoint = Math.min(sourceOutPoint + offset, container.outPoint);
                        try { copied.startTime = sourceStartTime + offset; } catch (ignoreCopiedStart) {}
                        if (restoredOutPoint > restoredInPoint) {
                            try { copied.inPoint = restoredInPoint; } catch (ignoreCopiedIn) {}
                            try { copied.outPoint = restoredOutPoint; } catch (ignoreCopiedOut) {}
                        }
                        try { copied.moveBefore(container); } catch (ignoreCopiedMove) {}
                        try { rememberLayerFor3D(comp, copied); } catch (ignoreCopied3D) {}
                    } catch (ignoreCopy) {}
                    if (copied) {
                        copies[l] = copied;
                    }
                    copied = null;
                }

                for (l = 1; l <= source.numLayers; l += 1) {
                    if (originalParents[l]) {
                        try { source.layer(l).setParentWithJump(originalParents[l]); } catch (ignoreSourceReparentJump) {
                            try { source.layer(l).parent = originalParents[l]; } catch (ignoreSourceReparent) {}
                        }
                    }
                }

                for (l = 1; l < copies.length; l += 1) {
                    if (copies[l] && parentIndices[l] && copies[parentIndices[l]]) {
                        try { copies[l].setParentWithJump(copies[parentIndices[l]]); } catch (ignoreParent) {}
                    }
                }
                try { container.remove(); } catch (ignoreRemove) {}
            }
            return records.length > 0;
        });
    }

    function copyLayerToComp(sourceLayer, targetComp) {
        var beforeCopy = captureLayerSnapshot(targetComp);
        var copied = null;
        try {
            sourceLayer.copyToComp(targetComp);
        } catch (ignoreCopyToComp) {
            return null;
        }
        try {
            copied = targetComp.layer(1);
            if (copied && !snapshotContainsLayer(beforeCopy, copied)) {
                return copied;
            }
        } catch (ignoreTopLayer) {}
        return findAddedLayer(targetComp, beforeCopy);
    }

    function captureLayerSnapshot(comp) {
        var snapshot = { ids: {}, layers: [] };
        var layer;
        var i;
        for (i = 1; i <= comp.numLayers; i += 1) {
            layer = comp.layer(i);
            snapshot.layers.push(layer);
            try { snapshot.ids[String(layer.id)] = true; } catch (ignoreLayerId) {}
        }
        return snapshot;
    }

    function snapshotContainsLayer(snapshot, layer) {
        var i;
        try {
            if (snapshot.ids[String(layer.id)]) {
                return true;
            }
        } catch (ignoreSnapshotId) {}
        for (i = 0; i < snapshot.layers.length; i += 1) {
            if (snapshot.layers[i] === layer) {
                return true;
            }
        }
        return false;
    }

    function findAddedLayer(comp, snapshot) {
        var layer;
        var known;
        var i;
        var j;
        for (i = 1; i <= comp.numLayers; i += 1) {
            layer = comp.layer(i);
            try {
                if (!snapshot.ids[String(layer.id)]) {
                    return layer;
                }
            } catch (ignoreLayerId) {}
        }
        for (i = 1; i <= comp.numLayers; i += 1) {
            layer = comp.layer(i);
            known = false;
            for (j = 0; j < snapshot.layers.length; j += 1) {
                if (snapshot.layers[j] === layer) {
                    known = true;
                    break;
                }
            }
            if (!known) {
                return layer;
            }
        }
        return null;
    }

    function addAdjustment() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        if (!comp || !layers.length) {
            return false;
        }
        return withUndo("CLEAR Add Adjustment Layer", function () {
            var sourceLayer;
            var adjustment;
            var createdAdjustments = [];
            var duration;
            var i;
            for (i = 0; i < layers.length; i += 1) {
                sourceLayer = layers[i];
                duration = sourceLayer.outPoint - sourceLayer.inPoint;
                if (duration <= 0) {
                    continue;
                }
                adjustment = comp.layers.addSolid([1, 1, 1], "Adjustment Layer", comp.width, comp.height, comp.pixelAspect, duration);
                adjustment.adjustmentLayer = true;
                adjustment.label = 5;
                adjustment.startTime = sourceLayer.inPoint;
                adjustment.inPoint = sourceLayer.inPoint;
                adjustment.outPoint = sourceLayer.outPoint;
                adjustment.moveBefore(sourceLayer);
                createdAdjustments.push(adjustment);
            }
            if (createdAdjustments.length) {
                clearSelections(comp);
                for (i = 0; i < createdAdjustments.length; i += 1) {
                    try { createdAdjustments[i].selected = true; } catch (ignoreSelection) {}
                }
            }
            return true;
        });
    }

    function addNull() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        if (!comp) {
            return false;
        }
        return withUndo("CLEAR Add Null", function () {
            var nullLayer;
            var i;
            if (!layers.length) {
                nullLayer = comp.layers.addNull(comp.duration);
                nullLayer.name = "Null";
                return true;
            }
            for (i = 0; i < layers.length; i += 1) {
                nullLayer = comp.layers.addNull(layers[i].outPoint - layers[i].inPoint);
                nullLayer.name = "Null " + (i + 1);
                nullLayer.startTime = layers[i].inPoint;
                nullLayer.inPoint = layers[i].inPoint;
                nullLayer.outPoint = layers[i].outPoint;
                nullLayer.moveBefore(layers[i]);
            }
            return true;
        });
    }

    function linkToParent(options) {
        var comp = activeComp();
        options = options || {};
        if (options.setOptions) {
            api._parentLinkColorGrouping = options.colorGrouping !== false;
            api._parentLinkOrganize = options.organize !== false;
            return {
                enabled: api._parentLinkMode,
                colorGrouping: api._parentLinkColorGrouping,
                organize: api._parentLinkOrganize
            };
        }
        api._parentLinkColorGrouping = options.colorGrouping !== false;
        api._parentLinkOrganize = options.organize !== false;
        if (options && options.live) {
            return enforceParentLinkMode();
        }
        api._parentLinkMode = !api._parentLinkMode;
        if (api._parentLinkMode) {
            api._parentLinkChildLabels = {};
            api._parentLinkKnownPairs = {};
            api._parentLinkGroupLabels = {};
            api._parentLinkUsedLabels = {};
            startParentLinkTask();
            if (comp) {
                initializeParentLinkState(comp);
                organizeParentGroups(comp, true, true, selectedParentGroupKeys(comp));
            }
        } else {
            stopParentLinkTask();
        }
        return {
            enabled: api._parentLinkMode,
            colorGrouping: api._parentLinkColorGrouping,
            organize: api._parentLinkOrganize
        };
    }

    function getParentLinkState() {
        if (api._parentLinkMode) {
            startParentLinkTask();
        }
        return {
            enabled: api._parentLinkMode,
            colorGrouping: api._parentLinkColorGrouping,
            organize: api._parentLinkOrganize
        };
    }

    function startParentLinkTask() {
        if (!api._parentLinkTaskId) {
            try { api._parentLinkTaskId = app.scheduleTask("CLEAR.enforceParentLinkMode()", 500, true); } catch (ignoreSchedule) {}
        }
    }

    function stopParentLinkTask() {
        if (api._parentLinkTaskId) {
            try { app.cancelTask(api._parentLinkTaskId); } catch (ignoreCancel) {}
            api._parentLinkTaskId = 0;
        }
    }

    function enforceParentLinkMode() {
        var comp = activeComp();
        if (!api._parentLinkMode || !comp) {
            return { enabled: api._parentLinkMode };
        }
        organizeParentGroups(comp, false, false);
        return { enabled: true };
    }

    function initializeParentLinkState(comp) {
        var groups = collectParentGroups(comp);
        var root;
        var key;
        var label;
        var i;
        if (!groups.length) {
            return;
        }
        for (i = 0; i < groups.length; i += 1) {
            rememberParentLinks(groups[i]);
            root = rootParentOf(groups[i].parent);
            key = layerKey(root);
            if (!api._parentLinkGroupLabels[key]) {
                label = validLightParentLabel(root.label, parentLinkBaseLabels()) ? root.label : 0;
                if (label) {
                    api._parentLinkGroupLabels[key] = label;
                    api._parentLinkUsedLabels[label] = true;
                }
            }
        }
    }

    function selectedParentGroupKeys(comp) {
        var selected = selectedLayers(comp);
        var groups = collectParentGroups(comp);
        var selectedKeys = {};
        var selectedMap = {};
        var group;
        var i;
        var j;
        if (!selected.length) {
            return selectedKeys;
        }
        for (i = 0; i < selected.length; i += 1) {
            selectedMap[layerKey(selected[i])] = true;
        }
        for (i = 0; i < groups.length; i += 1) {
            group = groups[i];
            if (selectedMap[layerKey(group.parent)] || selectedMap[layerKey(rootParentOf(group.parent))]) {
                selectedKeys[layerKey(group.parent)] = true;
                continue;
            }
            for (j = 0; j < group.children.length; j += 1) {
                if (selectedMap[layerKey(group.children[j])]) {
                    selectedKeys[layerKey(group.parent)] = true;
                    break;
                }
            }
        }
        return selectedKeys;
    }

    function organizeParentGroups(comp, forceOrganize, forceColor, allowedGroupKeys) {
        var groups = collectParentGroups(comp);
        var baseLabels = parentLinkBaseLabels();
        var changed = false;
        var group;
        var parentLabel;
        var groupKey;
        var newLinks;
        var i;
        syncCurrentParentLinks(groups);
        if (!groups.length) {
            return false;
        }
        for (i = 0; i < groups.length; i += 1) {
            group = groups[i];
            groupKey = layerKey(group.parent);
            newLinks = hasNewParentLinks(group);
            if (allowedGroupKeys && !allowedGroupKeys[groupKey]) {
                continue;
            }
            if (!forceColor && !forceOrganize && !newLinks) {
                continue;
            }
            if (api._parentLinkColorGrouping) {
                parentLabel = parentGroupLabel(group, baseLabels, i, forceColor || newLinks);
                changed = applyChildGroupLabels(group, parentLabel, forceColor) || changed;
            }
            if (api._parentLinkOrganize && (forceOrganize || newLinks)) {
                changed = compactParentGroup(group) || changed;
            }
            rememberParentLinks(group);
        }
        return changed;
    }

    function rootParentOf(layer) {
        var root = layer;
        var parent = null;
        while (root) {
            try { parent = root.parent; } catch (ignoreParent) { parent = null; }
            if (!parent) {
                break;
            }
            root = parent;
        }
        return root || layer;
    }

    function parentGroupLabel(group, baseLabels, startIndex, assignToRoot) {
        var root = rootParentOf(group.parent);
        var rootKey = layerKey(root);
        var label = api._parentLinkGroupLabels[rootKey];
        var rootLabel;
        if (label && root === group.parent) {
            try {
                rootLabel = validLightParentLabel(root.label, baseLabels) ? root.label : 0;
                if (rootLabel && rootLabel !== label) {
                    label = rootLabel;
                    api._parentLinkGroupLabels[rootKey] = label;
                    api._parentLinkUsedLabels[label] = true;
                }
            } catch (ignoreRootLabel) {}
        }
        if (!label) {
            rootLabel = validLightParentLabel(root.label, baseLabels) ? root.label : 0;
            if (rootLabel && !api._parentLinkUsedLabels[rootLabel]) {
                label = rootLabel;
            } else {
                label = nextUnusedParentLabel(baseLabels, api._parentLinkUsedLabels, startIndex);
            }
            api._parentLinkGroupLabels[rootKey] = label;
            api._parentLinkUsedLabels[label] = true;
        }
        if (assignToRoot && root === group.parent) {
            try {
                if (root.label !== label) {
                    root.label = label;
                }
            } catch (ignoreAssignRootLabel) {}
        }
        return label;
    }

    function validLightParentLabel(label, baseLabels) {
        var i;
        label = Number(label);
        for (i = 0; i < baseLabels.length; i += 1) {
            if (baseLabels[i] === label) {
                return true;
            }
        }
        return false;
    }

    function parentLinkBaseLabels() {
        // Avoid Brown, Grey/Sandstone, and Dark Green for automatic parent groups.
        return [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14];
    }

    function nextUnusedParentLabel(baseLabels, usedParentLabels, startIndex) {
        var candidate;
        var offset;
        for (offset = 0; offset < baseLabels.length; offset += 1) {
            candidate = baseLabels[(startIndex + offset) % baseLabels.length];
            if (!usedParentLabels[candidate]) {
                return candidate;
            }
        }
        return baseLabels[startIndex % baseLabels.length];
    }

    function collectParentGroups(comp) {
        var groups = [];
        var groupMap = {};
        var layer;
        var parent;
        var key;
        var i;
        for (i = 1; i <= comp.numLayers; i += 1) {
            layer = comp.layer(i);
            parent = null;
            try { parent = layer.parent; } catch (ignoreParent) {}
            if (!parent) {
                continue;
            }
            key = layerKey(parent);
            if (!groupMap[key]) {
                groupMap[key] = {
                    parent: parent,
                    above: [],
                    below: [],
                    children: []
                };
                groups.push(groupMap[key]);
            }
            groupMap[key].children.push(layer);
            if (layer.index < parent.index) {
                groupMap[key].above.push(layer);
            } else {
                groupMap[key].below.push(layer);
            }
        }
        groups.sort(function (a, b) {
            return a.parent.index - b.parent.index;
        });
        for (i = 0; i < groups.length; i += 1) {
            groups[i].above.sort(function (a, b) { return a.index - b.index; });
            groups[i].below.sort(function (a, b) { return a.index - b.index; });
            groups[i].children.sort(function (a, b) { return a.index - b.index; });
        }
        return groups;
    }

    function layerKey(layer) {
        try {
            return "id:" + layer.id;
        } catch (ignoreId) {}
        return "index:" + layer.index + ":" + layer.name;
    }

    function validLabel(label) {
        label = Number(label);
        return label >= 1 && label <= 16;
    }

    function childShadeLabels(parentLabel) {
        return [parentLabel];
    }

    function parentPairKey(parent, child) {
        return layerKey(parent) + ">" + layerKey(child);
    }

    function syncCurrentParentLinks(groups) {
        var currentPairs = {};
        var key;
        var i;
        var j;
        for (i = 0; i < groups.length; i += 1) {
            for (j = 0; j < groups[i].children.length; j += 1) {
                currentPairs[parentPairKey(groups[i].parent, groups[i].children[j])] = true;
            }
        }
        for (key in api._parentLinkKnownPairs) {
            if (api._parentLinkKnownPairs.hasOwnProperty(key) && !currentPairs[key]) {
                delete api._parentLinkKnownPairs[key];
            }
        }
    }

    function hasNewParentLinks(group) {
        var i;
        for (i = 0; i < group.children.length; i += 1) {
            if (!api._parentLinkKnownPairs[parentPairKey(group.parent, group.children[i])]) {
                return true;
            }
        }
        return false;
    }

    function rememberParentLinks(group) {
        var i;
        for (i = 0; i < group.children.length; i += 1) {
            api._parentLinkKnownPairs[parentPairKey(group.parent, group.children[i])] = true;
        }
    }

    function applyChildGroupLabels(group, parentLabel, forceColor) {
        var shades = childShadeLabels(parentLabel);
        var changed = false;
        var targetLabel;
        var child;
        var childKey;
        var previousAppliedLabel;
        var i;
        for (i = 0; i < group.children.length; i += 1) {
            child = group.children[i];
            childKey = layerKey(child);
            previousAppliedLabel = api._parentLinkChildLabels[childKey];
            targetLabel = shades[i % shades.length];
            try {
                if (!forceColor && previousAppliedLabel !== undefined && child.label !== previousAppliedLabel) {
                    continue;
                }
                if (child.label !== targetLabel) {
                    child.label = targetLabel;
                    changed = true;
                }
                api._parentLinkChildLabels[childKey] = targetLabel;
            } catch (ignoreChildLabel) {}
        }
        return changed;
    }

    function compactParentGroup(group) {
        var changed = false;
        var reference;
        var child;
        var i;
        reference = group.parent;
        for (i = group.above.length - 1; i >= 0; i -= 1) {
            child = group.above[i];
            try {
                if (child.index !== reference.index - 1) {
                    child.moveBefore(reference);
                    changed = true;
                }
                reference = child;
            } catch (ignoreMoveAbove) {}
        }
        reference = group.parent;
        for (i = 0; i < group.below.length; i += 1) {
            child = group.below[i];
            try {
                if (child.index !== reference.index + 1) {
                    child.moveAfter(reference);
                    changed = true;
                }
                reference = child;
            } catch (ignoreMoveBelow) {}
        }
        return changed;
    }

    function fitLayer() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        var mode = api._fitLayerMode === "height" ? "height" : "width";
        api._fitLayerMode = mode === "width" ? "height" : "width";
        if (!comp || !layers.length) {
            return false;
        }
        return withUndo("CLEAR Fit Layers", function () {
            var compWidth = comp.width;
            var compHeight = comp.height;
            var compCenter = [compWidth / 2, compHeight / 2];
            var layer;
            var rect;
            var width;
            var height;
            var rotation;
            var radians;
            var cosine;
            var sine;
            var rotatedWidth;
            var rotatedHeight;
            var fitScale;
            var transform;
            var scaleProperty;
            var positionProperty;
            var anchorProperty;
            var oldScale;
            var oldPosition;
            var anchor;
            var rectCenterX;
            var rectCenterY;
            var offsetX;
            var offsetY;
            var scaleFactor;
            var rotatedOffsetX;
            var rotatedOffsetY;
            var i;
            for (i = 0; i < layers.length; i += 1) {
                layer = layers[i];
                if (layer.locked) {
                    continue;
                }
                try {
                    if ((layer instanceof TextLayer || layer.matchName === "ADBE Vector Layer") && layer.sourceRectAtTime) {
                        rect = layer.sourceRectAtTime(comp.time, false);
                    } else if (layer.source && layer.source.width && layer.source.height) {
                        rect = { left: 0, top: 0, width: layer.source.width, height: layer.source.height };
                    } else {
                        continue;
                    }
                    if (!rect || rect.width <= 0 || rect.height <= 0) {
                        continue;
                    }

                    width = rect.width;
                    height = rect.height;
                    transform = layer.property("ADBE Transform Group");
                    rotation = transform.property("ADBE Rotate Z");
                    if (!rotation) {
                        rotation = transform.property("ADBE Rotation");
                    }
                    rotation = rotation ? rotation.value : 0;
                    radians = rotation * Math.PI / 180;
                    cosine = Math.abs(Math.cos(radians));
                    sine = Math.abs(Math.sin(radians));
                    rotatedWidth = width * cosine + height * sine;
                    rotatedHeight = width * sine + height * cosine;
                    fitScale = (mode === "height" ? compHeight / rotatedHeight : compWidth / rotatedWidth) * 100;

                    scaleProperty = transform.property("ADBE Scale");
                    positionProperty = transform.property("ADBE Position");
                    anchorProperty = transform.property("ADBE Anchor Point");
                    oldScale = scaleProperty.value;
                    oldPosition = positionProperty.value;
                    anchor = anchorProperty.value;

                    if (oldScale.length === 3) {
                        scaleProperty.setValue([fitScale, fitScale, oldScale[2]]);
                    } else {
                        scaleProperty.setValue([fitScale, fitScale]);
                    }

                    rectCenterX = rect.left + rect.width / 2;
                    rectCenterY = rect.top + rect.height / 2;
                    offsetX = rectCenterX - anchor[0];
                    offsetY = rectCenterY - anchor[1];
                    scaleFactor = fitScale / 100;
                    rotatedOffsetX = (offsetX * Math.cos(radians) - offsetY * Math.sin(radians)) * scaleFactor;
                    rotatedOffsetY = (offsetX * Math.sin(radians) + offsetY * Math.cos(radians)) * scaleFactor;

                    if (oldPosition.length === 3) {
                        positionProperty.setValue([compCenter[0] - rotatedOffsetX, compCenter[1] - rotatedOffsetY, oldPosition[2]]);
                    } else {
                        positionProperty.setValue([compCenter[0] - rotatedOffsetX, compCenter[1] - rotatedOffsetY]);
                    }
                } catch (ignoreLayer) {}
            }
            return true;
        });
    }

    function topToBottom() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        if (!comp || layers.length < 2) {
            return false;
        }
        layers.sort(function (a, b) { return a.index - b.index; });
        return withUndo("CLEAR Reverse Layer Order", function () {
            var anchor = layers[0];
            var i;
            for (i = layers.length - 1; i >= 1; i -= 1) {
                layers[i].moveBefore(anchor);
            }
            return true;
        });
    }

    function rotateCW() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        if (!comp || !layers.length) {
            return false;
        }
        return withUndo("CLEAR Rotate 90 Clockwise", function () {
            var rotation;
            var i;
            for (i = 0; i < layers.length; i += 1) {
                rotation = layers[i].property("ADBE Transform Group").property("ADBE Rotate Z");
                if (rotation) {
                    rotation.setValue(rotation.value + 90);
                }
            }
            return true;
        });
    }

    function clearSelections(comp) {
        var i;
        var properties;
        try {
            properties = comp.selectedProperties;
            for (i = properties.length - 1; i >= 0; i -= 1) {
                try { properties[i].selected = false; } catch (ignoreProperty) {}
            }
        } catch (ignoreProperties) {}
        for (i = 1; i <= comp.numLayers; i += 1) {
            try { comp.layer(i).selected = false; } catch (ignoreLayer) {}
        }
    }

    function pasteEffects() {
        var comp = activeComp();
        var targets;
        var dialog;
        var stretchCheckbox;
        var buttons;
        var shouldStretch;
        var commandId;
        var pastedLayerCount = 0;
        var failedLayers = [];
        var i;

        if (!comp) {
            alert("Open a composition and select destination layers.");
            return false;
        }
        targets = selectedLayers(comp);
        if (!targets.length) {
            alert("Select at least one destination layer.");
            return false;
        }

        dialog = new Window("dialog", "Paste Copied Effects");
        dialog.orientation = "column";
        dialog.alignChildren = ["left", "top"];
        dialog.spacing = 10;
        dialog.margins = 16;
        dialog.add("statictext", undefined, "Paste the previously copied effect(s) to all selected layers.");
        stretchCheckbox = dialog.add("checkbox", undefined, "Stretch keyframes to each layer length");
        stretchCheckbox.value = false;
        dialog.add("statictext", undefined, "Unticked: keep keyframe spacing and align the first key to the layer In Point.");
        buttons = dialog.add("group");
        buttons.alignment = "right";
        buttons.add("button", undefined, "Cancel", { name: "cancel" });
        buttons.add("button", undefined, "Paste", { name: "ok" });

        if (dialog.show() !== 1) {
            return false;
        }

        shouldStretch = stretchCheckbox.value;
        commandId = app.findMenuCommandId("Paste") || 20;
        app.beginUndoGroup("CLEAR Paste Effects");
        try {
            try { comp.openInViewer(); } catch (ignoreViewer) {}
            clearSelections(comp);
            for (i = 0; i < targets.length; i += 1) {
                var layer = targets[i];
                var effects;
                var beforeCount;
                var afterCount;
                var effectIndex;
                if (layer.locked) {
                    failedLayers.push(layer.name + " (locked)");
                    continue;
                }
                clearSelections(comp);
                layer.selected = true;
                effects = layer.property("ADBE Effect Parade");
                beforeCount = effects ? effects.numProperties : 0;
                app.executeCommand(commandId);
                effects = layer.property("ADBE Effect Parade");
                afterCount = effects ? effects.numProperties : 0;
                if (!effects || afterCount <= beforeCount) {
                    failedLayers.push(layer.name);
                    continue;
                }
                pastedLayerCount += 1;
                for (effectIndex = beforeCount + 1; effectIndex <= afterCount; effectIndex += 1) {
                    retimePastedProperties(effects.property(effectIndex), layer.inPoint, layer.outPoint, shouldStretch);
                }
            }
        } catch (error) {
            alert("Unable to paste the copied effects.\n\n" + error.toString());
        } finally {
            clearSelections(comp);
            for (i = 0; i < targets.length; i += 1) {
                try { targets[i].selected = true; } catch (ignoreRestore) {}
            }
            app.endUndoGroup();
        }

        if (pastedLayerCount === 0) {
            alert("No effects were pasted.\n\nCopy one or more effects from the Effect Controls panel, select the destination layers, and run the script again.");
        } else if (failedLayers.length > 0) {
            alert("Effects pasted to " + pastedLayerCount + " layer(s).\n\nCould not paste to:\n- " + failedLayers.join("\n- "));
        }
        if (pastedLayerCount > 0) {
            openEffectControlsPanel();
        }
        return true;
    }

    function openEffectControlsPanel() {
        var commandId;
        if (api._effectControlsOpenedByClear) {
            return true;
        }
        try {
            commandId = app.findMenuCommandId("Effect Controls");
            if (commandId) {
                app.executeCommand(commandId);
                api._effectControlsOpenedByClear = true;
                return true;
            }
        } catch (ignoreEffectControls) {}
        return false;
    }

    function retimePastedProperties(group, layerIn, layerOut, stretch) {
        var propertyIndex;
        if (!group) {
            return;
        }
        if (group.propertyType === PropertyType.PROPERTY) {
            retimePastedProperty(group, layerIn, layerOut, stretch);
            return;
        }
        for (propertyIndex = 1; propertyIndex <= group.numProperties; propertyIndex += 1) {
            retimePastedProperties(group.property(propertyIndex), layerIn, layerOut, stretch);
        }
    }

    function retimePastedProperty(prop, layerIn, layerOut, stretch) {
        var keys = [];
        var firstTime;
        var lastTime;
        var originalSpan;
        var layerDuration;
        var timeScale = 1;
        var keyIndex;
        var newTime;
        var normalizedTime;
        if (!prop.canVaryOverTime || prop.numKeys < 1) {
            return;
        }
        for (keyIndex = 1; keyIndex <= prop.numKeys; keyIndex += 1) {
            keys.push(capturePastedKey(prop, keyIndex));
        }
        firstTime = keys[0].time;
        lastTime = keys[keys.length - 1].time;
        originalSpan = lastTime - firstTime;
        layerDuration = layerOut - layerIn;
        if (stretch && keys.length > 1 && originalSpan > 0 && layerDuration > 0) {
            timeScale = layerDuration / originalSpan;
        }
        while (prop.numKeys > 0) {
            prop.removeKey(1);
        }
        for (keyIndex = 0; keyIndex < keys.length; keyIndex += 1) {
            if (stretch && keys.length > 1 && originalSpan > 0 && layerDuration > 0) {
                normalizedTime = (keys[keyIndex].time - firstTime) / originalSpan;
                newTime = layerIn + (normalizedTime * layerDuration);
            } else {
                newTime = keys[keyIndex].time + (layerIn - firstTime);
            }
            restorePastedKey(prop, newTime, keys[keyIndex], timeScale);
        }
    }

    function capturePastedKey(prop, keyIndex) {
        var keyData = {
            time: prop.keyTime(keyIndex),
            value: prop.keyValue(keyIndex),
            inInterpolation: prop.keyInInterpolationType(keyIndex),
            outInterpolation: prop.keyOutInterpolationType(keyIndex),
            easeIn: null,
            easeOut: null,
            temporalContinuous: null,
            temporalAutoBezier: null,
            spatialContinuous: null,
            spatialAutoBezier: null,
            inSpatialTangent: null,
            outSpatialTangent: null,
            roving: null
        };
        try {
            keyData.easeIn = prop.keyInTemporalEase(keyIndex);
            keyData.easeOut = prop.keyOutTemporalEase(keyIndex);
        } catch (ignoreEase) {}
        try { keyData.temporalContinuous = prop.keyTemporalContinuous(keyIndex); } catch (ignoreTemporalContinuous) {}
        try { keyData.temporalAutoBezier = prop.keyTemporalAutoBezier(keyIndex); } catch (ignoreTemporalAutoBezier) {}
        try {
            if (prop.isSpatial) {
                keyData.spatialContinuous = prop.keySpatialContinuous(keyIndex);
                keyData.spatialAutoBezier = prop.keySpatialAutoBezier(keyIndex);
                keyData.inSpatialTangent = prop.keyInSpatialTangent(keyIndex);
                keyData.outSpatialTangent = prop.keyOutSpatialTangent(keyIndex);
                keyData.roving = prop.keyRoving(keyIndex);
            }
        } catch (ignoreSpatial) {}
        return keyData;
    }

    function scalePastedTemporalEase(eases, timeScale) {
        var scaled = [];
        var easeIndex;
        if (!eases || timeScale <= 0 || timeScale === 1) {
            return eases;
        }
        for (easeIndex = 0; easeIndex < eases.length; easeIndex += 1) {
            scaled.push(new KeyframeEase(eases[easeIndex].speed / timeScale, eases[easeIndex].influence));
        }
        return scaled;
    }

    function restorePastedKey(prop, time, keyData, timeScale) {
        var newKeyIndex = prop.addKey(time);
        var scaledEaseIn;
        var scaledEaseOut;
        prop.setValueAtKey(newKeyIndex, keyData.value);
        try { prop.setInterpolationTypeAtKey(newKeyIndex, keyData.inInterpolation, keyData.outInterpolation); } catch (ignoreInterpolation) {}
        try {
            if (keyData.easeIn !== null && keyData.easeOut !== null) {
                scaledEaseIn = scalePastedTemporalEase(keyData.easeIn, timeScale);
                scaledEaseOut = scalePastedTemporalEase(keyData.easeOut, timeScale);
                prop.setTemporalEaseAtKey(newKeyIndex, scaledEaseIn, scaledEaseOut);
            }
        } catch (ignoreTemporalEase) {}
        try {
            if (keyData.temporalContinuous !== null) {
                prop.setTemporalContinuousAtKey(newKeyIndex, keyData.temporalContinuous);
            }
        } catch (ignoreSetTemporalContinuous) {}
        try {
            if (keyData.temporalAutoBezier !== null) {
                prop.setTemporalAutoBezierAtKey(newKeyIndex, keyData.temporalAutoBezier);
            }
        } catch (ignoreSetTemporalAutoBezier) {}
        try {
            if (prop.isSpatial && keyData.inSpatialTangent !== null && keyData.outSpatialTangent !== null) {
                prop.setSpatialTangentsAtKey(newKeyIndex, keyData.inSpatialTangent, keyData.outSpatialTangent);
            }
        } catch (ignoreSetSpatialTangents) {}
        try {
            if (prop.isSpatial && keyData.spatialContinuous !== null) {
                prop.setSpatialContinuousAtKey(newKeyIndex, keyData.spatialContinuous);
            }
        } catch (ignoreSetSpatialContinuous) {}
        try {
            if (prop.isSpatial && keyData.spatialAutoBezier !== null) {
                prop.setSpatialAutoBezierAtKey(newKeyIndex, keyData.spatialAutoBezier);
            }
        } catch (ignoreSetSpatialAutoBezier) {}
        try {
            if (prop.isSpatial && keyData.roving !== null) {
                prop.setRovingAtKey(newKeyIndex, keyData.roving);
            }
        } catch (ignoreSetRoving) {}
    }

    function deleteAllEffects() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        if (!comp || !layers.length) {
            return false;
        }
        return withUndo("CLEAR Delete All Effects", function () {
            var effects;
            var i;
            var e;
            for (i = 0; i < layers.length; i += 1) {
                effects = layers[i].property("ADBE Effect Parade");
                if (!effects) {
                    continue;
                }
                for (e = effects.numProperties; e >= 1; e -= 1) {
                    try { effects.property(e).remove(); } catch (ignoreRemove) {}
                }
            }
            return true;
        });
    }

    function fastColor() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        var selectedLayerIndices = [];
        var pickerFile;
        var resultFile;
        var colorHex = "";
        var color;
        var changedCount = 0;
        var layer;
        var i;
        if (!comp) {
            alert("Open an active composition.");
            return false;
        }
        if (!layers.length) {
            alert("Color Picker works only on Solid, Text and Shape layers.");
            return false;
        }
        for (i = 0; i < layers.length; i += 1) {
            if (isColorEditableLayer(layers[i])) {
                selectedLayerIndices.push(layers[i].index);
            }
        }
        if (!selectedLayerIndices.length) {
            alert("Color Picker works only on Solid, Text and Shape layers.");
            return false;
        }
        pickerFile = new File(extensionFolder().fsName + "/bin/ClearColorPicker.exe");
        if (!pickerFile.exists) {
            alert("Fast Color Picker is missing.");
            return false;
        }
        resultFile = fastColorResultFile();
        try {
            if (resultFile.exists) {
                resultFile.remove();
            }
        } catch (ignoreRemoveBefore) {}

        system.callSystem("\"" + pickerFile.fsName + "\"");

        colorHex = readTextFile(resultFile);
        try {
            if (resultFile.exists) {
                resultFile.remove();
            }
        } catch (ignoreRemoveAfter) {}
        colorHex = trimString(colorHex);
        if (!colorHex || colorHex.toUpperCase() === "CANCEL") {
            return true;
        }
        color = parseHexColor(colorHex);
        if (!color) {
            return true;
        }

        withUndo("CLEAR Fast Color Picker", function () {
            for (i = 0; i < selectedLayerIndices.length; i += 1) {
                try { layer = comp.layer(selectedLayerIndices[i]); } catch (ignoreLayerLookup) { layer = null; }
                if (layer) {
                    changedCount += applyColorToLayer(layer, color);
                }
            }
            return true;
        });
        return true;
    }

    function pickQuickColor() {
        var picked;
        var hex;
        try { picked = $.colorPicker(); } catch (ignorePicker) { picked = -1; }
        if (picked === undefined || picked === null || picked < 0) {
            return "";
        }
        picked = picked & 0xFFFFFF;
        hex = picked.toString(16).toUpperCase();
        while (hex.length < 6) {
            hex = "0" + hex;
        }
        return "#" + hex;
    }

    function applyQuickColor(colorHex) {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        var color = parseHexColor(colorHex);
        if (!comp || !layers.length || !color) {
            return { changed: 0 };
        }
        return withUndo("CLEAR Quick Colors", function () {
            var layer;
            var contents;
            var changed = 0;
            var i;
            for (i = 0; i < layers.length; i += 1) {
                layer = layers[i];
                try {
                    if (layer.property("ADBE Text Properties")) {
                        changed += applyTextColor(layer, color);
                    } else if (isSolidLayer(layer)) {
                        changed += applySolidColor(layer, color);
                    } else {
                        contents = layer.property("ADBE Root Vectors Group");
                        if (contents) {
                            changed += updateShapeColors(contents, color);
                        }
                    }
                } catch (ignoreQuickColorLayer) {}
            }
            return { changed: changed };
        });
    }

    function getFastColorContext() {
        var comp = activeComp();
        var layers;
        var i;
        if (!comp) {
            return { ready: false, reason: "noComp" };
        }
        layers = comp.selectedLayers || [];
        if (!layers.length) {
            return { ready: false, reason: "noSelection" };
        }
        for (i = 0; i < layers.length; i += 1) {
            if (isColorEditableLayer(layers[i])) {
                return { ready: true, reason: "" };
            }
        }
        return { ready: false, reason: "unsupported" };
    }

    function isTextOrShapeLayer(layer) {
        try {
            return Boolean(
                layer && (
                    layer.property("ADBE Text Properties") ||
                    layer.property("ADBE Root Vectors Group")
                )
            );
        } catch (ignoreLayerType) {}
        return false;
    }

    function isColorEditableLayer(layer) {
        return isTextOrShapeLayer(layer) || isSolidLayer(layer);
    }

    function isSolidLayer(layer) {
        try {
            return Boolean(layer && layer.source && layer.source.mainSource &&
                layer.source.mainSource.color !== undefined);
        } catch (ignoreSolidLayer) {}
        return false;
    }

    function parseHexColor(value) {
        var match = /^#?([0-9a-f]{6})$/i.exec(String(value || ""));
        var integer;
        if (!match) {
            return null;
        }
        integer = parseInt(match[1], 16);
        return [
            ((integer >> 16) & 255) / 255,
            ((integer >> 8) & 255) / 255,
            (integer & 255) / 255
        ];
    }

    function trimString(value) {
        return String(value || "").replace(/^\s+|\s+$/g, "");
    }

    function fastColorResultFile() {
        return new File(Folder.temp.fsName + "/clear_fast_color_result.txt");
    }

    function extensionFolder() {
        var storedPath;
        var scriptFile;
        var jsxFolder;
        try {
            storedPath = api._extensionPath || "";
            if (storedPath) {
                return new Folder(storedPath);
            }
        } catch (ignoreStoredExtensionFolder) {}
        try {
            scriptFile = new File($.fileName);
            jsxFolder = scriptFile.parent;
            if (jsxFolder && jsxFolder.parent) {
                return jsxFolder.parent;
            }
        } catch (ignoreExtensionFolder) {}
        return new Folder("D:/clear");
    }

    function readTextFile(file) {
        var value = "";
        try {
            if (file && file.exists && file.open("r")) {
                value = file.read();
                file.close();
            }
        } catch (ignoreRead) {
            try { file.close(); } catch (ignoreClose) {}
        }
        return value;
    }

    function applyColorToLayer(layer, color) {
        if (!layer) {
            return 0;
        }
        try {
            if (layer.property("ADBE Text Properties")) {
                return applyTextColor(layer, color);
            }
            if (layer.property("ADBE Root Vectors Group")) {
                return applyShapeColor(layer, color);
            }
            if (isSolidLayer(layer)) {
                return applySolidColor(layer, color);
            }
        } catch (ignoreUnsupportedColorLayer) {
            return 0;
        }
        return 0;
    }

    function applySolidColor(layer, color) {
        try {
            if (isSolidLayer(layer)) {
                layer.source.mainSource.color = color;
                return 1;
            }
        } catch (ignoreSolidColor) {}
        return 0;
    }

    function applyTextColor(layer, color) {
        var textGroup;
        var textProperty;
        var textDocument;
        try {
            textGroup = layer.property("ADBE Text Properties");
            textProperty = textGroup ? textGroup.property("ADBE Text Document") : null;
            if (!textProperty) {
                return 0;
            }
            textDocument = textProperty.value;
            textDocument.applyFill = true;
            textDocument.fillColor = color;
            textProperty.setValue(textDocument);
            return 1;
        } catch (ignoreTextColor) {}
        return 0;
    }

    function applyShapeColor(layer, color) {
        var contents;
        var changed;
        var fill;
        var colorProperty;
        try {
            contents = layer.property("ADBE Root Vectors Group");
            if (!contents) {
                return 0;
            }
            changed = updateShapeColors(contents, color);
            if (changed > 0) {
                return changed;
            }
            if (!contents.canAddProperty || !contents.canAddProperty("ADBE Vector Graphic - Fill")) {
                return 0;
            }
            fill = contents.addProperty("ADBE Vector Graphic - Fill");
            colorProperty = vectorColorProperty(fill, "ADBE Vector Fill Color");
            return setColorProperty(colorProperty, color);
        } catch (ignoreShapeColor) {}
        return 0;
    }

    function setColorProperty(property, color) {
        try {
            if (property && typeof property.setValue === "function") {
                property.setValue(color);
                return 1;
            }
        } catch (ignoreSetColor) {}
        return 0;
    }

    function vectorColorProperty(group, primaryName) {
        var colorProperty = null;
        try { colorProperty = group.property(primaryName); } catch (ignorePrimary) {}
        if (!colorProperty) {
            try { colorProperty = group.property("Color"); } catch (ignoreColor) {}
        }
        return colorProperty;
    }

    function updateShapeColors(group, color) {
        var property;
        var colorProperty;
        var enabled;
        var changed = 0;
        var i;
        for (i = 1; i <= group.numProperties; i += 1) {
            property = group.property(i);
            enabled = true;
            try { enabled = property.enabled !== false; } catch (ignoreEnabled) {}

            if (enabled && property.matchName === "ADBE Vector Graphic - Fill") {
                colorProperty = vectorColorProperty(property, "ADBE Vector Fill Color");
                changed += setColorProperty(colorProperty, color);
            }

            if (property.propertyType !== PropertyType.PROPERTY && property.numProperties) {
                changed += updateShapeColors(property, color);
            }
        }
        return changed;
    }

    function colorAudio() {
        var comp = activeComp();
        if (!comp) {
            return false;
        }
        return withUndo("CLEAR Color Audio", function () {
            var layer;
            var i;
            for (i = 1; i <= comp.numLayers; i += 1) {
                layer = comp.layer(i);
                if (layer.hasAudio && !layer.hasVideo) {
                    layer.label = 9;
                }
            }
            return true;
        });
    }

    function fadeInOut() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        var fadeSeconds = 0.5;
        if (!comp || !layers.length) {
            return false;
        }
        return withUndo("CLEAR Fade In Out", function () {
            var layer;
            var inTime;
            var outTime;
            var fadeInEnd;
            var fadeOutStart;
            var opacity;
            var audioLevels;
            var i;
            for (i = 0; i < layers.length; i += 1) {
                layer = layers[i];
                inTime = layer.inPoint;
                outTime = layer.outPoint;
                fadeInEnd = Math.min(inTime + fadeSeconds, (inTime + outTime) / 2);
                fadeOutStart = Math.max(outTime - fadeSeconds, (inTime + outTime) / 2);
                if (layer.hasVideo) {
                    opacity = layer.property("ADBE Transform Group").property("ADBE Opacity");
                    if (opacity) {
                        opacity.setValueAtTime(inTime, 0);
                        opacity.setValueAtTime(fadeInEnd, 100);
                        opacity.setValueAtTime(fadeOutStart, 100);
                        opacity.setValueAtTime(outTime, 0);
                    }
                }
                if (layer.hasAudio) {
                    audioLevels = layer.property("ADBE Audio Group").property("ADBE Audio Levels");
                    if (audioLevels) {
                        audioLevels.setValueAtTime(inTime, [-48, -48]);
                        audioLevels.setValueAtTime(fadeInEnd, [0, 0]);
                        audioLevels.setValueAtTime(fadeOutStart, [0, 0]);
                        audioLevels.setValueAtTime(outTime, [-48, -48]);
                    }
                }
            }
            return true;
        });
    }

    function transformText(mode) {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        if (!comp || !layers.length) {
            return false;
        }
        return withUndo("CLEAR Text Case", function () {
            var sourceText;
            var documentValue;
            var text;
            var i;
            for (i = 0; i < layers.length; i += 1) {
                sourceText = layers[i].property("ADBE Text Properties") ? layers[i].property("ADBE Text Properties").property("ADBE Text Document") : null;
                if (!sourceText) {
                    continue;
                }
                documentValue = sourceText.value;
                text = documentValue.text;
                if (mode === "lower") {
                    text = text.toLowerCase();
                } else if (mode === "upper") {
                    text = text.toUpperCase();
                } else {
                    text = text.toLowerCase().replace(/(^|[.!?]\s+|\r|\n)([a-z])/g, function (match, prefix, letter) {
                        return prefix + letter.toUpperCase();
                    });
                }
                documentValue.text = text;
                sourceText.setValue(documentValue);
            }
            return true;
        });
    }

    function sentenceCase() { return transformText("sentence"); }
    function lowerCase() { return transformText("lower"); }
    function upperCase() { return transformText("upper"); }

    function splitText() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        if (!comp || !layers.length) {
            return false;
        }
        return withUndo("CLEAR Split Text", function () {
            var layer;
            var sourceText;
            var sourceDocument;
            var originalText;
            var originalRect;
            var averageWidth;
            var duplicate;
            var duplicateText;
            var position;
            var value;
            var i;
            var c;
            for (i = 0; i < layers.length; i += 1) {
                layer = layers[i];
                sourceText = layer.property("ADBE Text Properties") ? layer.property("ADBE Text Properties").property("ADBE Text Document") : null;
                if (!sourceText) {
                    continue;
                }
                sourceDocument = sourceText.value;
                originalText = sourceDocument.text;
                if (!originalText || originalText.length < 2) {
                    continue;
                }
                originalRect = layer.sourceRectAtTime(comp.time, false);
                averageWidth = originalRect.width / originalText.length;
                for (c = originalText.length - 1; c >= 0; c -= 1) {
                    if (/\s/.test(originalText.charAt(c))) {
                        continue;
                    }
                    duplicate = layer.duplicate();
                    duplicate.name = originalText.charAt(c);
                    duplicateText = duplicate.property("ADBE Text Properties").property("ADBE Text Document");
                    value = duplicateText.value;
                    value.text = originalText.charAt(c);
                    duplicateText.setValue(value);
                    position = duplicate.property("ADBE Transform Group").property("ADBE Position");
                    value = position.value;
                    value[0] += (c * averageWidth) - (originalRect.width / 2) + (averageWidth / 2);
                    position.setValue(value);
                }
                layer.remove();
            }
            return true;
        });
    }

    function squarePen() {
        var comp = activeComp();
        if (!comp) {
            return false;
        }
        return withUndo("CLEAR Square Pen", function () {
            var layer = comp.layers.addShape();
            var contents = layer.property("ADBE Root Vectors Group");
            var rectangle = contents.addProperty("ADBE Vector Shape - Rect");
            var fill = contents.addProperty("ADBE Vector Graphic - Fill");
            layer.name = "Square";
            rectangle.property("ADBE Vector Rect Size").setValue([200, 200]);
            fill.property("ADBE Vector Fill Color").setValue([0.659, 0.333, 0.969]);
            layer.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width / 2, comp.height / 2]);
            return true;
        });
    }

    function roundCorner() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        if (!comp || !layers.length) {
            return false;
        }
        return withUndo("CLEAR Round Corner", function () {
            var contents;
            var roundness;
            var bounds;
            var i;
            for (i = 0; i < layers.length; i += 1) {
                contents = layers[i].property("ADBE Root Vectors Group");
                if (contents && contents.canAddProperty("ADBE Vector Filter - RC")) {
                    roundness = contents.addProperty("ADBE Vector Filter - RC");
                    try { roundness.property("ADBE Vector RoundCorner Radius").setValue(20); } catch (ignoreRadius) {}
                    continue;
                }
                bounds = getRoundCornerBounds(layers[i], comp.time);
                if (bounds) {
                    applyRoundCornerMask(layers[i], bounds, roundCornerMaskRadius(layers[i]));
                }
            }
            return true;
        });
    }

    function roundCornerMaskRadius(layer) {
        try {
            if (layer && layer.source && layer.source instanceof FootageItem &&
                    !(layer.source.mainSource instanceof SolidSource)) {
                return 70;
            }
        } catch (ignoreFootageRadius) {}
        return 20;
    }

    function getRoundCornerBounds(layer, time) {
        var rect;
        var width;
        var height;
        if (!layer || layer.locked) {
            return null;
        }
        try {
            if (layer instanceof TextLayer && layer.sourceRectAtTime) {
                rect = layer.sourceRectAtTime(time, false);
                if (rect && rect.width > 0 && rect.height > 0) {
                    return { left: rect.left, top: rect.top, width: rect.width, height: rect.height };
                }
            }
        } catch (ignoreTextBounds) {}
        try {
            if (layer.source && layer.source.width > 0 && layer.source.height > 0) {
                return { left: 0, top: 0, width: layer.source.width, height: layer.source.height };
            }
        } catch (ignoreSourceBounds) {}
        try {
            width = layer.width;
            height = layer.height;
            if (width > 0 && height > 0) {
                return { left: 0, top: 0, width: width, height: height };
            }
        } catch (ignoreLayerBounds) {}
        return null;
    }

    function applyRoundCornerMask(layer, bounds, requestedRadius) {
        var masks;
        var mask = null;
        var maskPath;
        var shape;
        var left = bounds.left;
        var top = bounds.top;
        var right = left + bounds.width;
        var bottom = top + bounds.height;
        var radius = Math.min(requestedRadius, bounds.width / 2, bounds.height / 2);
        var tangent = radius * 0.55228475;
        var existingMaskCount;
        var i;
        if (radius <= 0) {
            return false;
        }
        try { masks = layer.property("ADBE Mask Parade"); } catch (ignoreMasks) { masks = null; }
        if (!masks || !masks.canAddProperty("ADBE Mask Atom")) {
            return false;
        }
        existingMaskCount = masks.numProperties;
        for (i = 1; i <= masks.numProperties; i += 1) {
            if (masks.property(i).name === "CLEAR Round Corner") {
                mask = masks.property(i);
                break;
            }
        }
        if (!mask) {
            mask = masks.addProperty("ADBE Mask Atom");
            mask.name = "CLEAR Round Corner";
            try {
                mask.maskMode = existingMaskCount > 0 ? MaskMode.INTERSECT : MaskMode.ADD;
            } catch (ignoreMaskMode) {}
        }
        maskPath = mask.property("ADBE Mask Shape");
        if (!maskPath) {
            return false;
        }
        shape = new Shape();
        shape.closed = true;
        shape.vertices = [
            [left + radius, top],
            [right - radius, top],
            [right, top + radius],
            [right, bottom - radius],
            [right - radius, bottom],
            [left + radius, bottom],
            [left, bottom - radius],
            [left, top + radius]
        ];
        shape.inTangents = [
            [-tangent, 0], [0, 0], [0, -tangent], [0, 0],
            [tangent, 0], [0, 0], [0, tangent], [0, 0]
        ];
        shape.outTangents = [
            [0, 0], [tangent, 0], [0, 0], [0, tangent],
            [0, 0], [-tangent, 0], [0, 0], [0, -tangent]
        ];
        maskPath.setValue(shape);
        return true;
    }

    function addCamera() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        if (!comp) {
            return false;
        }
        return withUndo("CLEAR Add Camera", function () {
            var camera = comp.layers.addCamera("Camera 1", [comp.width / 2, comp.height / 2]);
            if (layers.length) {
                camera.inPoint = layers[0].inPoint;
                camera.outPoint = layers[0].outPoint;
                camera.moveBefore(layers[0]);
            }
            return true;
        });
    }

    function toggle3D() {
        api._threeDMode = !api._threeDMode;
        if (api._threeDMode) {
            rememberAllLayersFor3D();
            start3DModeTask();
        } else {
            stop3DModeTask();
        }
        return { enabled: api._threeDMode };
    }

    function get3DModeState() {
        if (api._threeDMode) {
            start3DModeTask();
        }
        return { enabled: api._threeDMode };
    }

    function start3DModeTask() {
        if (!api._threeDTaskId) {
            try { api._threeDTaskId = app.scheduleTask("CLEAR.enforce3DMode()", 350, true); } catch (ignoreSchedule) {}
        }
    }

    function stop3DModeTask() {
        if (api._threeDTaskId) {
            try { app.cancelTask(api._threeDTaskId); } catch (ignoreCancel) {}
            api._threeDTaskId = 0;
        }
    }

    function rememberAllLayersFor3D() {
        var comp;
        var item;
        var map;
        var i;
        var l;
        api._known3DLayers = {};
        api._threeDProjectReference = app.project;
        if (!app.project) {
            return;
        }
        for (i = 1; i <= app.project.numItems; i += 1) {
            item = app.project.item(i);
            if (!(item instanceof CompItem)) {
                continue;
            }
            comp = item;
            map = {};
            api._known3DLayers[getComp3DKey(comp)] = map;
            for (l = 1; l <= comp.numLayers; l += 1) {
                map[getLayer3DKey(comp.layer(l))] = true;
            }
        }
    }

    function enforce3DMode() {
        var pending = [];
        var item;
        var comp;
        var layer;
        var map;
        var key;
        var i;
        var l;
        if (!api._threeDMode || !app.project) {
            return { enabled: api._threeDMode };
        }
        if (api._threeDProjectReference !== app.project) {
            rememberAllLayersFor3D();
            return { enabled: true };
        }
        for (i = 1; i <= app.project.numItems; i += 1) {
            item = app.project.item(i);
            if (!(item instanceof CompItem)) {
                continue;
            }
            comp = item;
            key = getComp3DKey(comp);
            map = api._known3DLayers[key];
            if (!map) {
                map = {};
                api._known3DLayers[key] = map;
            }
            for (l = 1; l <= comp.numLayers; l += 1) {
                layer = comp.layer(l);
                key = getLayer3DKey(layer);
                if (!map[key]) {
                    map[key] = true;
                    pending.push(layer);
                }
            }
        }
        if (pending.length) {
            app.beginUndoGroup("CLEAR 3D Mode");
            for (i = 0; i < pending.length; i += 1) {
                try { pending[i].threeDLayer = true; } catch (ignoreUnsupported3D) {}
            }
            app.endUndoGroup();
        }
        return { enabled: true };
    }

    function getComp3DKey(comp) {
        var id;
        try { id = comp.id; } catch (ignoreCompId) {}
        return id !== undefined && id !== null ? "comp:" + id : "comp:" + comp.name;
    }

    function getLayer3DKey(layer) {
        var id;
        try { id = layer.id; } catch (ignoreLayerId) {}
        return id !== undefined && id !== null ? "layer:" + id : "layer:" + layer.index + ":" + layer.name;
    }

    function rememberLayerFor3D(comp, layer) {
        var compKey;
        var map;
        if (!api._threeDMode) {
            return;
        }
        compKey = getComp3DKey(comp);
        map = api._known3DLayers[compKey];
        if (!map) {
            map = {};
            api._known3DLayers[compKey] = map;
        }
        map[getLayer3DKey(layer)] = true;
    }

    function pngRender(options) {
        var comp = activeComp();
        var baseFolder;
        var outputFolder;
        var projectName;
        var frameNumber;
        var baseName;
        var output;
        var previousResolutionFactor;
        var suffix = 2;
        if (!comp) {
            return false;
        }
        return withUndo("CLEAR PNG Render", function () {
            try {
                previousResolutionFactor = comp.resolutionFactor;
                comp.resolutionFactor = [1, 1];
            } catch (ignoreResolutionFactor) {}
            if (options && options.outputFolder) {
                outputFolder = new Folder(options.outputFolder);
            } else {
                baseFolder = app.project.file ? app.project.file.parent : Folder.myDocuments;
                outputFolder = new Folder(baseFolder.fsName + "/CLEAR PNG");
            }
            if (!outputFolder.exists) {
                outputFolder.create();
            }
            projectName = app.project.file ? app.project.file.displayName.replace(/\.[^\.]+$/, "") : "Untitled Project";
            frameNumber = Math.round(comp.time * comp.frameRate);
            baseName = sanitizeFileName(projectName + " - " + comp.name + " - " + frameNumber);
            output = new File(outputFolder.fsName + "/" + baseName + ".png");
            while (output.exists) {
                output = new File(outputFolder.fsName + "/" + baseName + " " + suffix + ".png");
                suffix += 1;
            }
            try {
                comp.saveFrameToPng(comp.time, output);
            } finally {
                if (previousResolutionFactor) {
                    try { comp.resolutionFactor = previousResolutionFactor; } catch (ignoreRestoreResolutionFactor) {}
                }
            }
            return output.fsName;
        });
    }

    function sanitizeFileName(value) {
        return String(value).replace(/[\\\/:*?"<>|]/g, "-");
    }

    function getEffects() {
        var result = [];
        var effects = app.effects;
        var item;
        var i;
        if (!effects) {
            return result;
        }
        for (i = 0; i < effects.length; i += 1) {
            item = effects[i];
            result.push({
                name: item.displayName || item.matchName || "Effect",
                matchName: item.matchName || item.displayName,
                category: item.category || "Effect"
            });
        }
        return result;
    }

    function applyEffect(matchName, displayName) {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        if (!layers.length) {
            layers = quickSearchCachedLayers(comp);
            if (!comp && layers.length) {
                comp = api._quickSearchCompRef;
            }
        }
        if (!comp) {
            return { applied: 0, error: "noComp" };
        }
        if (!layers.length) {
            return { applied: 0, error: "noSelection" };
        }
        if (!matchName) {
            return { applied: 0, error: "missingEffect" };
        }
        return withUndo("CLEAR Apply Effect", function () {
            var effects;
            var added;
            var applied = 0;
            var affectedLayers = [];
            var addedEffects = [];
            var i;
            for (i = 0; i < layers.length; i += 1) {
                if (isAudioOnlyLayer(layers[i]) || isCameraOrLightLayer(layers[i])) {
                    continue;
                }
                try { effects = layers[i].property("ADBE Effect Parade"); } catch (ignoreEffects) { effects = null; }
                added = null;
                if (effects) {
                    try { added = effects.addProperty(matchName); } catch (ignoreMatchName) { added = null; }
                    if (!added && displayName && displayName !== matchName) {
                        try { added = effects.addProperty(displayName); } catch (ignoreDisplayName) { added = null; }
                    }
                    if (added) {
                        applied += 1;
                        affectedLayers.push(layers[i]);
                        addedEffects.push(added);
                    }
                }
            }
            if (applied > 0) {
                selectAppliedEffects(comp, affectedLayers, addedEffects);
                openEffectControlsPanel();
            }
            return { applied: applied, error: applied > 0 ? "" : "noValidLayers" };
        });
    }

    function selectAppliedEffects(comp, layers, effects) {
        var i;
        var layerCount;
        if (!comp || !layers || !layers.length) {
            return;
        }
        try {
            for (i = 1, layerCount = comp.numLayers; i <= layerCount; i += 1) {
                comp.layer(i).selected = false;
            }
        } catch (ignoreClearSelection) {}
        for (i = 0; i < layers.length; i += 1) {
            try { layers[i].selected = true; } catch (ignoreLayerSelect) {}
        }
        for (i = 0; i < effects.length; i += 1) {
            try { effects[i].selected = true; } catch (ignoreEffectSelect) {}
        }
    }

    function quickSearchCachedLayers(comp) {
        var result = [];
        var cachedComp = api._quickSearchCompRef || null;
        var indexes = api._quickSearchLayerIndexes || [];
        var targetComp = comp || cachedComp;
        var i;
        var layer;
        if (!targetComp || targetComp !== cachedComp || !indexes.length) {
            return result;
        }
        for (i = 0; i < indexes.length; i += 1) {
            try {
                layer = targetComp.layer(indexes[i]);
                if (layer) {
                    result.push(layer);
                }
            } catch (ignoreCachedLayer) {}
        }
        return result;
    }

    function isAudioOnlyLayer(layer) {
        try { return Boolean(layer.hasAudio && !layer.hasVideo); } catch (ignoreLayerAudio) {}
        try { return Boolean(layer.source && layer.source.hasAudio && !layer.source.hasVideo); } catch (ignoreSourceAudio) {}
        return false;
    }

    function isCameraOrLightLayer(layer) {
        var matchName = "";
        try { matchName = layer.matchName || ""; } catch (ignoreMatchName) {}
        return matchName === "ADBE Camera Layer" || matchName === "ADBE Light Layer";
    }

    function getSelectedEffects() {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        var map = {};
        var order = [];
        var effects;
        var effect;
        var key;
        var i;
        var e;
        if (!comp || !layers.length) {
            return [];
        }
        for (i = 0; i < layers.length; i += 1) {
            effects = layers[i].property("ADBE Effect Parade");
            if (!effects) {
                continue;
            }
            for (e = 1; e <= effects.numProperties; e += 1) {
                effect = effects.property(e);
                key = effect.matchName || effect.name;
                if (!map[key]) {
                    map[key] = { name: effect.name, matchName: key, count: 0 };
                    order.push(key);
                }
                map[key].count += 1;
            }
        }
        effects = [];
        for (i = 0; i < order.length; i += 1) {
            effects.push(map[order[i]]);
        }
        effects.sort(function (a, b) {
            return String(a.name).toLowerCase() < String(b.name).toLowerCase() ? -1 : 1;
        });
        return effects;
    }

    function deleteEffects(matchNames) {
        var comp = activeComp();
        var layers = selectedLayers(comp);
        var wanted = {};
        var effects;
        var effect;
        var key;
        var i;
        var e;
        if (!comp || !layers.length || !matchNames || !matchNames.length) {
            return false;
        }
        for (i = 0; i < matchNames.length; i += 1) {
            wanted[matchNames[i]] = true;
        }
        return withUndo("CLEAR Delete Effects", function () {
            for (i = 0; i < layers.length; i += 1) {
                effects = layers[i].property("ADBE Effect Parade");
                if (!effects) {
                    continue;
                }
                for (e = effects.numProperties; e >= 1; e -= 1) {
                    effect = effects.property(e);
                    key = effect.matchName || effect.name;
                    if (wanted[key]) {
                        try { effect.remove(); } catch (ignoreMissing) {}
                    }
                }
            }
            return true;
        });
    }

    function getProjectState() {
        var project = app.project;
        var comp;
        var selected;
        var activityParts = [];
        var projectFile = null;
        var projectPath = "";
        var projectName = "Untitled Project";
        var fileKey;
        var i;
        if (!project) {
            api._projectReference = null;
            return { open: false, key: "", sessionId: "", name: "", activityToken: "" };
        }
        if (api._projectReference !== project) {
            api._projectReference = project;
            api._projectSerial += 1;
        }
        try { projectFile = project.file; } catch (ignoreProjectFile) {}
        if (projectFile) {
            try { projectPath = projectFile.fsName || ""; } catch (ignoreProjectPath) {}
            try { projectName = projectFile.displayName || projectName; } catch (ignoreProjectDisplayName) {}
        } else {
            try { projectName = project.name || projectName; } catch (ignoreProjectName) {}
        }
        fileKey = projectPath || "unsaved:" + api._projectSerial + ":" + projectName;
        comp = activeComp();
        try { activityParts.push(project.numItems); } catch (ignoreItemCount) {}
        if (comp) {
            try { activityParts.push(comp.id); } catch (ignoreCompId) {}
            try { activityParts.push(roundNumber(comp.time, 3)); } catch (ignoreCompTime) {}
            try {
                selected = comp.selectedLayers;
                for (i = 0; i < selected.length; i += 1) {
                    activityParts.push(selected[i].index);
                }
            } catch (ignoreSelectedLayers) {}
        }
        return {
            open: true,
            key: fileKey,
            path: projectPath,
            saved: Boolean(projectPath),
            sessionId: String(api._projectSerial),
            name: projectName,
            activityToken: activityParts.join("|")
        };
    }

    function getProjectTime(projectPath) {
        var data = readProjectTimeData();
        var entry = projectPath && data[projectPath] ? data[projectPath] : null;
        var seconds = entry ? Number(entry.totalSeconds) : 0;
        return isFinite(seconds) && seconds > 0 ? Math.floor(seconds) : 0;
    }

    function setProjectTime(projectPath, totalSeconds) {
        var data;
        var seconds;
        if (!projectPath) {
            return false;
        }
        seconds = Math.max(0, Math.floor(Number(totalSeconds) || 0));
        data = readProjectTimeData();
        data[projectPath] = { totalSeconds: seconds };
        return writeProjectTimeData(data);
    }

    function projectTimeFile() {
        var folder = new Folder(Folder.userData.fsName + "/CLEAR/data");
        if (!folder.exists) {
            try { folder.create(); } catch (ignoreCreate) {}
        }
        return new File(folder.fsName + "/project_time.json");
    }

    function readProjectTimeData() {
        var file = projectTimeFile();
        var text;
        if (!file.exists || !file.open("r")) {
            return {};
        }
        file.encoding = "UTF-8";
        text = file.read();
        file.close();
        if (!text) {
            return {};
        }
        try {
            return parseJSON(text) || {};
        } catch (ignoreInvalidData) {
            return {};
        }
    }

    function writeProjectTimeData(data) {
        var file = projectTimeFile();
        if (!file.open("w")) {
            return false;
        }
        file.encoding = "UTF-8";
        file.write(stringify(data));
        file.close();
        return true;
    }

    function roundNumber(value, places) {
        var factor = Math.pow(10, places || 0);
        return Math.round(value * factor) / factor;
    }

    function parseJSON(value) {
        if (typeof JSON !== "undefined" && JSON.parse) {
            return JSON.parse(value);
        }
        return eval("(" + value + ")");
    }

    function stringify(value) {
        if (typeof JSON !== "undefined" && JSON.stringify) {
            return JSON.stringify(value);
        }
        if (value === null) { return "null"; }
        if (value === true) { return "true"; }
        if (value === false) { return "false"; }
        if (typeof value === "number") { return isFinite(value) ? String(value) : "null"; }
        if (typeof value === "string") { return "\"" + escapeString(value) + "\""; }
        if (value instanceof Array) {
            var arrayParts = [];
            var i;
            for (i = 0; i < value.length; i += 1) {
                arrayParts.push(stringify(value[i]));
            }
            return "[" + arrayParts.join(",") + "]";
        }
        var objectParts = [];
        var key;
        for (key in value) {
            if (value.hasOwnProperty(key) && typeof value[key] !== "undefined" && typeof value[key] !== "function") {
                objectParts.push("\"" + escapeString(key) + "\":" + stringify(value[key]));
            }
        }
        return "{" + objectParts.join(",") + "}";
    }

    function escapeString(value) {
        return String(value)
            .replace(/\\/g, "\\\\")
            .replace(/\"/g, "\\\"")
            .replace(/\r/g, "\\r")
            .replace(/\n/g, "\\n")
            .replace(/\t/g, "\\t");
    }
}(CLEAR));
