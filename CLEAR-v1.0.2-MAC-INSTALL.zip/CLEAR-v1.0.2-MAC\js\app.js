(function () {
    "use strict";

    var config = window.CLEAR_CONFIG;
    var bridge = window.CLEAR_BRIDGE;
    var content = document.getElementById("panel-content");
    var tooltip = document.getElementById("tooltip");
    var searchResults = document.getElementById("search-results");
    var searchFavoriteMenu = document.getElementById("search-favorite-menu");
    var searchFavoriteAction = document.getElementById("search-favorite-action");
    var toolContextMenu = document.getElementById("tool-context-menu");
    var removeToolAction = document.getElementById("remove-tool-action");
    var parentColorAction = document.getElementById("parent-color-action");
    var parentOrganizeAction = document.getElementById("parent-organize-action");
    var anchorInlineAction = document.getElementById("anchor-inline-action");
    var anchorPopupAction = document.getElementById("anchor-popup-action");
    var quickColorsContextMenu = document.getElementById("quick-colors-context-menu");
    var editQuickColorsAction = document.getElementById("edit-quick-colors-action");
    var lockQuickColorsAction = document.getElementById("lock-quick-colors-action");
    var feedbackMenu = document.getElementById("feedback-menu");
    var feedbackTelegramAction = document.getElementById("feedback-telegram-action");
    var feedbackInstagramAction = document.getElementById("feedback-instagram-action");
    var feedbackDiscordAction = document.getElementById("feedback-discord-action");
    var modalBackdrop = document.getElementById("modal-backdrop");
    var modalTitle = document.getElementById("modal-title");
    var modalBody = document.getElementById("modal-body");
    var modalFooter = document.getElementById("modal-footer");
    var sessionTimeEl = document.getElementById("session-time");
    var totalTimeEl = document.getElementById("total-time");
    var statusLine = document.getElementById("status-line");
    var quickColorsGrid = document.getElementById("quick-colors-grid");
    var quickColorsPanel = document.getElementById("quick-colors-panel");
    var quickColorsResizeHandle = document.getElementById("quick-colors-resize-handle");
    var toolMap = {};
    var allTools = [];
    var aeEffects = [];
    var tooltipTimer = null;
    var statusTimer = null;
    var activeSearchIndex = 0;
    var visibleSearchEntries = [];
    var currentSearchInput = null;
    var resizeFrame = null;
    var resizeSettleTimer = null;
    var forceResponsiveSizing = false;
    var lastResponsiveWidth = -1;
    var lastResponsiveHeight = -1;
    var lastPointerX = Math.round(window.innerWidth / 2);
    var lastPointerY = Math.round(window.innerHeight / 2);
    var markerNativeAvailable = false;
    var lastMarkerCommandId = "";
    var markerSocket = null;
    var markerSocketOpen = false;
    var lastQuickSearchCommandId = "";
    var lastQuickSelectionRequestId = "";
    var favoriteContextEntry = null;
    var toolContextTarget = null;
    var quickColorDefaults = [
        "#FE0000", "#FF8000", "#FFFF80", "#5DDE87", "#45C8F0",
        "#5B7CFA", "#8000FF", "#F15BB5", "#FFFFFF", "#000000"
    ];
    var quickColorLegacyDefaults = [
        "#FF5D5D", "#FFB84D", "#FFE66D", "#5DDE87", "#45C8F0",
        "#5B7CFA", "#A855F7", "#F15BB5", "#FFFFFF", "#1F2430"
    ];
    var quickColorsResizing = false;
    var quickColorsResizeStartY = 0;
    var quickColorsResizeStartHeight = 0;
    var alignSelectionCount = 0;
    var anchorPointPopup = null;
    var anchorPointTrigger = null;

    var timerState = {
        projectOpen: false,
        projectKey: "",
        projectPath: "",
        projectSaved: false,
        projectSessionId: "",
        projectName: "",
        sessionMs: 0,
        baseTotalMs: 0,
        totalMs: 0,
        lastTick: Date.now(),
        lastActivity: Date.now(),
        lastHostToken: "",
        appActive: true,
        persistElapsed: 0
    };

    function createElement(tag, className, text) {
        var element = document.createElement(tag);
        if (className) {
            element.className = className;
        }
        if (text !== undefined && text !== null) {
            element.textContent = text;
        }
        return element;
    }

    function setIcon(element, path) {
        element.setAttribute("data-icon", path);
        element.style.backgroundImage = "url(\"" + path + "\")";
    }

    function hydrateIcons(root) {
        var icons = (root || document).querySelectorAll("[data-icon]");
        var i;
        for (i = 0; i < icons.length; i += 1) {
            setIcon(icons[i], icons[i].getAttribute("data-icon"));
        }
    }

    function renderPanel() {
        var sectionIndex;
        var categorized = categoryViewEnabled();
        toolMap = {};
        allTools = [];
        currentSearchInput = null;
        closeToolContextMenu();
        content.innerHTML = "";
        content.classList.toggle("is-flat-view", !categorized);

        if (categorized) {
            for (sectionIndex = 0; sectionIndex < config.sections.length; sectionIndex += 1) {
                content.appendChild(renderSection(config.sections[sectionIndex]));
            }
        } else {
            content.appendChild(renderFlatTools());
        }

        hydrateIcons(document);
        scheduleResponsiveToolSizing(true);
        refreshQuickSearchIndex();
        refresh3DModeState();
        refreshParentLinkState();
        refreshAlignToolbarState();
    }

    function quickSearchEnabled() {
        return false;
    }

    function quickSearchHotkey() {
        return localStorage.getItem("clear:quickSearchHotkey") || "Ctrl+Space";
    }

    function showFavoritesFirst() {
        return true;
    }

    function accentHue() {
        var value = Number(localStorage.getItem("clear:accentHue"));
        return isFinite(value) ? Math.max(0, Math.min(360, value)) : 271;
    }

    function hslToRgb(hue, saturation, lightness) {
        var c = (1 - Math.abs(2 * lightness - 1)) * saturation;
        var x = c * (1 - Math.abs((hue / 60) % 2 - 1));
        var m = lightness - c / 2;
        var rgb;
        if (hue < 60) { rgb = [c, x, 0]; }
        else if (hue < 120) { rgb = [x, c, 0]; }
        else if (hue < 180) { rgb = [0, c, x]; }
        else if (hue < 240) { rgb = [0, x, c]; }
        else if (hue < 300) { rgb = [x, 0, c]; }
        else { rgb = [c, 0, x]; }
        return [
            Math.round((rgb[0] + m) * 255),
            Math.round((rgb[1] + m) * 255),
            Math.round((rgb[2] + m) * 255)
        ];
    }

    function rgbHex(rgb) {
        function part(value) { return (value < 16 ? "0" : "") + value.toString(16); }
        return "#" + part(rgb[0]) + part(rgb[1]) + part(rgb[2]);
    }

    function applyAccentTheme(hue, syncNative) {
        var normalized = Math.max(0, Math.min(360, Number(hue) || 0));
        var accent = hslToRgb(normalized, 0.91, 0.65);
        var bright = hslToRgb(normalized, 1, 0.71);
        var root = document.documentElement.style;
        root.setProperty("--accent", rgbHex(accent));
        root.setProperty("--accent-bright", rgbHex(bright));
        root.setProperty("--accent-rgb", accent.join(", "));
        root.setProperty("--accent-bright-rgb", bright.join(", "));
        root.setProperty("--accent-hue-shift", (normalized - 271) + "deg");
        if (syncNative) {
            bridge.setQuickSearchAccent(rgbHex(accent));
        }
    }

    function normalizeQuickColor(value, fallback) {
        var match = /^#?([0-9a-f]{6})$/i.exec(String(value || ""));
        return match ? "#" + match[1].toUpperCase() : fallback;
    }

    function quickColorsState() {
        var stored;
        var state;
        var total;
        var colors = [];
        var legacy = true;
        var i;
        try { stored = JSON.parse(localStorage.getItem("clear:quickColors") || "{}"); } catch (ignoreQuickColors) { stored = {}; }
        state = stored && typeof stored === "object" ? stored : {};
        state.rows = Math.max(1, Math.min(10, parseInt(state.rows, 10) || 2));
        state.columns = Math.max(1, Math.min(20, parseInt(state.columns, 10) || 5));
        total = state.rows * state.columns;
        if (state.version !== 2 && state.colors && state.colors.length) {
            for (i = 0; i < state.colors.length; i += 1) {
                if (normalizeQuickColor(state.colors[i], "") !== quickColorLegacyDefaults[i % quickColorLegacyDefaults.length]) {
                    legacy = false;
                    break;
                }
            }
            if (legacy) {
                state.colors = [];
            }
        }
        for (i = 0; i < total; i += 1) {
            colors.push(normalizeQuickColor(
                state.colors && state.colors[i],
                quickColorDefaults[i % quickColorDefaults.length]
            ));
        }
        state.colors = colors;
        return state;
    }

    function saveQuickColorsState(state) {
        localStorage.setItem("clear:quickColors", JSON.stringify({
            version: 2,
            rows: state.rows,
            columns: state.columns,
            colors: state.colors
        }));
    }

    function quickColorsEnabled() {
        return localStorage.getItem("clear:quickColorsEnabled") !== "0";
    }

    function quickColorScale() {
        var scale = parseFloat(localStorage.getItem("clear:quickColorScale"));
        return isFinite(scale) ? Math.max(0.35, Math.min(2.5, scale)) : 1;
    }

    function quickColorsSizeLocked() {
        return localStorage.getItem("clear:quickColorsSizeLocked") === "1";
    }

    function maximumQuickColorsHeight() {
        var header = document.querySelector(".app-header");
        var footer = document.querySelector(".app-footer");
        return Math.max(70, window.innerHeight -
            (header ? header.offsetHeight : 0) -
            (footer ? footer.offsetHeight : 0) - 48);
    }

    function applySavedQuickColorsHeight() {
        var saved = parseInt(localStorage.getItem("clear:quickColorsHeight"), 10);
        if (!saved) {
            quickColorsPanel.classList.remove("is-resized");
            quickColorsPanel.style.removeProperty("--quick-colors-height");
            return;
        }
        saved = Math.max(42, Math.min(maximumQuickColorsHeight(), saved));
        quickColorsPanel.classList.add("is-resized");
        quickColorsPanel.style.setProperty("--quick-colors-height", saved + "px");
    }

    function renderQuickColors() {
        var state = quickColorsState();
        var button;
        var i;
        quickColorsPanel.classList.toggle("is-disabled", !quickColorsEnabled());
        quickColorsPanel.classList.toggle("is-size-locked", quickColorsSizeLocked());
        applySavedQuickColorsHeight();
        quickColorsGrid.innerHTML = "";
        for (i = 0; i < state.colors.length; i += 1) {
            button = createElement("button", "quick-color-slot");
            button.type = "button";
            button.setAttribute("data-quick-color", state.colors[i]);
            button.setAttribute("data-tooltip", state.colors[i]);
            button.setAttribute("aria-label", "Apply " + state.colors[i]);
            button.style.setProperty("--slot-color", state.colors[i]);
            button.addEventListener("click", function () {
                bridge.call("applyQuickColor", [this.getAttribute("data-quick-color")], function () {});
            });
            quickColorsGrid.appendChild(button);
        }
        hydrateIcons(quickColorsGrid);
        updateQuickColorLayout();
        scheduleResponsiveToolSizing(true);
    }

    function bindQuickColorsResize() {
        quickColorsResizeHandle.addEventListener("contextmenu", function (event) {
            event.preventDefault();
        });
        quickColorsResizeHandle.addEventListener("mousedown", function (event) {
            if (event.button !== 0 || !quickColorsEnabled() || quickColorsSizeLocked()) {
                return;
            }
            event.preventDefault();
            hideTooltip();
            quickColorsResizing = true;
            quickColorsResizeStartY = event.clientY;
            quickColorsResizeStartHeight = quickColorsPanel.offsetHeight;
            document.body.classList.add("is-resizing-quick-colors");
        });
        quickColorsPanel.addEventListener("contextmenu", function (event) {
            if (!quickColorsEnabled()) {
                return;
            }
            event.preventDefault();
            event.stopPropagation();
            openQuickColorsContextMenu(event.clientX, event.clientY);
        });
        quickColorsPanel.addEventListener("wheel", function (event) {
            var scale;
            if (!event.ctrlKey || !quickColorsEnabled() || quickColorsSizeLocked()) {
                return;
            }
            event.preventDefault();
            event.stopPropagation();
            scale = quickColorScale() + (event.deltaY < 0 ? 0.08 : -0.08);
            scale = Math.max(0.35, Math.min(2.5, Math.round(scale * 100) / 100));
            localStorage.setItem("clear:quickColorScale", String(scale));
            updateQuickColorLayout();
            scheduleResponsiveToolSizing(true);
        }, false);
        document.addEventListener("mousemove", function (event) {
            var height;
            if (!quickColorsResizing) {
                return;
            }
            event.preventDefault();
            height = quickColorsResizeStartHeight + (quickColorsResizeStartY - event.clientY);
            height = Math.max(42, Math.min(maximumQuickColorsHeight(), height));
            quickColorsPanel.classList.add("is-resized");
            quickColorsPanel.style.setProperty("--quick-colors-height", height + "px");
            scheduleResponsiveToolSizing(true);
        });
        document.addEventListener("mouseup", function () {
            if (!quickColorsResizing) {
                return;
            }
            quickColorsResizing = false;
            document.body.classList.remove("is-resizing-quick-colors");
            localStorage.setItem("clear:quickColorsHeight", String(quickColorsPanel.offsetHeight));
        });
    }

    function openQuickColorsContextMenu(x, y) {
        hideTooltip();
        closeToolContextMenu();
        closeSearchFavoriteMenu();
        lockQuickColorsAction.textContent = quickColorsSizeLocked() ? "Unlock Size" : "Lock Size";
        quickColorsContextMenu.classList.add("is-open");
        quickColorsContextMenu.setAttribute("aria-hidden", "false");
        quickColorsContextMenu.style.left = Math.max(6, Math.min(x, window.innerWidth - 110)) + "px";
        quickColorsContextMenu.style.top = Math.max(6, Math.min(y, window.innerHeight - 42)) + "px";
    }

    function closeQuickColorsContextMenu() {
        quickColorsContextMenu.classList.remove("is-open");
        quickColorsContextMenu.setAttribute("aria-hidden", "true");
    }

    function toggleQuickColorsSizeLock() {
        var locked = !quickColorsSizeLocked();
        localStorage.setItem("clear:quickColorsSizeLocked", locked ? "1" : "0");
        quickColorsPanel.classList.toggle("is-size-locked", locked);
        closeQuickColorsContextMenu();
    }

    function updateQuickColorLayout() {
        var state;
        var width;
        var gap;
        var total;
        var targetColumns;
        var baseCellSize;
        var baseGridHeight;
        var heightFactor = 1;
        var columns = 1;
        var distance;
        var bestDistance = Number.MAX_VALUE;
        var candidate;
        if (!quickColorsGrid) {
            return;
        }
        state = quickColorsState();
        width = quickColorsGrid.clientWidth;
        if (width <= 0) {
            return;
        }
        gap = Math.max(2, Math.min(6, width / (state.columns * 10)));
        total = state.colors.length;
        baseCellSize = (width - gap * (state.columns - 1)) / state.columns;
        baseGridHeight = baseCellSize * state.rows + gap * (state.rows - 1);
        if (quickColorsPanel.classList.contains("is-resized") && quickColorsGrid.clientHeight > 0) {
            heightFactor = baseGridHeight / quickColorsGrid.clientHeight;
        }
        targetColumns = Math.max(1, Math.min(total,
            Math.round((state.columns / quickColorScale()) * heightFactor)));
        for (candidate = 1; candidate <= total; candidate += 1) {
            if (total % candidate !== 0) {
                continue;
            }
            distance = Math.abs(candidate - targetColumns);
            if (distance < bestDistance || (distance === bestDistance && candidate > columns)) {
                columns = candidate;
                bestDistance = distance;
            }
        }
        gap = Math.max(2, Math.min(6, width / (columns * 10)));
        quickColorsGrid.style.gridTemplateColumns = "repeat(" + columns + ", minmax(0, 1fr))";
        quickColorsGrid.style.justifyContent = "stretch";
        quickColorsGrid.style.setProperty("--quick-color-gap", gap + "px");
    }

    function populateQuickColorEditor(editor) {
        var state = quickColorsState();
        var row;
        var label;
        var button;
        var i;
        editor.innerHTML = "";
        for (i = 0; i < state.colors.length; i += 1) {
            row = createElement("div", "quick-color-edit-row");
            label = createElement("span", "removed-tool-name", "Slot " + (i + 1) + "  " + state.colors[i]);
            button = createElement("button", "quick-color-edit-button");
            button.type = "button";
            button.setAttribute("data-color-index", String(i));
            button.setAttribute("aria-label", "Edit Quick Color slot " + (i + 1));
            button.style.setProperty("--slot-color", state.colors[i]);
            button.addEventListener("click", function () {
                var index = Number(this.getAttribute("data-color-index"));
                var current = quickColorsState();
                bridge.call("pickQuickColor", [current.colors[index]], function (result) {
                    var picked = result && result.ok ? result.value : "";
                    var updated;
                    if (!picked) {
                        return;
                    }
                    updated = quickColorsState();
                    updated.colors[index] = normalizeQuickColor(picked, updated.colors[index]);
                    saveQuickColorsState(updated);
                    renderQuickColors();
                    populateQuickColorEditor(editor);
                });
            });
            row.appendChild(label);
            row.appendChild(button);
            editor.appendChild(row);
        }
    }

    function syncQuickSearchSettings() {
        bridge.setQuickSearchSettings(quickSearchEnabled(), quickSearchHotkey(), showFavoritesFirst());
    }

    function refreshQuickSearchIndex() {
        var index = [];
        var section;
        var tool;
        var effect;
        var s;
        var t;
        var e;
        for (s = 0; s < config.sections.length; s += 1) {
            section = config.sections[s];
            for (t = 0; t < section.tools.length; t += 1) {
                tool = section.tools[t];
                if (isToolHidden(tool.id)) {
                    continue;
                }
                index.push({
                    id: "tool:" + tool.id,
                    type: "tool",
                    name: tool.name,
                    command: tool.id,
                    category: section.title
                });
            }
        }
        for (e = 0; e < aeEffects.length; e += 1) {
            effect = aeEffects[e];
            index.push({
                id: "effect:" + (effect.matchName || effect.name),
                type: "effect",
                name: effect.name,
                command: effect.matchName || effect.name,
                category: effect.category || "Effects"
            });
        }
        bridge.writeQuickSearchIndex(JSON.stringify(index));
    }

    function categoryViewEnabled() {
        return localStorage.getItem("clear:categoryView") !== "0";
    }

    function hiddenToolIds() {
        var value;
        try {
            value = JSON.parse(localStorage.getItem("clear:hiddenTools") || "[]");
            return value instanceof Array ? value : [];
        } catch (ignoreHiddenTools) {}
        return [];
    }

    function saveHiddenToolIds(ids) {
        localStorage.setItem("clear:hiddenTools", JSON.stringify(ids || []));
    }

    function isToolHidden(id) {
        return hiddenToolIds().indexOf(id) >= 0;
    }

    function findConfiguredTool(id) {
        var sectionIndex;
        var toolIndex;
        if (id === "anchorPointGrid") {
            return { id: id, name: "Anchor Point Grid", icon: "icons/anchor points.svg" };
        }
        if (id === "alignToolbar") {
            return { id: id, name: "Align", icon: "icons/align 1.svg" };
        }
        for (sectionIndex = 0; sectionIndex < config.sections.length; sectionIndex += 1) {
            for (toolIndex = 0; toolIndex < config.sections[sectionIndex].tools.length; toolIndex += 1) {
                if (config.sections[sectionIndex].tools[toolIndex].id === id) {
                    return config.sections[sectionIndex].tools[toolIndex];
                }
            }
        }
        return null;
    }

    function registerTool(tool, grid) {
        if (isToolHidden(tool.id)) {
            return;
        }
        toolMap[tool.id] = tool;
        allTools.push(tool);
        grid.appendChild(renderToolButton(tool));
    }

    function renderFlatTools() {
        var wrapper = createElement("div", "flat-tools-view");
        var grid = createElement("div", "tool-grid flat-tool-grid");
        var section;
        var sectionIndex;
        var toolIndex;

        for (sectionIndex = 0; sectionIndex < config.sections.length; sectionIndex += 1) {
            section = config.sections[sectionIndex];
            for (toolIndex = 0; toolIndex < section.tools.length; toolIndex += 1) {
                registerTool(section.tools[toolIndex], grid);
            }
        }
        if (!isToolHidden("anchorPointGrid")) {
            grid.appendChild(renderAnchorPointControl());
        }
        wrapper.appendChild(grid);
        if (!isToolHidden("alignToolbar")) {
            wrapper.appendChild(renderAlignToolbar());
        }
        return wrapper;
    }

    function renderSection(section) {
        var wrapper = createElement("section", "tool-section");
        var toggle = createElement("button", "section-toggle");
        var heading = createElement("span", "section-heading");
        var headingIcon = createElement("span", "svg-icon");
        var headingText = createElement("span", "", section.title);
        var chevron = createElement("span", "chevron");
        var sectionContent = createElement("div", "section-content");
        var grid = createElement("div", "tool-grid");
        var collapsed = localStorage.getItem("clear:collapsed:" + section.id) === "1";
        var i;

        wrapper.setAttribute("data-section", section.id);
        if (collapsed) {
            wrapper.classList.add("is-collapsed");
        }

        toggle.type = "button";
        toggle.setAttribute("aria-expanded", collapsed ? "false" : "true");
        toggle.setAttribute("aria-label", (collapsed ? "Expand " : "Collapse ") + section.title);
        setIcon(headingIcon, section.icon);
        heading.appendChild(headingIcon);
        heading.appendChild(headingText);
        toggle.appendChild(heading);
        toggle.appendChild(chevron);
        toggle.addEventListener("click", function () {
            var isCollapsed = wrapper.classList.toggle("is-collapsed");
            toggle.setAttribute("aria-expanded", isCollapsed ? "false" : "true");
            toggle.setAttribute("aria-label", (isCollapsed ? "Expand " : "Collapse ") + section.title);
            localStorage.setItem("clear:collapsed:" + section.id, isCollapsed ? "1" : "0");
            closeSearch();
        });

        for (i = 0; i < section.tools.length; i += 1) {
            registerTool(section.tools[i], grid);
        }

        if (section.id === "shape") {
            if (!isToolHidden("anchorPointGrid")) {
                grid.appendChild(renderAnchorPointControl());
            }
            sectionContent.appendChild(grid);
            if (!isToolHidden("alignToolbar")) {
                sectionContent.appendChild(renderAlignToolbar());
            }
        } else {
            sectionContent.appendChild(grid);
        }
        wrapper.appendChild(toggle);
        wrapper.appendChild(sectionContent);
        return wrapper;
    }

    function anchorPointViewMode() {
        return localStorage.getItem("clear:anchorPointView") === "popup" ? "popup" : "inline";
    }

    function anchorPointPositions() {
        return [
            { id: "top-left", name: "Top Left Anchor" },
            { id: "top-center", name: "Top Center Anchor" },
            { id: "top-right", name: "Top Right Anchor" },
            { id: "middle-left", name: "Middle Left Anchor" },
            { id: "center", name: "Center Anchor" },
            { id: "middle-right", name: "Middle Right Anchor" },
            { id: "bottom-left", name: "Bottom Left Anchor" },
            { id: "bottom-center", name: "Bottom Center Anchor" },
            { id: "bottom-right", name: "Bottom Right Anchor" }
        ];
    }

    function appendAnchorPointDots(container) {
        var positions = anchorPointPositions();
        var button;
        var i;
        for (i = 0; i < positions.length; i += 1) {
            button = createElement("button", "anchor-point-dot");
            button.type = "button";
            button.setAttribute("data-anchor-position", positions[i].id);
            button.setAttribute("data-tooltip", positions[i].name);
            button.setAttribute("aria-label", positions[i].name);
            button.addEventListener("click", handleAnchorPointClick);
            container.appendChild(button);
        }
    }

    function renderAnchorPointControl() {
        var control = createElement("div", "anchor-point-control");
        var launcher;
        var icon;
        control.addEventListener("contextmenu", function (event) {
            event.preventDefault();
            event.stopPropagation();
            openToolContextMenu({ id: "anchorPointGrid", name: "Anchor Point Grid" }, event.clientX, event.clientY);
        });
        if (anchorPointViewMode() === "popup") {
            control.classList.add("is-popup-mode");
            launcher = createElement("button", "anchor-point-launcher");
            icon = createElement("span", "svg-icon");
            launcher.type = "button";
            launcher.setAttribute("data-tooltip", "Anchor Point Grid");
            launcher.setAttribute("aria-label", "Anchor Point Grid");
            launcher.setAttribute("aria-expanded", "false");
            setIcon(icon, "icons/anchor points.svg");
            launcher.appendChild(icon);
            launcher.addEventListener("click", function (event) {
                event.stopPropagation();
                toggleAnchorPointPopup(launcher);
            });
            control.appendChild(launcher);
            return control;
        }
        control.setAttribute("role", "group");
        control.setAttribute("aria-label", "Anchor Point Grid");
        appendAnchorPointDots(control);
        return control;
    }

    function ensureAnchorPointPopup() {
        if (!anchorPointPopup) {
            anchorPointPopup = createElement("div", "anchor-point-popup");
            anchorPointPopup.setAttribute("role", "menu");
            anchorPointPopup.setAttribute("aria-label", "Anchor Point Grid");
            appendAnchorPointDots(anchorPointPopup);
            document.body.appendChild(anchorPointPopup);
        }
        return anchorPointPopup;
    }

    function toggleAnchorPointPopup(trigger) {
        var popup = ensureAnchorPointPopup();
        var rect;
        var left;
        var top;
        if (popup.classList.contains("is-open")) {
            closeAnchorPointPopup();
            return;
        }
        anchorPointTrigger = trigger;
        trigger.setAttribute("aria-expanded", "true");
        popup.classList.add("is-open");
        rect = trigger.getBoundingClientRect();
        left = Math.max(6, Math.min(rect.left, window.innerWidth - popup.offsetWidth - 6));
        top = rect.bottom + 6;
        if (top + popup.offsetHeight > window.innerHeight - 6) {
            top = Math.max(6, rect.top - popup.offsetHeight - 6);
        }
        popup.style.left = left + "px";
        popup.style.top = top + "px";
    }

    function closeAnchorPointPopup() {
        if (anchorPointPopup) {
            anchorPointPopup.classList.remove("is-open");
        }
        if (anchorPointTrigger) {
            anchorPointTrigger.setAttribute("aria-expanded", "false");
        }
        anchorPointTrigger = null;
    }

    function handleAnchorPointClick(event) {
        var position = event.currentTarget.getAttribute("data-anchor-position");
        closeAnchorPointPopup();
        hideTooltip();
        if (position) {
            bridge.call("runCommand", ["anchorPointGrid", { position: position }], function () {});
        }
    }

    function renderAlignToolbar() {
        var toolbar = createElement("div", "align-toolbar is-disabled");
        var actions = [
            { id: "left", name: "Align Left", icon: "icons/align 1.svg" },
            { id: "hcenter", name: "Align Center Horizontally", icon: "icons/align 2.svg" },
            { id: "right", name: "Align Right", icon: "icons/align 3.svg" },
            { id: "center", name: "Align Center", icon: "icons/dual center align.svg" },
            { id: "top", name: "Align Top", icon: "icons/align 4.svg" },
            { id: "vcenter", name: "Align Center Vertically", icon: "icons/align 5.svg" },
            { id: "bottom", name: "Align Bottom", icon: "icons/align 6.svg" }
        ];
        var button;
        var icon;
        var i;

        toolbar.setAttribute("data-align-toolbar", "1");
        toolbar.setAttribute("aria-label", "Align");
        toolbar.addEventListener("contextmenu", function (event) {
            event.preventDefault();
            event.stopPropagation();
            openToolContextMenu({ id: "alignToolbar", name: "Align" }, event.clientX, event.clientY);
        });
        for (i = 0; i < actions.length; i += 1) {
            button = createElement("button", "align-button");
            icon = createElement("span", "svg-icon");
            button.type = "button";
            button.setAttribute("data-align-action", actions[i].id);
            button.setAttribute("data-tooltip", actions[i].name);
            button.setAttribute("aria-label", actions[i].name);
            setIcon(icon, actions[i].icon);
            button.appendChild(icon);
            button.addEventListener("click", handleAlignClick);
            toolbar.appendChild(button);
        }
        return toolbar;
    }

    function handleAlignClick(event) {
        var button = event.currentTarget;
        var toolbar = button && button.parentNode;
        var action = button ? button.getAttribute("data-align-action") : "";
        if (!toolbar || toolbar.classList.contains("is-disabled") || !action) {
            return;
        }
        toolbar.classList.add("is-running");
        bridge.call("runCommand", ["alignLayers", { action: action }], function () {
            window.setTimeout(function () {
                toolbar.classList.remove("is-running");
                refreshAlignToolbarState();
            }, 120);
        });
    }

    function refreshAlignToolbarState() {
        bridge.call("getSelectionState", [], function (result) {
            alignSelectionCount = result && result.ok && result.value ? Number(result.value.selectedLayers || 0) : 0;
            updateAlignToolbarState();
        });
    }

    function updateAlignSelectionFromActivityToken(token) {
        var parts;
        var count;
        var i;
        if (!token) {
            alignSelectionCount = 0;
            updateAlignToolbarState();
            return;
        }
        parts = String(token).split(",");
        count = 0;
        for (i = 3; i < parts.length; i += 1) {
            if (parts[i] !== "") {
                count += 1;
            }
        }
        alignSelectionCount = count;
        updateAlignToolbarState();
    }

    function updateAlignToolbarState() {
        var toolbars = document.querySelectorAll("[data-align-toolbar]");
        var enabled = alignSelectionCount > 0;
        var buttons;
        var i;
        var j;
        for (i = 0; i < toolbars.length; i += 1) {
            toolbars[i].classList.toggle("is-disabled", !enabled);
            buttons = toolbars[i].querySelectorAll(".align-button");
            for (j = 0; j < buttons.length; j += 1) {
                buttons[j].disabled = !enabled;
                buttons[j].setAttribute("aria-disabled", enabled ? "false" : "true");
            }
        }
    }

    function renderToolButton(tool) {
        var button = createElement("button", "tool-button");
        var icon = createElement("span", "svg-icon");
        button.type = "button";
        button.setAttribute("data-tool", tool.id);
        button.setAttribute("data-tooltip", tool.name);
        button.setAttribute("aria-label", tool.name);
        setIcon(icon, tool.icon);
        button.appendChild(icon);
        button.addEventListener("click", function () {
            executeTool(tool, button);
        });
        button.addEventListener("contextmenu", function (event) {
            event.preventDefault();
            event.stopPropagation();
            openToolContextMenu(tool, event.clientX, event.clientY);
        });
        return button;
    }

    function openToolContextMenu(tool, x, y) {
        hideTooltip();
        closeSearchFavoriteMenu();
        toolContextTarget = tool;
        updateToolContextMenu();
        toolContextMenu.classList.add("is-open");
        toolContextMenu.setAttribute("aria-hidden", "false");
        toolContextMenu.style.left = Math.max(6, Math.min(x, window.innerWidth - 120)) + "px";
        toolContextMenu.style.top = Math.max(6, Math.min(y, window.innerHeight - toolContextMenu.offsetHeight - 6)) + "px";
    }

    function closeToolContextMenu() {
        toolContextMenu.classList.remove("is-open");
        toolContextMenu.setAttribute("aria-hidden", "true");
        toolContextTarget = null;
    }

    function parentColorGroupingEnabled() {
        return localStorage.getItem("clear:parentColorGrouping") !== "0";
    }

    function parentOrganizeEnabled() {
        return localStorage.getItem("clear:parentOrganize") !== "0";
    }

    function updateToolContextMenu() {
        var isParentTool = toolContextTarget && toolContextTarget.id === "linkToParent";
        var isAnchorTool = toolContextTarget && toolContextTarget.id === "anchorPointGrid";
        parentColorAction.style.display = isParentTool ? "" : "none";
        parentOrganizeAction.style.display = isParentTool ? "" : "none";
        anchorInlineAction.style.display = isAnchorTool ? "" : "none";
        anchorPopupAction.style.display = isAnchorTool ? "" : "none";
        removeToolAction.style.display = isParentTool ? "none" : "";
        parentColorAction.textContent = parentColorGroupingEnabled() ? "Color Group ON" : "Color Group OFF";
        parentOrganizeAction.textContent = parentOrganizeEnabled() ? "Organize ON" : "Organize OFF";
        anchorInlineAction.classList.toggle("is-selected", isAnchorTool && anchorPointViewMode() === "inline");
        anchorPopupAction.classList.toggle("is-selected", isAnchorTool && anchorPointViewMode() === "popup");
    }

    function setAnchorPointViewMode(mode) {
        if (!toolContextTarget || toolContextTarget.id !== "anchorPointGrid") {
            return;
        }
        localStorage.setItem("clear:anchorPointView", mode);
        closeToolContextMenu();
        closeAnchorPointPopup();
        renderPanel();
    }

    function syncParentLinkOptions() {
        bridge.call("runCommand", ["linkToParent", {
            setOptions: true,
            colorGrouping: parentColorGroupingEnabled(),
            organize: parentOrganizeEnabled()
        }], function (result) {
            if (result && result.ok) {
                updateParentLinkButton(Boolean(result.value && result.value.enabled));
            }
        });
    }

    function toggleParentColorGrouping() {
        localStorage.setItem("clear:parentColorGrouping", parentColorGroupingEnabled() ? "0" : "1");
        updateToolContextMenu();
        syncParentLinkOptions();
    }

    function toggleParentOrganize() {
        localStorage.setItem("clear:parentOrganize", parentOrganizeEnabled() ? "0" : "1");
        updateToolContextMenu();
        syncParentLinkOptions();
    }

    function removeContextTool() {
        var hidden;
        if (!toolContextTarget) {
            return;
        }
        hidden = hiddenToolIds();
        if (hidden.indexOf(toolContextTarget.id) < 0) {
            hidden.push(toolContextTarget.id);
            saveHiddenToolIds(hidden);
        }
        closeToolContextMenu();
        renderPanel();
    }

    function restoreTool(id) {
        var hidden = hiddenToolIds();
        var index = hidden.indexOf(id);
        if (index >= 0) {
            hidden.splice(index, 1);
            saveHiddenToolIds(hidden);
            renderPanel();
        }
    }

    function populateRemovedToolsList(list) {
        var hidden = hiddenToolIds();
        var tool;
        var row;
        var name;
        var button;
        var i;
        list.innerHTML = "";
        if (!hidden.length) {
            list.appendChild(createElement("span", "removed-tools-empty", "No removed tools"));
            return;
        }
        for (i = 0; i < hidden.length; i += 1) {
            tool = findConfiguredTool(hidden[i]);
            if (!tool) {
                continue;
            }
            row = createElement("div", "removed-tool-row");
            name = createElement("span", "removed-tool-name", tool.name);
            button = createElement("button", "button-secondary", "Restore");
            button.type = "button";
            button.setAttribute("data-restore-tool", tool.id);
            button.addEventListener("click", function () {
                restoreTool(this.getAttribute("data-restore-tool"));
                populateRemovedToolsList(list);
            });
            row.appendChild(name);
            row.appendChild(button);
            list.appendChild(row);
        }
        if (!list.children.length) {
            list.appendChild(createElement("span", "removed-tools-empty", "No removed tools"));
        }
    }

    function scheduleResponsiveToolSizing(force) {
        if (force) {
            forceResponsiveSizing = true;
        }
        if (!force && resizeSettleTimer !== null) {
            window.clearTimeout(resizeSettleTimer);
        }
        if (resizeFrame !== null) {
            window.cancelAnimationFrame(resizeFrame);
            resizeFrame = null;
        }
        function runSizing() {
            resizeFrame = window.requestAnimationFrame(function () {
                resizeFrame = null;
                updateResponsiveToolSizing(forceResponsiveSizing);
                forceResponsiveSizing = false;
            });
        }
        if (force) {
            runSizing();
        } else {
            resizeSettleTimer = window.setTimeout(function () {
                resizeSettleTimer = null;
                runSizing();
            }, 160);
        }
    }

    function updateResponsiveToolSizing(force) {
        var panelWidth = document.documentElement.clientWidth;
        var panelHeight = document.documentElement.clientHeight;
        var grids = content.querySelectorAll(".tool-grid");
        var flatView = !categoryViewEnabled();
        var toolCount;
        var width;
        var height;
        var iconSize;
        var targetButtonSize;
        var buttonSize;
        var buttonPadding;
        var gap;
        var columns;
        var rows;
        var candidateSize;
        var bestSize;
        var bestColumns;
        var bestRows;
        var candidateColumns;
        var compactTimeFooter = panelWidth <= 300;
        var i;

        if (!force && Math.abs(panelWidth - lastResponsiveWidth) < 8) {
            return;
        }
        lastResponsiveWidth = panelWidth;
        lastResponsiveHeight = panelHeight;

        for (i = 0; i < grids.length; i += 1) {
            width = Math.floor(grids[i].clientWidth);
            height = Math.floor(grids[i].clientHeight);
            if (width <= 0 || height <= 0) {
                continue;
            }

            if (flatView) {
                var wrapper = grids[i].closest(".flat-tools-view");
                var toolbar = wrapper ? wrapper.querySelector(".align-toolbar") : null;
                var availableHeight = wrapper ? wrapper.clientHeight : height;
                var maxColumns = Math.max(3, Math.min(10, Math.floor((width + 4) / 24)));
                var minColumns = Math.min(3, maxColumns);
                var totalSlots;
                var candidateGap;
                var candidateWidth;
                var candidateHeight;
                var candidateIcon;
                var score;
                var bestScore = -1;
                toolCount = grids[i].querySelectorAll(".tool-button").length +
                    (grids[i].querySelector(".anchor-point-control") ? (anchorPointViewMode() === "popup" ? 1 : 4) : 0);
                if (toolbar) {
                    availableHeight -= toolbar.offsetHeight + 7;
                }
                availableHeight = Math.max(56, availableHeight);
                bestColumns = minColumns;
                bestRows = Math.ceil(toolCount / bestColumns);
                bestSize = 16;
                gap = 4;
                for (candidateColumns = minColumns; candidateColumns <= maxColumns; candidateColumns += 1) {
                    totalSlots = toolCount;
                    rows = Math.ceil(totalSlots / candidateColumns);
                    candidateGap = Math.max(3, Math.min(7, width / (candidateColumns * 13)));
                    candidateWidth = (width - candidateGap * (candidateColumns - 1)) / candidateColumns;
                    candidateHeight = (availableHeight - candidateGap * (rows - 1)) / rows;
                    candidateSize = Math.min(candidateWidth, candidateHeight);
                    candidateIcon = Math.max(10, Math.min(40, candidateSize - 6));
                    score = candidateSize + candidateIcon * 0.25 - Math.abs(candidateColumns - 5) * 0.6;
                    if (candidateSize >= 12 && score > bestScore) {
                        bestScore = score;
                        bestColumns = candidateColumns;
                        bestRows = rows;
                        bestSize = candidateSize;
                        gap = candidateGap;
                    }
                }
                columns = bestColumns;
                rows = bestRows;
                buttonSize = Math.max(14, Math.min(72, (width - gap * (columns - 1)) / columns));
                candidateSize = Math.max(14, Math.min(72, bestSize));
                iconSize = Math.max(9, Math.min(42, candidateSize - 6, buttonSize - 6));
                buttonPadding = Math.max(1, Math.min(8, (candidateSize - iconSize) / 2));
                grids[i].style.setProperty("--tool-button-height", candidateSize + "px");
            } else {
                iconSize = Math.max(20, Math.min(26, Math.round(width / 15)));
                targetButtonSize = Math.max(42, Math.min(50, iconSize + 24));
                gap = Math.max(5, Math.min(7, Math.round(width / 60)));
                columns = Math.max(1, Math.floor((width + gap) / (targetButtonSize + gap)));
                buttonSize = Math.floor((width - gap * (columns - 1)) / columns);
                buttonSize = Math.max(42, Math.min(50, buttonSize));
                iconSize = Math.max(20, Math.min(26, Math.min(iconSize, buttonSize - 16)));
                buttonPadding = Math.max(6, Math.floor((buttonSize - iconSize) / 2));
            }

            if (columns <= 4) {
                compactTimeFooter = true;
            }

            grids[i].style.setProperty("--tool-columns", String(columns));
            grids[i].style.setProperty("--tool-button-size", buttonSize + "px");
            grids[i].style.setProperty("--tool-icon-size", iconSize + "px");
            grids[i].style.setProperty("--tool-grid-gap", gap + "px");
            grids[i].style.setProperty("--tool-button-padding", buttonPadding + "px");
            positionAnchorPointControl(grids[i], columns, flatView);
        }
        updateAlignToolbarSizing();
        document.body.classList.toggle("compact-time-footer", compactTimeFooter);
        updateQuickColorLayout();
    }

    function positionAnchorPointControl(grid, columns, flatView) {
        var anchor = grid.querySelector(".anchor-point-control");
        var tools;
        var sideFillCount;
        var insertIndex;
        if (!anchor) {
            return;
        }
        if (!flatView || anchorPointViewMode() === "popup" || columns < 3) {
            grid.appendChild(anchor);
            return;
        }
        tools = grid.querySelectorAll(".tool-button");
        sideFillCount = Math.max(0, (columns - 2) * 2);
        insertIndex = Math.max(0, Math.floor((tools.length - sideFillCount) / columns) * columns);
        if (tools[insertIndex]) {
            grid.insertBefore(anchor, tools[insertIndex]);
        } else {
            grid.appendChild(anchor);
        }
    }

    function updateAlignToolbarSizing() {
        var toolbars = content.querySelectorAll(".align-toolbar");
        var width;
        var grid;
        var gridButtonHeight;
        var gap;
        var buttonSize;
        var iconSize;
        var padding;
        var i;
        for (i = 0; i < toolbars.length; i += 1) {
            width = Math.floor(toolbars[i].clientWidth);
            if (width <= 0) {
                continue;
            }
            grid = content.querySelector(".flat-tool-grid") || content.querySelector(".tool-grid");
            gridButtonHeight = grid ? parseFloat(getComputedStyle(grid).getPropertyValue("--tool-button-height")) : 0;
            if (!isFinite(gridButtonHeight) || gridButtonHeight <= 0) {
                gridButtonHeight = grid ? parseFloat(getComputedStyle(grid).getPropertyValue("--tool-button-size")) : 32;
            }
            if (!isFinite(gridButtonHeight) || gridButtonHeight <= 0) {
                gridButtonHeight = 32;
            }
            gap = Math.max(2, Math.min(6, width / 62));
            buttonSize = Math.floor((width - gap * 6) / 7);
            buttonSize = Math.max(14, Math.min(32, gridButtonHeight, buttonSize));
            iconSize = Math.max(9, Math.min(19, buttonSize - 6));
            padding = Math.max(2, Math.min(4, Math.floor(buttonSize / 8)));
            toolbars[i].style.setProperty("--align-gap", gap + "px");
            toolbars[i].style.setProperty("--align-button-size", buttonSize + "px");
            toolbars[i].style.setProperty("--align-icon-size", iconSize + "px");
            toolbars[i].style.setProperty("--align-padding", padding + "px");
        }
    }

    function renderSearch() {
        var shell = createElement("div", "effects-search");
        var wrap = createElement("div", "search-input-wrap");
        var icon = createElement("span", "svg-icon");
        var input = createElement("input");
        var shortcut = createElement("span", "search-shortcut", "ENTER");

        setIcon(icon, "icons/search.svg");
        input.type = "search";
        input.id = "effects-search-input";
        input.placeholder = "Search effects or CLEAR tools...";
        input.autocomplete = "off";
        input.spellcheck = false;
        input.setAttribute("aria-label", "Search CLEAR tools and After Effects effects");
        input.setAttribute("aria-controls", "search-results");
        input.addEventListener("input", updateSearch);
        input.addEventListener("keydown", handleSearchKeys);
        input.addEventListener("focus", function () {
            currentSearchInput = input;
            if (input.value.trim()) {
                updateSearch({ target: input });
            }
        });

        wrap.appendChild(icon);
        wrap.appendChild(input);
        wrap.appendChild(shortcut);
        shell.appendChild(wrap);
        return shell;
    }

    function executeTool(tool, button) {
        closeSearch();
        if (tool.id === "deleteParticularEffect") {
            openDeleteEffects();
            return;
        }
        if (tool.id === "fastColor") {
            executeFastColor(tool, button);
            return;
        }

        if (button) {
            button.classList.add("is-running");
        }
        var commandOptions = {};
        if (tool.id === "pngRender") {
            commandOptions.outputFolder = localStorage.getItem("clear:pngOutputFolder") || "";
        }
        if (tool.id === "linkToParent") {
            commandOptions.colorGrouping = parentColorGroupingEnabled();
            commandOptions.organize = parentOrganizeEnabled();
        }
        bridge.call("runCommand", [tool.id, commandOptions], function (result) {
            if (button) {
                window.setTimeout(function () {
                    button.classList.remove("is-running");
                }, 150);
            }
            if (result && result.ok === false) {
                showStatus("Unable to run " + tool.name, true);
            }
            if (tool.id === "toggle3D" && result && result.ok) {
                update3DModeButton(Boolean(result.value && result.value.enabled));
            }
            if (tool.id === "linkToParent" && result && result.ok) {
                updateParentLinkButton(Boolean(result.value && result.value.enabled));
            }
        });
    }

    function executeFastColor(tool, button) {
        if (button) {
            button.classList.add("is-running");
        }
        bridge.call("runCommand", [tool.id, {}], function () {
            if (button) {
                window.setTimeout(function () {
                    button.classList.remove("is-running");
                }, 150);
            }
        });
    }

    function update3DModeButton(enabled) {
        var button = document.querySelector('[data-tool="toggle3D"]');
        if (!button) {
            return;
        }
        button.classList.toggle("is-mode-active", enabled);
        button.setAttribute("aria-pressed", enabled ? "true" : "false");
    }

    function refresh3DModeState() {
        bridge.call("get3DModeState", [], function (result) {
            update3DModeButton(Boolean(result && result.ok && result.value && result.value.enabled));
        });
    }

    function updateParentLinkButton(enabled) {
        var button = document.querySelector('[data-tool="linkToParent"]');
        if (!button) {
            return;
        }
        button.classList.toggle("is-mode-active", enabled);
        button.setAttribute("aria-pressed", enabled ? "true" : "false");
    }

    function refreshParentLinkState() {
        syncParentLinkOptions();
        bridge.call("getParentLinkState", [], function (result) {
            updateParentLinkButton(Boolean(result && result.ok && result.value && result.value.enabled));
        });
    }

    function loadEffects() {
        bridge.call("getEffects", [], function (result) {
            if (result && result.ok && result.value instanceof Array) {
                aeEffects = result.value;
                refreshQuickSearchIndex();
            }
        });
    }

    function normalized(value) {
        return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
    }

    function fuzzyScore(name, query) {
        var haystack = normalized(name);
        var needle = normalized(query);
        var direct = haystack.indexOf(needle);
        var score = 0;
        var h = 0;
        var n = 0;

        if (!needle) {
            return -1;
        }
        if (direct === 0) {
            return 1000 - haystack.length;
        }
        if (direct > 0) {
            return 700 - direct;
        }
        while (h < haystack.length && n < needle.length) {
            if (haystack.charAt(h) === needle.charAt(n)) {
                score += h > 0 && haystack.charAt(h - 1) === " " ? 10 : 3;
                n += 1;
            }
            h += 1;
        }
        return n === needle.length ? score : -1;
    }

    function buildSearchEntries(query) {
        var entries = [];
        var seenTools = {};
        var favorites = bridge.readQuickSearchFavorites();
        var i;
        var score;

        for (i = 0; i < allTools.length; i += 1) {
            if (seenTools[allTools[i].id]) {
                continue;
            }
            seenTools[allTools[i].id] = true;
            score = fuzzyScore(allTools[i].name, query);
            if (score >= 0) {
                entries.push({
                    type: "tool",
                    name: allTools[i].name,
                    icon: allTools[i].icon,
                    score: score + 100,
                    favorite: favorites.indexOf("tool:" + allTools[i].id) >= 0,
                    value: allTools[i]
                });
            }
        }

        for (i = 0; i < aeEffects.length; i += 1) {
            score = Math.max(
                fuzzyScore(aeEffects[i].name, query),
                fuzzyScore(aeEffects[i].category, query) - 30,
                fuzzyScore(aeEffects[i].matchName, query) - 15
            );
            if (score >= 0) {
                entries.push({
                    type: "effect",
                    name: aeEffects[i].name,
                    icon: "icons/fast color.svg",
                    score: score,
                    favorite: favorites.indexOf("effect:" + (aeEffects[i].matchName || aeEffects[i].name)) >= 0,
                    value: aeEffects[i]
                });
            }
        }

        entries.sort(function (a, b) {
            if (showFavoritesFirst() && a.favorite !== b.favorite) {
                return a.favorite ? -1 : 1;
            }
            if (b.score !== a.score) {
                return b.score - a.score;
            }
            return a.name.localeCompare(b.name);
        });
        return entries.slice(0, 24);
    }

    function updateSearch(event) {
        var input = event.target;
        var query = input.value.trim();
        var rect;
        var i;

        currentSearchInput = input;
        if (!query) {
            closeSearch();
            return;
        }

        visibleSearchEntries = buildSearchEntries(query);
        activeSearchIndex = 0;
        searchResults.innerHTML = "";

        if (visibleSearchEntries.length === 0) {
            searchResults.appendChild(createElement("div", "empty-result", "No matching tools or effects"));
        } else {
            for (i = 0; i < visibleSearchEntries.length; i += 1) {
                searchResults.appendChild(renderSearchResult(visibleSearchEntries[i], i));
            }
        }

        rect = input.parentNode.getBoundingClientRect();
        searchResults.style.left = Math.max(8, rect.left) + "px";
        searchResults.style.top = Math.min(window.innerHeight - 70, rect.bottom + 5) + "px";
        searchResults.style.width = Math.min(rect.width, window.innerWidth - Math.max(8, rect.left) - 8) + "px";
        searchResults.classList.add("is-open");
        input.setAttribute("aria-expanded", "true");
    }

    function renderSearchResult(entry, index) {
        var button = createElement("button", "search-result" + (index === 0 ? " is-selected" : ""));
        var icon = createElement("span", "svg-icon");
        var name = createElement("span", "result-name", entry.name);
        var kind = createElement("span", "result-kind", entry.type === "tool" ? "CLEAR" : (entry.favorite ? "\u2605 AE Effect" : "AE Effect"));
        button.type = "button";
        button.setAttribute("role", "option");
        button.setAttribute("aria-selected", index === 0 ? "true" : "false");
        setIcon(icon, entry.icon);
        button.appendChild(icon);
        button.appendChild(name);
        button.appendChild(kind);
        button.addEventListener("mouseenter", function () {
            activeSearchIndex = index;
            refreshSearchSelection();
        });
        button.addEventListener("mousedown", function (event) {
            event.preventDefault();
        });
        button.addEventListener("click", function () {
            activateSearchEntry(entry);
        });
        button.addEventListener("contextmenu", function (event) {
            event.preventDefault();
            event.stopPropagation();
            openSearchFavoriteMenu(entry, event.clientX, event.clientY);
        });
        return button;
    }

    function handleSearchKeys(event) {
        if (event.key === "Escape") {
            closeSearch();
            event.target.blur();
            return;
        }
        if (!searchResults.classList.contains("is-open")) {
            return;
        }
        if (event.key === "ArrowDown") {
            activeSearchIndex = Math.min(activeSearchIndex + 1, visibleSearchEntries.length - 1);
            refreshSearchSelection();
            event.preventDefault();
        } else if (event.key === "ArrowUp") {
            activeSearchIndex = Math.max(activeSearchIndex - 1, 0);
            refreshSearchSelection();
            event.preventDefault();
        } else if (event.key === "Enter" && visibleSearchEntries[activeSearchIndex]) {
            activateSearchEntry(visibleSearchEntries[activeSearchIndex]);
            event.preventDefault();
        }
    }

    function refreshSearchSelection() {
        var children = searchResults.querySelectorAll(".search-result");
        var i;
        for (i = 0; i < children.length; i += 1) {
            children[i].classList.toggle("is-selected", i === activeSearchIndex);
            children[i].setAttribute("aria-selected", i === activeSearchIndex ? "true" : "false");
        }
        if (children[activeSearchIndex]) {
            children[activeSearchIndex].scrollIntoView({ block: "nearest" });
        }
    }

    function activateSearchEntry(entry) {
        if (currentSearchInput) {
            currentSearchInput.value = "";
        }
        closeSearch();
        if (entry.type === "tool") {
            executeTool(entry.value, document.querySelector('[data-tool="' + entry.value.id + '"]'));
        } else {
            bridge.call("applyEffect", [entry.value.matchName], function (result) {
                if (!result || result.ok === false || (result.value && result.value.applied === 0)) {
                    showStatus("Unable to apply " + entry.name, true);
                }
            });
        }
    }

    function closeSearch() {
        searchResults.classList.remove("is-open");
        searchResults.innerHTML = "";
        visibleSearchEntries = [];
        if (currentSearchInput) {
            currentSearchInput.setAttribute("aria-expanded", "false");
        }
    }

    function searchFavoriteId(entry) {
        return entry.type === "tool" ? "tool:" + entry.value.id :
            "effect:" + (entry.value.matchName || entry.value.name);
    }

    function openSearchFavoriteMenu(entry, x, y) {
        var favorites = bridge.readQuickSearchFavorites();
        var id = searchFavoriteId(entry);
        favoriteContextEntry = entry;
        searchFavoriteAction.textContent = favorites.indexOf(id) >= 0 ? "Remove from Favorite" : "Add to Favorite";
        searchFavoriteMenu.classList.add("is-open");
        searchFavoriteMenu.setAttribute("aria-hidden", "false");
        searchFavoriteMenu.style.left = Math.max(6, Math.min(x, window.innerWidth - 155)) + "px";
        searchFavoriteMenu.style.top = Math.max(6, Math.min(y, window.innerHeight - 42)) + "px";
    }

    function closeSearchFavoriteMenu() {
        searchFavoriteMenu.classList.remove("is-open");
        searchFavoriteMenu.setAttribute("aria-hidden", "true");
        favoriteContextEntry = null;
    }

    function toggleSearchFavorite() {
        var favorites;
        var id;
        var index;
        if (!favoriteContextEntry) {
            return;
        }
        favorites = bridge.readQuickSearchFavorites();
        id = searchFavoriteId(favoriteContextEntry);
        index = favorites.indexOf(id);
        if (index >= 0) {
            favorites.splice(index, 1);
        } else {
            favorites.push(id);
        }
        bridge.writeQuickSearchFavorites(favorites);
        closeSearchFavoriteMenu();
        if (currentSearchInput && currentSearchInput.value.trim()) {
            updateSearch({ target: currentSearchInput });
        }
    }

    function openDeleteEffects() {
        openModal("Delete Particular Effect", createElement("p", "modal-note", "Reading effects from selected layers..."));
        bridge.call("getSelectedEffects", [], function (result) {
            var effects = result && result.ok ? result.value : [];
            var list;
            var deleteButton;
            var i;
            modalBody.innerHTML = "";
            modalFooter.innerHTML = "";

            if (!effects || effects.length === 0) {
                modalBody.appendChild(createElement("p", "empty-state", "No effects found on the selected layers."));
                return;
            }

            list = createElement("div", "effect-checklist");
            for (i = 0; i < effects.length; i += 1) {
                list.appendChild(createEffectCheck(effects[i]));
            }
            modalBody.appendChild(list);

            deleteButton = createElement("button", "button-primary", "Delete");
            deleteButton.type = "button";
            deleteButton.disabled = true;
            list.addEventListener("change", function () {
                deleteButton.disabled = list.querySelectorAll("input:checked").length === 0;
            });
            deleteButton.addEventListener("click", function () {
                var checked = list.querySelectorAll("input:checked");
                var matchNames = [];
                var c;
                for (c = 0; c < checked.length; c += 1) {
                    matchNames.push(checked[c].value);
                }
                if (!matchNames.length) {
                    return;
                }
                deleteButton.disabled = true;
                bridge.call("deleteEffects", [matchNames], function () {
                    closeModal();
                });
            });
            modalFooter.appendChild(deleteButton);
        });
    }

    function createEffectCheck(effect) {
        var label = createElement("label", "check-row");
        var checkbox = createElement("input");
        var text = createElement("span", "", effect.name + (effect.count > 1 ? " (" + effect.count + ")" : ""));
        checkbox.type = "checkbox";
        checkbox.value = effect.matchName;
        label.appendChild(checkbox);
        label.appendChild(text);
        return label;
    }

    function openDonate() {
        var card = createElement("div", "donate-card");
        var supportTitle = createElement("strong", "donate-title", "Support for More Tools & Updates");
        var qrImage = createElement("img", "donate-qr");
        var upiLabel = createElement("span", "donate-label", "UPI ID");
        var upiRow = createElement("div", "upi-row");
        var upiValue = createElement("code", "upi-value", "kevinvimala15@okhdfcbank");
        var copyButton = createElement("button", "button-secondary", "Copy");
        var closeButton = createElement("button", "button-primary", "Close");

        qrImage.src = "assets/kevin-romero-upi.jpeg?v=20260622-2";
        qrImage.alt = "UPI payment QR code";
        copyButton.type = "button";
        copyButton.addEventListener("click", function () {
            if (bridge.copyText("kevinvimala15@okhdfcbank")) {
                copyButton.textContent = "Copied";
                window.setTimeout(function () {
                    copyButton.textContent = "Copy";
                }, 1400);
            }
        });
        closeButton.type = "button";
        closeButton.addEventListener("click", closeModal);

        card.appendChild(supportTitle);
        card.appendChild(qrImage);
        card.appendChild(upiLabel);
        upiRow.appendChild(upiValue);
        upiRow.appendChild(copyButton);
        card.appendChild(upiRow);
        openModal("Support", card);
        modalFooter.appendChild(closeButton);
    }

    function shortcutFromCaptureEvent(event) {
        var parts = [];
        var key = String(event.key || "");
        if (key === "Control" || key === "Alt" || key === "Shift" || key === "Meta" || event.metaKey) {
            return "";
        }
        if (event.ctrlKey) { parts.push("Ctrl"); }
        if (event.altKey) { parts.push("Alt"); }
        if (event.shiftKey) { parts.push("Shift"); }
        if (key === " " || key === "Spacebar") {
            key = "Space";
        } else if (key.length === 1) {
            key = key.toUpperCase();
        } else if (!/^F([1-9]|1[0-2])$/i.test(key)) {
            return "";
        }
        parts.push(key);
        return parts.join("+");
    }

    function openSettings(focusQuickColors) {
        var grid = createElement("div", "settings-grid");
        var folderLabel = createElement("label", "field-label", "PNG Output Folder");
        var folderRow = createElement("div", "folder-picker");
        var folderInput = createElement("input");
        var browseButton = createElement("button", "button-secondary", "Browse Folder");
        var pauseLabel = createElement("label", "check-row settings-check");
        var pauseCheckbox = createElement("input");
        var pauseText = createElement("span", "", "Pause timer when After Effects inactive");
        var categoryLabel = createElement("label", "check-row settings-check category-view-setting");
        var categoryCheckbox = createElement("input");
        var categoryText = createElement("span", "", "Category View");
        var categoryState = createElement("span", "setting-state");
        var markerLabel = createElement("label", "check-row settings-check");
        var markerCheckbox = createElement("input");
        var markerText = createElement("span", "", "Enable J/K Marker Navigation");
        var quickLabel = createElement("label", "check-row settings-check");
        var quickCheckbox = createElement("input");
        var quickText = createElement("span", "", "Enable Quick Search");
        var colorLabel = createElement("label", "field-label accent-setting", "Interface Color");
        var colorRow = createElement("div", "accent-slider-row");
        var colorSlider = createElement("input", "accent-slider");
        var colorSwatch = createElement("span", "accent-swatch");
        var shortcutLabel = createElement("label", "field-label", "Quick Search Shortcut");
        var shortcutRow = createElement("div", "folder-picker");
        var shortcutInput = createElement("input");
        var shortcutReset = createElement("button", "button-secondary", "Reset to Default");
        var removedToolsSetting = createElement("div", "removed-tools-setting");
        var removedToolsTitle = createElement("span", "field-label", "Removed Tools");
        var removedToolsList = createElement("div", "removed-tools-list");
        var quickColorSetting = createElement("div", "quick-color-settings");
        var quickColorTitle = createElement("span", "field-label", "Quick Colors");
        var quickColorEnabledLabel = createElement("label", "check-row settings-check");
        var quickColorEnabledCheckbox = createElement("input");
        var quickColorEnabledText = createElement("span", "", "Enable Quick Colors");
        var quickColorSizeRow = createElement("div", "quick-color-size-row");
        var quickColorRowsLabel = createElement("label", "field-label", "Rows");
        var quickColorRowsInput = createElement("input");
        var quickColorColumnsLabel = createElement("label", "field-label", "Columns");
        var quickColorColumnsInput = createElement("input");
        var quickColorEditButton = createElement("button", "button-secondary", "Edit Quick Colors");
        var quickColorEditor = createElement("div", "quick-color-editor");
        var currentQuickColors = quickColorsState();
        var capturedShortcut = quickSearchHotkey();
        var shortcutCaptureTimer = null;
        var saveButton = createElement("button", "button-primary", "Save");

        populateRemovedToolsList(removedToolsList);
        removedToolsSetting.appendChild(removedToolsTitle);
        removedToolsSetting.appendChild(removedToolsList);

        function updateQuickColorSize() {
            var state = quickColorsState();
            state.rows = Math.max(1, Math.min(10, parseInt(quickColorRowsInput.value, 10) || 1));
            state.columns = Math.max(1, Math.min(20, parseInt(quickColorColumnsInput.value, 10) || 1));
            saveQuickColorsState(state);
            renderQuickColors();
            populateQuickColorEditor(quickColorEditor);
        }

        quickColorRowsInput.type = "number";
        quickColorRowsInput.min = "1";
        quickColorRowsInput.max = "10";
        quickColorRowsInput.value = String(currentQuickColors.rows);
        quickColorRowsInput.addEventListener("change", updateQuickColorSize);
        quickColorColumnsInput.type = "number";
        quickColorColumnsInput.min = "1";
        quickColorColumnsInput.max = "20";
        quickColorColumnsInput.value = String(currentQuickColors.columns);
        quickColorColumnsInput.addEventListener("change", updateQuickColorSize);
        quickColorRowsLabel.appendChild(quickColorRowsInput);
        quickColorColumnsLabel.appendChild(quickColorColumnsInput);
        quickColorSizeRow.appendChild(quickColorRowsLabel);
        quickColorSizeRow.appendChild(quickColorColumnsLabel);

        populateQuickColorEditor(quickColorEditor);
        quickColorEditButton.type = "button";
        quickColorEditButton.addEventListener("click", function () {
            var open = quickColorEditor.classList.toggle("is-open");
            quickColorEditButton.textContent = open ? "Done Editing" : "Edit Quick Colors";
        });

        quickColorSetting.appendChild(quickColorTitle);
        quickColorEnabledCheckbox.type = "checkbox";
        quickColorEnabledCheckbox.checked = quickColorsEnabled();
        quickColorEnabledCheckbox.addEventListener("change", function () {
            localStorage.setItem("clear:quickColorsEnabled", quickColorEnabledCheckbox.checked ? "1" : "0");
            renderQuickColors();
        });
        quickColorEnabledLabel.appendChild(quickColorEnabledCheckbox);
        quickColorEnabledLabel.appendChild(quickColorEnabledText);
        quickColorSetting.appendChild(quickColorEnabledLabel);
        quickColorSetting.appendChild(quickColorSizeRow);
        quickColorSetting.appendChild(quickColorEditButton);
        quickColorSetting.appendChild(quickColorEditor);

        colorSlider.type = "range";
        colorSlider.min = "0";
        colorSlider.max = "360";
        colorSlider.step = "1";
        colorSlider.value = String(accentHue());
        colorSlider.setAttribute("aria-label", "CLEAR interface color");
        colorSlider.addEventListener("input", function () {
            applyAccentTheme(Number(colorSlider.value), false);
        });
        colorSlider.addEventListener("change", function () {
            localStorage.setItem("clear:accentHue", colorSlider.value);
            applyAccentTheme(Number(colorSlider.value), true);
        });
        colorRow.appendChild(colorSlider);
        colorRow.appendChild(colorSwatch);
        colorLabel.appendChild(colorRow);

        function stopShortcutCapture() {
            bridge.endQuickSearchShortcutCapture();
            if (shortcutCaptureTimer !== null) {
                window.clearInterval(shortcutCaptureTimer);
                shortcutCaptureTimer = null;
            }
        }

        function startShortcutCapture() {
            stopShortcutCapture();
            bridge.beginQuickSearchShortcutCapture();
            shortcutCaptureTimer = window.setInterval(function () {
                var shortcut = bridge.readQuickSearchShortcutCapture();
                if (!shortcut) {
                    return;
                }
                capturedShortcut = shortcut;
                localStorage.setItem("clear:quickSearchHotkey", capturedShortcut);
                shortcutInput.value = capturedShortcut;
                stopShortcutCapture();
                syncQuickSearchSettings();
                shortcutInput.blur();
            }, 25);
        }

        folderInput.type = "text";
        folderInput.readOnly = true;
        folderInput.placeholder = "Project folder / CLEAR PNG";
        folderInput.value = localStorage.getItem("clear:pngOutputFolder") || "";
        browseButton.type = "button";
        browseButton.addEventListener("click", function () {
            var selectedFolder = bridge.chooseFolder(folderInput.value);
            if (selectedFolder) {
                folderInput.value = selectedFolder;
            }
        });
        folderRow.appendChild(folderInput);
        folderRow.appendChild(browseButton);
        folderLabel.appendChild(folderRow);

        pauseCheckbox.type = "checkbox";
        pauseCheckbox.checked = localStorage.getItem("clear:pauseWhenInactive") !== "0";
        pauseLabel.appendChild(pauseCheckbox);
        pauseLabel.appendChild(pauseText);

        categoryCheckbox.type = "checkbox";
        categoryCheckbox.setAttribute("aria-label", "Category View");
        categoryCheckbox.checked = categoryViewEnabled();
        categoryState.setAttribute("aria-hidden", "true");
        categoryState.textContent = categoryCheckbox.checked ? "ON" : "OFF";
        categoryCheckbox.addEventListener("change", function () {
            categoryState.textContent = categoryCheckbox.checked ? "ON" : "OFF";
        });
        categoryLabel.appendChild(categoryCheckbox);
        categoryLabel.appendChild(categoryText);
        categoryLabel.appendChild(categoryState);

        markerCheckbox.type = "checkbox";
        markerCheckbox.checked = markerNavigationEnabled();
        markerCheckbox.addEventListener("change", function () {
            localStorage.setItem("clear:markerNavigationEnabled", markerCheckbox.checked ? "1" : "0");
            syncMarkerNavigationSetting();
        });
        markerLabel.appendChild(markerCheckbox);
        markerLabel.appendChild(markerText);

        quickCheckbox.type = "checkbox";
        quickCheckbox.checked = quickSearchEnabled();
        quickCheckbox.addEventListener("change", function () {
            localStorage.setItem("clear:quickSearchEnabled", quickCheckbox.checked ? "1" : "0");
            syncQuickSearchSettings();
        });
        quickLabel.appendChild(quickCheckbox);
        quickLabel.appendChild(quickText);

        shortcutInput.type = "text";
        shortcutInput.readOnly = true;
        shortcutInput.value = capturedShortcut;
        shortcutInput.addEventListener("mousedown", function () {
            bridge.setQuickSearchSettings(false, capturedShortcut, true);
        });
        shortcutInput.addEventListener("focus", function () {
            shortcutInput.value = "Press shortcut...";
            bridge.setQuickSearchSettings(false, capturedShortcut, true);
            startShortcutCapture();
        });
        shortcutInput.addEventListener("keydown", function (event) {
            var shortcut;
            event.preventDefault();
            event.stopPropagation();
            if (event.key === "Escape") {
                stopShortcutCapture();
                shortcutInput.blur();
                return;
            }
            shortcut = shortcutFromCaptureEvent(event);
            if (shortcut) {
                capturedShortcut = shortcut;
                shortcutInput.value = shortcut;
                localStorage.setItem("clear:quickSearchHotkey", shortcut);
                stopShortcutCapture();
                syncQuickSearchSettings();
                shortcutInput.blur();
            }
        });
        shortcutInput.addEventListener("blur", function () {
            stopShortcutCapture();
            shortcutInput.value = capturedShortcut;
            syncQuickSearchSettings();
        });
        shortcutReset.type = "button";
        shortcutReset.addEventListener("click", function () {
            stopShortcutCapture();
            capturedShortcut = "Ctrl+Space";
            shortcutInput.value = capturedShortcut;
            localStorage.setItem("clear:quickSearchHotkey", capturedShortcut);
            localStorage.setItem("clear:quickColorsEnabled", quickColorEnabledCheckbox.checked ? "1" : "0");
            syncQuickSearchSettings();
        });
        shortcutRow.appendChild(shortcutInput);
        shortcutRow.appendChild(shortcutReset);
        shortcutLabel.appendChild(shortcutRow);

        grid.appendChild(folderLabel);
        grid.appendChild(colorLabel);
        grid.appendChild(pauseLabel);
        grid.appendChild(categoryLabel);
        grid.appendChild(quickColorSetting);
        grid.appendChild(removedToolsSetting);
        openModal("Settings", grid);
        saveButton.type = "button";
        saveButton.addEventListener("click", function () {
            localStorage.setItem("clear:pngOutputFolder", folderInput.value);
            localStorage.setItem("clear:pauseWhenInactive", pauseCheckbox.checked ? "1" : "0");
            localStorage.setItem("clear:categoryView", categoryCheckbox.checked ? "1" : "0");
            localStorage.setItem("clear:markerNavigationEnabled", markerCheckbox.checked ? "1" : "0");
            localStorage.setItem("clear:quickSearchEnabled", quickCheckbox.checked ? "1" : "0");
            localStorage.setItem("clear:quickSearchHotkey", capturedShortcut);
            localStorage.setItem("clear:accentHue", colorSlider.value);
            applyAccentTheme(Number(colorSlider.value), true);
            syncMarkerNavigationSetting();
            syncQuickSearchSettings();
            closeModal();
            renderPanel();
            refresh3DModeState();
            refreshParentLinkState();
        });
        modalFooter.appendChild(saveButton);
        if (focusQuickColors) {
            quickColorEditor.classList.add("is-open");
            quickColorEditButton.textContent = "Done Editing";
            window.setTimeout(function () {
                modalBody.scrollTop = Math.max(0, quickColorSetting.offsetTop - grid.offsetTop - 8);
            }, 0);
        }
    }

    function openModal(title, bodyNode) {
        closeSearch();
        closeToolContextMenu();
        closeQuickColorsContextMenu();
        closeFeedbackMenu();
        modalTitle.textContent = title;
        modalBody.innerHTML = "";
        modalFooter.innerHTML = "";
        if (bodyNode) {
            modalBody.appendChild(bodyNode);
        }
        modalBackdrop.classList.add("is-open");
        modalBackdrop.setAttribute("aria-hidden", "false");
        document.getElementById("modal-close").focus();
    }

    function closeModal() {
        modalBackdrop.classList.remove("is-open");
        modalBackdrop.setAttribute("aria-hidden", "true");
        modalBody.innerHTML = "";
        modalFooter.innerHTML = "";
    }

    function closeFeedbackMenu() {
        feedbackMenu.classList.remove("is-open");
        feedbackMenu.setAttribute("aria-hidden", "true");
    }

    function openFeedbackMenu(trigger) {
        var rect = trigger.getBoundingClientRect();
        var left;
        var top;
        closeSearch();
        closeToolContextMenu();
        closeQuickColorsContextMenu();
        closeAnchorPointPopup();
        hideTooltip();
        feedbackMenu.classList.add("is-open");
        feedbackMenu.setAttribute("aria-hidden", "false");
        left = Math.max(6, Math.min(rect.right - feedbackMenu.offsetWidth, window.innerWidth - feedbackMenu.offsetWidth - 6));
        top = rect.bottom + 6;
        if (top + feedbackMenu.offsetHeight > window.innerHeight - 6) {
            top = Math.max(6, rect.top - feedbackMenu.offsetHeight - 6);
        }
        feedbackMenu.style.left = left + "px";
        feedbackMenu.style.top = top + "px";
    }

    function bindUtilities() {
        var utilityButtons = document.querySelectorAll("[data-utility]");
        var i;
        for (i = 0; i < utilityButtons.length; i += 1) {
            utilityButtons[i].addEventListener("click", function () {
                var action = this.getAttribute("data-utility");
                if (action === "update") {
                    bridge.openURL("https://clear-plugin.vercel.app/");
                    return;
                }
                if (action === "settings") {
                    openSettings();
                    return;
                }
                if (action === "feedback") {
                    openFeedbackMenu(this);
                    return;
                }
                if (action === "donate") {
                    openDonate();
                }
            });
        }
    }

    function bindTooltip() {
        document.addEventListener("mouseover", function (event) {
            var target = closestWithAttribute(event.target, "data-tooltip");
            if (!target) {
                return;
            }
            window.clearTimeout(tooltipTimer);
            tooltipTimer = window.setTimeout(function () {
                showTooltip(target);
            }, 200);
        });
        document.addEventListener("mouseout", function (event) {
            var target = closestWithAttribute(event.target, "data-tooltip");
            if (!target || (event.relatedTarget && target.contains(event.relatedTarget))) {
                return;
            }
            hideTooltip();
        });
        document.addEventListener("focusin", function (event) {
            var target = closestWithAttribute(event.target, "data-tooltip");
            if (target) {
                window.clearTimeout(tooltipTimer);
                tooltipTimer = window.setTimeout(function () {
                    showTooltip(target);
                }, 200);
            }
        });
        document.addEventListener("focusout", hideTooltip);
    }

    function closestWithAttribute(node, attribute) {
        while (node && node !== document) {
            if (node.hasAttribute && node.hasAttribute(attribute)) {
                return node;
            }
            node = node.parentNode;
        }
        return null;
    }

    function showTooltip(target) {
        var rect = target.getBoundingClientRect();
        var tipRect;
        var left;
        var top;
        tooltip.textContent = target.getAttribute("data-tooltip");
        tooltip.classList.add("is-visible");
        tipRect = tooltip.getBoundingClientRect();
        left = rect.left + ((rect.width - tipRect.width) / 2);
        left = Math.max(6, Math.min(left, window.innerWidth - tipRect.width - 6));
        top = rect.bottom + 7;
        if (top + tipRect.height > window.innerHeight - 6) {
            top = rect.top - tipRect.height - 7;
        }
        tooltip.style.left = left + "px";
        tooltip.style.top = top + "px";
    }

    function hideTooltip() {
        window.clearTimeout(tooltipTimer);
        tooltip.classList.remove("is-visible");
    }

    function showStatus(message, isError) {
        window.clearTimeout(statusTimer);
        statusLine.textContent = message;
        statusLine.classList.toggle("is-error", Boolean(isError));
        statusLine.classList.add("is-visible");
        statusTimer = window.setTimeout(function () {
            statusLine.classList.remove("is-visible");
        }, 1800);
    }

    function bindModal() {
        document.getElementById("modal-close").addEventListener("click", closeModal);
        modalBackdrop.addEventListener("mousedown", function (event) {
            if (event.target === modalBackdrop) {
                closeModal();
            }
        });
        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape" && modalBackdrop.classList.contains("is-open")) {
                closeModal();
            }
        });
    }

    function noteActivity(event) {
        timerState.lastActivity = Date.now();
        if (event && typeof event.clientX === "number" && typeof event.clientY === "number") {
            lastPointerX = event.clientX;
            lastPointerY = event.clientY;
        }
    }

    function bindActivity() {
        var events = ["mousedown", "mousemove", "keydown", "wheel", "touchstart"];
        var i;
        for (i = 0; i < events.length; i += 1) {
            document.addEventListener(events[i], noteActivity, { passive: true });
        }

        bridge.addEventListener("com.adobe.csxs.events.ApplicationActivate", function () {
            timerState.appActive = true;
            timerState.lastTick = Date.now();
            noteActivity();
        });
        bridge.addEventListener("com.adobe.csxs.events.ApplicationDeactivate", function () {
            timerState.appActive = false;
            timerState.lastTick = Date.now();
            persistTotal();
        });
    }

    function bindMarkerNavigation() {
        function editableTarget(target) {
            var tagName = target && target.tagName ? target.tagName.toLowerCase() : "";
            return tagName === "input" || tagName === "textarea" || tagName === "select" ||
                Boolean(target && target.isContentEditable);
        }

        function syncTextInputState() {
            bridge.setMarkerTextInputActive(editableTarget(document.activeElement));
        }

        lastMarkerCommandId = markerCommandId(bridge.readMarkerCommand());
        lastQuickSearchCommandId = markerCommandId(bridge.readQuickSearchCommand());
        syncMarkerNavigationSetting();
        syncQuickSearchSettings();
        refreshQuickSearchIndex();
        bridge.writeMarkerHeartbeat();
        bridge.setMarkerTextInputActive(false);
        markerNativeAvailable = Boolean(bridge.isCEP && bridge.startMarkerHotkeyHelper());
        startMarkerNavigationSocket();

        window.setInterval(function () {
            bridge.writeMarkerHeartbeat();
        }, 1000);
        window.setInterval(pollMarkerNavigationCommand, 25);
        window.setInterval(pollQuickSearchCommand, 25);
        window.setInterval(pollQuickSelectionRequest, 25);

        document.addEventListener("focusin", syncTextInputState);
        document.addEventListener("focusout", function () {
            window.setTimeout(syncTextInputState, 0);
        });
        document.addEventListener("keydown", function (event) {
            var target = event.target;
            var tagName = target && target.tagName ? target.tagName.toLowerCase() : "";
            var key = String(event.key || "").toLowerCase();
            var direction;
            if (markerNativeAvailable || !markerNavigationEnabled() || event.defaultPrevented ||
                    event.ctrlKey || event.altKey || event.metaKey || event.shiftKey) {
                return;
            }
            if (tagName === "input" || tagName === "textarea" || tagName === "select" ||
                    (target && target.isContentEditable)) {
                return;
            }
            if (key !== "j" && key !== "k") {
                return;
            }
            direction = key === "j" ? "previous" : "next";
            event.preventDefault();
            event.stopPropagation();
            executeMarkerNavigation(direction);
        });
    }

    function markerNavigationEnabled() {
        return false;
    }

    function executeMarkerNavigation(direction) {
        if (!bridge.navigateMarkerFast(direction)) {
            bridge.call("navigateMarker", [direction], function () {});
        }
    }

    function syncMarkerNavigationSetting() {
        bridge.setMarkerNavigationEnabled(markerNavigationEnabled());
    }

    function markerCommandId(commandText) {
        var separator = String(commandText || "").indexOf("|");
        return separator > 0 ? String(commandText).substring(0, separator) : "";
    }

    function startMarkerNavigationSocket() {
        if (!bridge.isCEP || typeof WebSocket === "undefined" ||
                (markerSocket && (markerSocket.readyState === 0 || markerSocket.readyState === 1))) {
            return;
        }
        try {
            markerSocket = new WebSocket("ws://127.0.0.1:47631/clear-marker");
            markerSocket.onopen = function () {
                markerSocketOpen = true;
            };
            markerSocket.onmessage = function (event) {
                dispatchNativeCommand(String(event.data || ""));
            };
            markerSocket.onerror = function () {
                try { markerSocket.close(); } catch (ignoreClose) {}
            };
            markerSocket.onclose = function () {
                markerSocketOpen = false;
                markerSocket = null;
                window.setTimeout(startMarkerNavigationSocket, 500);
            };
        } catch (ignoreSocket) {
            markerSocketOpen = false;
            markerSocket = null;
            window.setTimeout(startMarkerNavigationSocket, 500);
        }
    }

    function dispatchMarkerNavigationCommand(commandText) {
        var separator = String(commandText || "").indexOf("|");
        var commandId;
        var direction;
        if (!markerNavigationEnabled() || separator <= 0) {
            return;
        }
        commandId = commandText.substring(0, separator);
        direction = commandText.substring(separator + 1).trim();
        if (!commandId || commandId === lastMarkerCommandId || (direction !== "previous" && direction !== "next")) {
            return;
        }
        lastMarkerCommandId = commandId;
        executeMarkerNavigation(direction);
    }

    function dispatchNativeCommand(commandText) {
        var parts = String(commandText || "").split("|");
        if (parts.length >= 2 && parts[1] === "quick-selection-request") {
            handleQuickSelectionRequest(parts[0]);
            return;
        }
        if (parts.length >= 4 && parts[1] === "quick") {
            dispatchQuickSearchCommand(parts);
            return;
        }
        dispatchMarkerNavigationCommand(commandText);
    }

    function handleQuickSelectionRequest(requestId) {
        if (!requestId || requestId === lastQuickSelectionRequestId) {
            return;
        }
        lastQuickSelectionRequestId = requestId;
        bridge.getSelectedLayerCount(function (count) {
            bridge.writeQuickSearchSelectionResponse(requestId, count);
        });
    }

    function pollQuickSelectionRequest() {
        var request;
        if (markerSocketOpen) {
            return;
        }
        request = String(bridge.readQuickSearchSelectionRequest() || "").split("|");
        if (request.length >= 2 && request[1] === "quick-selection-request") {
            handleQuickSelectionRequest(request[0]);
        }
    }

    function dispatchQuickSearchCommand(parts) {
        var commandId = parts[0];
        var type = parts[2];
        var command;
        var displayName;
        var tool;
        var button;
        if (!quickSearchEnabled() || !commandId || commandId === lastQuickSearchCommandId) {
            return;
        }
        try { command = decodeURIComponent(parts[3] || ""); } catch (ignoreCommand) { command = parts[3] || ""; }
        try { displayName = decodeURIComponent(parts[4] || ""); } catch (ignoreName) { displayName = parts[4] || ""; }
        lastQuickSearchCommandId = commandId;
        if (type === "tool") {
            tool = toolMap[command];
            if (tool) {
                button = document.querySelector('[data-tool="' + command + '"]');
                executeTool(tool, button);
            }
        } else if (type === "effect") {
            bridge.call("applyEffect", [command, displayName], function () {});
        }
    }

    function pollMarkerNavigationCommand() {
        var commandText;
        if (!markerNavigationEnabled() || markerSocketOpen) {
            return;
        }
        commandText = bridge.readMarkerCommand();
        dispatchMarkerNavigationCommand(commandText);
    }

    function pollQuickSearchCommand() {
        if (!quickSearchEnabled()) {
            return;
        }
        dispatchNativeCommand(bridge.readQuickSearchCommand());
    }

    function getInactivityMs() {
        var minutes = Number(localStorage.getItem("clear:inactivityMinutes") || config.inactivityMinutes);
        return Math.max(1, minutes) * 60 * 1000;
    }

    function pauseWhenInactive() {
        return localStorage.getItem("clear:pauseWhenInactive") !== "0";
    }

    function pollProject() {
        var requestProjectState = bridge.getProjectState || function (callback) {
            bridge.call("getProjectState", [], callback);
        };
        requestProjectState(function (result) {
            var project = result && result.ok ? result.value : null;
            var detectedPath;
            var detectedKey;
            var sameUntitledProjectWasSaved;
            var projectChanged;
            if (!project || !project.open) {
                if (timerState.projectOpen) {
                    persistTotal();
                }
                timerState.projectOpen = false;
                timerState.projectKey = "";
                timerState.projectPath = "";
                timerState.projectSaved = false;
                timerState.projectSessionId = "";
                timerState.projectName = "";
                timerState.sessionMs = 0;
                timerState.baseTotalMs = 0;
                timerState.totalMs = 0;
                timerState.lastHostToken = "";
                updateAlignSelectionFromActivityToken("");
                timerState.persistElapsed = 0;
                timerState.lastTick = Date.now();
                updateTimeDisplay();
                return;
            }

            detectedPath = project.path || "";
            detectedKey = detectedPath || project.key || ("unsaved:" + String(project.sessionId || "active"));
            sameUntitledProjectWasSaved = timerState.projectOpen && !timerState.projectPath && Boolean(detectedPath);
            projectChanged = !timerState.projectOpen || (!sameUntitledProjectWasSaved &&
                (detectedKey !== timerState.projectKey || String(project.sessionId) !== String(timerState.projectSessionId)));

            if (projectChanged) {
                persistTotal();
                timerState.projectOpen = true;
                timerState.projectKey = detectedKey;
                timerState.projectPath = detectedPath;
                timerState.projectSaved = Boolean(detectedPath);
                timerState.projectSessionId = project.sessionId;
                timerState.projectName = project.name || "Untitled";
                timerState.sessionMs = 0;
                timerState.baseTotalMs = 0;
                timerState.totalMs = 0;
                timerState.lastTick = Date.now();
                timerState.lastActivity = Date.now();
                timerState.persistElapsed = 0;
                loadProjectTotal(project.sessionId, timerState.projectPath);
            } else if (sameUntitledProjectWasSaved) {
                timerState.projectKey = detectedKey;
                timerState.projectPath = detectedPath;
                timerState.projectSaved = true;
                loadProjectTotal(project.sessionId, timerState.projectPath);
            }

            timerState.projectOpen = true;
            timerState.projectSessionId = project.sessionId;
            if (project.activityToken && project.activityToken !== timerState.lastHostToken) {
                timerState.lastHostToken = project.activityToken;
                noteActivity();
                updateAlignSelectionFromActivityToken(project.activityToken);
            }
            updateTimeDisplay();
        });
    }

    function tickTimer() {
        var now = Date.now();
        var elapsed = Math.max(0, Math.min(now - timerState.lastTick, 2000));
        var isActive = timerState.projectOpen && (!pauseWhenInactive() || (timerState.appActive && now - timerState.lastActivity <= getInactivityMs()));
        timerState.lastTick = now;

        if (isActive) {
            timerState.sessionMs += elapsed;
            timerState.totalMs = timerState.baseTotalMs + timerState.sessionMs;
            timerState.persistElapsed += elapsed;
            if (timerState.persistElapsed >= 10000) {
                persistTotal();
                timerState.persistElapsed = 0;
            }
        }
        updateTimeDisplay();
    }

    function loadProjectTotal(sessionId, projectPath) {
        var cachedSeconds;
        if (!projectPath) {
            timerState.baseTotalMs = 0;
            timerState.totalMs = timerState.sessionMs;
            updateTimeDisplay();
            return;
        }
        cachedSeconds = Number(localStorage.getItem("clear:projectTotal:" + projectPath) || 0);
        if (isFinite(cachedSeconds) && cachedSeconds > 0) {
            timerState.baseTotalMs = cachedSeconds * 1000;
            timerState.totalMs = timerState.baseTotalMs + timerState.sessionMs;
            updateTimeDisplay();
        }
        bridge.call("getProjectTime", [projectPath], function (result) {
            var seconds;
            if (sessionId !== timerState.projectSessionId || projectPath !== timerState.projectPath) {
                return;
            }
            seconds = result && result.ok ? Number(result.value || 0) : 0;
            if (!(isFinite(seconds) && seconds > 0)) {
                seconds = isFinite(cachedSeconds) && cachedSeconds > 0 ? cachedSeconds : 0;
            }
            timerState.baseTotalMs = seconds * 1000;
            timerState.totalMs = timerState.baseTotalMs + timerState.sessionMs;
            updateTimeDisplay();
        });
    }

    function persistTotal() {
        var totalSeconds = Math.floor(timerState.totalMs / 1000);
        if (timerState.projectSaved && timerState.projectPath) {
            localStorage.setItem("clear:projectTotal:" + timerState.projectPath, String(totalSeconds));
            bridge.call("setProjectTime", [timerState.projectPath, totalSeconds], function () {});
        }
    }

    function formatTime(milliseconds) {
        var totalSeconds = Math.floor(milliseconds / 1000);
        var totalMinutes = Math.floor(totalSeconds / 60);
        var hours = Math.floor(totalMinutes / 60);
        var minutes = totalMinutes % 60;
        var seconds = totalSeconds % 60;
        return hours + "h " + (minutes < 10 ? "0" : "") + minutes + "m " +
            (seconds < 10 ? "0" : "") + seconds + "s";
    }

    function updateTimeDisplay() {
        sessionTimeEl.textContent = formatTime(timerState.sessionMs);
        totalTimeEl.textContent = formatTime(timerState.totalMs);
    }

    function initialize() {
        if (localStorage.getItem("clear:defaults:v101-ui") !== "1") {
            localStorage.setItem("clear:accentHue", "271");
            localStorage.setItem("clear:categoryView", "1");
            localStorage.setItem("clear:defaults:v101-ui", "1");
        }
        if (localStorage.getItem("clear:defaults:v100-category") !== "1") {
            localStorage.setItem("clear:categoryView", "1");
            localStorage.setItem("clear:defaults:v100-category", "1");
        }
        applyAccentTheme(accentHue(), true);
        renderQuickColors();
        renderPanel();
        bindUtilities();
        bindTooltip();
        bindQuickColorsResize();
        bindModal();
        searchFavoriteAction.addEventListener("click", toggleSearchFavorite);
        removeToolAction.addEventListener("click", removeContextTool);
        parentColorAction.addEventListener("click", toggleParentColorGrouping);
        parentOrganizeAction.addEventListener("click", toggleParentOrganize);
        anchorInlineAction.addEventListener("click", function () {
            setAnchorPointViewMode("inline");
        });
        anchorPopupAction.addEventListener("click", function () {
            setAnchorPointViewMode("popup");
        });
        editQuickColorsAction.addEventListener("click", function () {
            closeQuickColorsContextMenu();
            openSettings(true);
        });
        lockQuickColorsAction.addEventListener("click", toggleQuickColorsSizeLock);
        feedbackTelegramAction.addEventListener("click", function () {
            closeFeedbackMenu();
            bridge.openTelegramProfile("clearfx007");
        });
        feedbackInstagramAction.addEventListener("click", function () {
            closeFeedbackMenu();
            bridge.openInstagramProfile("clear7.fx");
        });
        feedbackDiscordAction.addEventListener("click", function () {
            closeFeedbackMenu();
            bridge.openDiscordInvite("WDeZWH8Ees");
        });
        bindMarkerNavigation();
        bindActivity();
        loadEffects();
        refresh3DModeState();
        refreshParentLinkState();
        pollProject();
        window.setInterval(tickTimer, 1000);
        window.setInterval(pollProject, 1000);
        window.setInterval(refreshAlignToolbarState, 700);
        window.addEventListener("beforeunload", persistTotal);
        window.addEventListener("unload", persistTotal);
        window.addEventListener("resize", function () {
            closeSearch();
            closeToolContextMenu();
            closeQuickColorsContextMenu();
            closeFeedbackMenu();
            closeAnchorPointPopup();
            hideTooltip();
            applySavedQuickColorsHeight();
            scheduleResponsiveToolSizing();
        });
        document.addEventListener("mousedown", function (event) {
            if (searchFavoriteMenu.classList.contains("is-open") && !searchFavoriteMenu.contains(event.target)) {
                closeSearchFavoriteMenu();
            }
            if (toolContextMenu.classList.contains("is-open") && !toolContextMenu.contains(event.target)) {
                closeToolContextMenu();
            }
            if (quickColorsContextMenu.classList.contains("is-open") && !quickColorsContextMenu.contains(event.target)) {
                closeQuickColorsContextMenu();
            }
            var utilityTarget = closestWithAttribute(event.target, "data-utility");
            if (feedbackMenu.classList.contains("is-open") && !feedbackMenu.contains(event.target) &&
                    (!utilityTarget || utilityTarget.getAttribute("data-utility") !== "feedback")) {
                closeFeedbackMenu();
            }
            if (anchorPointPopup && anchorPointPopup.classList.contains("is-open") &&
                    !anchorPointPopup.contains(event.target) &&
                    (!anchorPointTrigger || !anchorPointTrigger.contains(event.target))) {
                closeAnchorPointPopup();
            }
            if (!searchResults.contains(event.target) && (!currentSearchInput || event.target !== currentSearchInput)) {
                closeSearch();
            }
        });
        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape") {
                closeFeedbackMenu();
                closeAnchorPointPopup();
            }
        });
    }

    initialize();
}());
