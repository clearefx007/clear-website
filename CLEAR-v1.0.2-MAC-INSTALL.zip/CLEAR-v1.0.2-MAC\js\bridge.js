(function () {
    "use strict";

    var cep = window.__adobe_cep__;

    function isMacPlatform() {
        return /mac/i.test(String(navigator.platform || ""));
    }

    function parseResult(value) {
        if (value === undefined || value === null || value === "") {
            return null;
        }
        try {
            return JSON.parse(value);
        } catch (ignore) {
            return value;
        }
    }

    function callHost(method, args, callback) {
        var serialized = JSON.stringify(args || []);
        var extensionPath = getExtensionPath();
        var expression = "(function(){try{if(typeof CLEAR!=='undefined'){CLEAR._extensionPath=" +
            JSON.stringify(extensionPath) + ";}}catch(e){}return CLEAR.invoke(" +
            JSON.stringify(method) + "," + JSON.stringify(serialized) + ");}())";

        if (!cep || typeof cep.evalScript !== "function") {
            window.setTimeout(function () {
                callback(mockResult(method, args || []));
            }, 30);
            return;
        }

        cep.evalScript(expression, function (result) {
            callback(parseResult(result));
        });
    }

    function getProjectState(callback) {
        var expression;
        if (!cep || typeof cep.evalScript !== "function") {
            callback(mockResult("getProjectState", []));
            return;
        }
        expression = "(function(){try{" +
            "var p=app.project;if(!p){return 'CLEAR_PROJECT|0||||';}" +
            "var f=null,path='',name='Untitled Project',activity=[],item=null,selected=[],i;" +
            "try{f=p.file;}catch(e1){}" +
            "if(f){try{path=f.fsName||'';}catch(e2){}try{name=f.displayName||name;}catch(e3){}}" +
            "else{try{name=p.name||name;}catch(e4){}}" +
            "try{activity.push(p.numItems);}catch(e5){}" +
            "try{item=p.activeItem;if(item&&item instanceof CompItem){activity.push(item.id);activity.push(Math.round(item.time*1000)/1000);selected=item.selectedLayers;for(i=0;i<selected.length;i++){activity.push(selected[i].index);}}}catch(e6){}" +
            "return 'CLEAR_PROJECT|1|'+encodeURIComponent(path)+'|'+encodeURIComponent(name)+'|'+encodeURIComponent(activity.join(','));" +
            "}catch(e){return 'CLEAR_PROJECT|0||||';}}())";
        cep.evalScript(expression, function (value) {
            var parts = String(value || "").split("|");
            var path;
            var name;
            var activity;
            if (parts[0] !== "CLEAR_PROJECT" || parts[1] !== "1") {
                callback({ ok: true, value: { open: false, key: "", path: "", saved: false, sessionId: "", name: "", activityToken: "" } });
                return;
            }
            try { path = decodeURIComponent(parts[2] || ""); } catch (ignorePath) { path = parts[2] || ""; }
            try { name = decodeURIComponent(parts[3] || ""); } catch (ignoreName) { name = parts[3] || "Untitled Project"; }
            try { activity = decodeURIComponent(parts[4] || ""); } catch (ignoreActivity) { activity = parts[4] || ""; }
            callback({
                ok: true,
                value: {
                    open: true,
                    key: path || ("unsaved:" + name),
                    path: path,
                    saved: Boolean(path),
                    sessionId: path || ("unsaved:" + name),
                    name: name,
                    activityToken: activity
                }
            });
        });
    }

    function navigateMarkerFast(direction) {
        var safeDirection = direction === "previous" ? "previous" : "next";
        if (!cep || typeof cep.evalScript !== "function") {
            return false;
        }
        try {
            cep.evalScript("(typeof CLEAR.navigateMarkerFast === 'function' ? CLEAR.navigateMarkerFast('" +
                safeDirection + "') : CLEAR._methods.navigateMarker('" + safeDirection + "'))", function () {});
            return true;
        } catch (ignoreNavigation) {}
        return false;
    }

    function openEffectControls() {
        if (!cep || typeof cep.evalScript !== "function") {
            return false;
        }
        try {
            cep.evalScript("(function(){try{var id=app.findMenuCommandId('Effect Controls');if(id){app.executeCommand(id);}}catch(e){}}())", function () {});
            return true;
        } catch (ignoreOpen) {}
        return false;
    }

    function addEventListener(type, handler) {
        if (cep && typeof cep.addEventListener === "function") {
            cep.addEventListener(type, handler);
        }
    }

    function openURL(url) {
        var utility = window.cep && window.cep.util;
        var expression;
        if (!url) {
            return false;
        }
        if (utility && typeof utility.openURLInDefaultBrowser === "function") {
            utility.openURLInDefaultBrowser(url);
            return true;
        }
        if (cep && typeof cep.evalScript === "function" && isMacPlatform()) {
            expression = "(function(){try{system.callSystem('open '+" +
                JSON.stringify(JSON.stringify(String(url))) +
                ");return '1';}catch(e){return '0';}}())";
            try {
                cep.evalScript(expression, function () {});
                return true;
            } catch (ignoreMacOpen) {}
        }
        return false;
    }

    function openTelegramProfile(username) {
        var handle = String(username || "").replace(/^@/, "");
        var tgURL = "tg://resolve?domain=" + encodeURIComponent(handle);
        var webURL = "https://web.telegram.org/k/#@" + encodeURIComponent(handle);
        var expression;
        if (!handle) {
            return false;
        }
        if (!cep || typeof cep.evalScript !== "function" || !/win/i.test(navigator.platform || "")) {
            return openURL(webURL);
        }
        expression = "(function(){try{" +
            "function exists(path){try{return path&&File(path).exists;}catch(e){return false;}}" +
            "var protocol=system.callSystem('cmd.exe /d /c reg query HKCR\\\\tg /v \"URL Protocol\" 2^>nul');" +
            "if(!/URL Protocol/i.test(String(protocol||''))){return '0';}" +
            "var command=system.callSystem('cmd.exe /d /c reg query HKCR\\\\tg\\\\shell\\\\open\\\\command /ve 2^>nul');" +
            "var text=String(command||'');" +
            "var match=text.match(/\"([^\"]*Telegram(?: Desktop)?[\\\\\\\\\\/]+Telegram\\.exe)\"/i)||text.match(/([A-Z]:[^\\r\\n]*Telegram(?: Desktop)?[\\\\\\\\\\/]+Telegram\\.exe)/i);" +
            "return match&&exists(match[1])?'1':'0';" +
            "}catch(e){return '0';}}())";
        try {
            cep.evalScript(expression, function (result) {
                openURL(String(result || "") === "1" ? tgURL : webURL);
            });
            return true;
        } catch (ignoreTelegram) {}
        return openURL(webURL);
    }

    function openInstagramProfile(username) {
        var handle = String(username || "").replace(/^@/, "");
        var appURL = "instagram://user?username=" + encodeURIComponent(handle);
        var webURL = "https://www.instagram.com/" + encodeURIComponent(handle) + "/";
        var expression;
        if (!handle) {
            return false;
        }
        if (!cep || typeof cep.evalScript !== "function" || !/win/i.test(navigator.platform || "")) {
            return openURL(webURL);
        }
        expression = "(function(){try{" +
            "var out=system.callSystem('cmd.exe /d /c reg query HKCR\\\\instagram /v \"URL Protocol\" 2^>nul');" +
            "return /URL Protocol/i.test(String(out||''))?'1':'0';" +
            "}catch(e){return '0';}}())";
        try {
            cep.evalScript(expression, function (result) {
                openURL(String(result || "") === "1" ? appURL : webURL);
            });
            return true;
        } catch (ignoreInstagram) {}
        return openURL(webURL);
    }

    function openDiscordInvite(inviteCode) {
        var code = String(inviteCode || "").replace(/^https?:\/\/discord\.gg\//i, "");
        var appURL = "discord://discord.com/invite/" + encodeURIComponent(code);
        var webURL = "https://discord.gg/" + encodeURIComponent(code);
        var expression;
        if (!code) {
            return false;
        }
        if (!cep || typeof cep.evalScript !== "function" || !/win/i.test(navigator.platform || "")) {
            return openURL(webURL);
        }
        expression = "(function(){try{" +
            "var protocol=system.callSystem('cmd.exe /d /c reg query HKCR\\\\discord /v \"URL Protocol\" 2^>nul');" +
            "return /URL Protocol/i.test(String(protocol||''))?'1':'0';" +
            "}catch(e){return '0';}}())";
        try {
            cep.evalScript(expression, function (result) {
                openURL(String(result || "") === "1" ? appURL : webURL);
            });
            return true;
        } catch (ignoreDiscord) {}
        return openURL(webURL);
    }

    function getExtensionPath() {
        var extensionPath;
        if (!cep || typeof cep.getSystemPath !== "function") {
            return "";
        }
        extensionPath = decodeURI(cep.getSystemPath("extension"));
        extensionPath = extensionPath.replace(/^file:\/\/\//i, "");
        if (/^\/[a-z]:/i.test(extensionPath)) {
            extensionPath = extensionPath.substring(1);
        }
        return extensionPath.replace(/\\/g, "/").replace(/\/$/, "");
    }

    function chooseFolder(initialPath) {
        var fileSystem = window.cep && window.cep.fs;
        var result;
        if (!fileSystem || typeof fileSystem.showOpenDialog !== "function") {
            return "";
        }
        result = fileSystem.showOpenDialog(false, true, "Choose PNG Output Folder", initialPath || "", []);
        if (result && result.err === 0 && result.data && result.data.length) {
            return result.data[0];
        }
        return "";
    }

    function copyText(value) {
        var utility = window.cep && window.cep.util;
        var field;
        var copied = false;
        try {
            field = document.createElement("textarea");
            field.value = String(value);
            field.setAttribute("readonly", "readonly");
            field.style.position = "fixed";
            field.style.opacity = "0";
            field.style.userSelect = "text";
            document.body.appendChild(field);
            field.select();
            copied = document.execCommand("copy");
            document.body.removeChild(field);
        } catch (ignore) {}
        if (!copied && utility && typeof utility.setClipboardData === "function") {
            try {
                utility.setClipboardData(String(value));
                copied = true;
            } catch (ignoreUtility) {}
        }
        return copied;
    }

    function markerFileSystem() {
        if (isMacPlatform()) {
            return null;
        }
        return window.cep && window.cep.fs ? window.cep.fs : null;
    }

    function writeMarkerState(fileName, value) {
        var fileSystem = markerFileSystem();
        if (!fileSystem || typeof fileSystem.writeFile !== "function") {
            return false;
        }
        try {
            if (typeof fileSystem.makedir === "function") {
                fileSystem.makedir("D:/clear/data");
            }
            return fileSystem.writeFile("D:/clear/data/" + fileName, String(value)).err === 0;
        } catch (ignoreWrite) {}
        return false;
    }

    function startMarkerHotkeyHelper() {
        var processApi = window.cep && window.cep.process;
        var helperPath;
        var processId;
        if (isMacPlatform()) {
            return false;
        }
        if (!processApi || typeof processApi.createProcess !== "function") {
            return false;
        }
        try {
            helperPath = getExtensionPath() + "/bin/ClearMarkerHotkey.exe";
            processId = processApi.createProcess(helperPath);
            return Number(processId) > 0;
        } catch (ignoreProcess) {}
        return false;
    }

    function setMarkerNavigationEnabled(enabled) {
        return writeMarkerState("marker_navigation_enabled.txt", enabled ? "1" : "0");
    }

    function writeMarkerHeartbeat() {
        return writeMarkerState("marker_navigation_heartbeat.txt", String(Date.now()));
    }

    function setMarkerTextInputActive(active) {
        return writeMarkerState("marker_text_input_active.txt", active ? "1" : "0");
    }

    function readMarkerCommand() {
        var fileSystem = markerFileSystem();
        var result;
        if (!fileSystem || typeof fileSystem.readFile !== "function") {
            return "";
        }
        try {
            result = fileSystem.readFile("D:/clear/data/marker_navigation_command.txt");
            return result && result.err === 0 ? String(result.data || "") : "";
        } catch (ignoreRead) {}
        return "";
    }

    function setQuickSearchSettings(enabled, hotkey, favoritesFirst) {
        writeMarkerState("quick_search_enabled.txt", enabled ? "1" : "0");
        writeMarkerState("quick_search_hotkey.txt", hotkey || "Ctrl+Space");
        writeMarkerState("quick_search_favorites_first.txt", favoritesFirst ? "1" : "0");
    }

    function setQuickSearchAccent(color) {
        return writeMarkerState("quick_search_accent.txt", color || "#A855F7");
    }

    function getSelectedLayerCount(callback) {
        var expression;
        if (!cep || typeof cep.evalScript !== "function") {
            callback(0);
            return;
        }
        expression = "(function(){try{var c=app.project&&app.project.activeItem,selected=[],indexes=[],i;" +
            "if(c&&c instanceof CompItem){selected=c.selectedLayers;for(i=0;i<selected.length;i++){indexes.push(selected[i].index);}" +
            "if(typeof CLEAR!=='undefined'){CLEAR._quickSearchCompRef=c;CLEAR._quickSearchLayerIndexes=indexes;}" +
            "return selected.length;}" +
            "if(typeof CLEAR!=='undefined'){CLEAR._quickSearchCompRef=null;CLEAR._quickSearchLayerIndexes=[];}" +
            "return 0;}catch(e){return 0;}}())";
        cep.evalScript(expression, function (value) {
            callback(Math.max(0, parseInt(value, 10) || 0));
        });
    }

    function readQuickSearchSelectionRequest() {
        var fileSystem = markerFileSystem();
        var result;
        if (!fileSystem || typeof fileSystem.readFile !== "function") {
            return "";
        }
        try {
            result = fileSystem.readFile("D:/clear/data/quick_search_selection_request.txt");
            return result && result.err === 0 ? String(result.data || "") : "";
        } catch (ignoreRead) {}
        return "";
    }

    function writeQuickSearchSelectionResponse(requestId, selectedCount) {
        return writeMarkerState("quick_search_selection_response.txt", requestId + "|" + selectedCount);
    }

    function writeQuickSearchIndex(indexJSON) {
        return writeMarkerState("quick_search_index.json", indexJSON || "[]");
    }

    function readQuickSearchFavorites() {
        var fileSystem = markerFileSystem();
        var result;
        if (!fileSystem || typeof fileSystem.readFile !== "function") {
            return [];
        }
        try {
            result = fileSystem.readFile("D:/clear/data/quick_search_favorites.json");
            if (result && result.err === 0 && result.data) {
                result = JSON.parse(result.data);
                return result && result.favorites instanceof Array ? result.favorites : [];
            }
        } catch (ignoreFavorites) {}
        return [];
    }

    function writeQuickSearchFavorites(favorites) {
        return writeMarkerState("quick_search_favorites.json", JSON.stringify({ favorites: favorites || [] }));
    }

    function readQuickSearchCommand() {
        var fileSystem = markerFileSystem();
        var result;
        if (!fileSystem || typeof fileSystem.readFile !== "function") {
            return "";
        }
        try {
            result = fileSystem.readFile("D:/clear/data/quick_search_command.txt");
            return result && result.err === 0 ? String(result.data || "") : "";
        } catch (ignoreRead) {}
        return "";
    }

    function requestQuickSearchOpen() {
        return writeMarkerState("quick_search_open_request.txt", String(Date.now()) + "|" + String(Math.random()).slice(2));
    }

    function beginQuickSearchShortcutCapture() {
        writeMarkerState("quick_search_capture_result.txt", "");
        return writeMarkerState("quick_search_capture_active.txt", "1");
    }

    function endQuickSearchShortcutCapture() {
        return writeMarkerState("quick_search_capture_active.txt", "0");
    }

    function readQuickSearchShortcutCapture() {
        var fileSystem = markerFileSystem();
        var result;
        if (!fileSystem || typeof fileSystem.readFile !== "function") {
            return "";
        }
        try {
            result = fileSystem.readFile("D:/clear/data/quick_search_capture_result.txt");
            return result && result.err === 0 ? String(result.data || "").trim() : "";
        } catch (ignoreRead) {}
        return "";
    }

    function mockResult(method, args) {
        if (method === "getEffects") {
            return {
                ok: true,
                value: [
                    { name: "Gaussian Blur", matchName: "ADBE Gaussian Blur 2", category: "Blur & Sharpen" },
                    { name: "Fill", matchName: "ADBE Fill", category: "Generate" },
                    { name: "Glow", matchName: "ADBE Glo2", category: "Stylize" },
                    { name: "Lumetri Color", matchName: "ADBE Lumetri", category: "Color Correction" },
                    { name: "Drop Shadow", matchName: "ADBE Drop Shadow", category: "Perspective" }
                ]
            };
        }
        if (method === "getSelectedEffects") {
            return {
                ok: true,
                value: [
                    { name: "Gaussian Blur", matchName: "ADBE Gaussian Blur 2", count: 2 },
                    { name: "Fill", matchName: "ADBE Fill", count: 1 },
                    { name: "Glow", matchName: "ADBE Glo2", count: 1 }
                ]
            };
        }
        if (method === "getProjectState") {
            return {
                ok: true,
                value: {
                    open: true,
                    key: "preview-project",
                    sessionId: "preview-session",
                    name: "Browser Preview",
                    activityToken: "preview"
                }
            };
        }
        return { ok: true, value: args || true };
    }

    window.CLEAR_BRIDGE = {
        call: callHost,
        getProjectState: getProjectState,
        navigateMarkerFast: navigateMarkerFast,
        openEffectControls: openEffectControls,
        addEventListener: addEventListener,
        openURL: openURL,
        openTelegramProfile: openTelegramProfile,
        openInstagramProfile: openInstagramProfile,
        openDiscordInvite: openDiscordInvite,
        getExtensionPath: getExtensionPath,
        chooseFolder: chooseFolder,
        copyText: copyText,
        startMarkerHotkeyHelper: startMarkerHotkeyHelper,
        setMarkerNavigationEnabled: setMarkerNavigationEnabled,
        writeMarkerHeartbeat: writeMarkerHeartbeat,
        setMarkerTextInputActive: setMarkerTextInputActive,
        readMarkerCommand: readMarkerCommand,
        setQuickSearchSettings: setQuickSearchSettings,
        setQuickSearchAccent: setQuickSearchAccent,
        getSelectedLayerCount: getSelectedLayerCount,
        readQuickSearchSelectionRequest: readQuickSearchSelectionRequest,
        writeQuickSearchSelectionResponse: writeQuickSearchSelectionResponse,
        writeQuickSearchIndex: writeQuickSearchIndex,
        readQuickSearchFavorites: readQuickSearchFavorites,
        writeQuickSearchFavorites: writeQuickSearchFavorites,
        readQuickSearchCommand: readQuickSearchCommand,
        requestQuickSearchOpen: requestQuickSearchOpen,
        beginQuickSearchShortcutCapture: beginQuickSearchShortcutCapture,
        endQuickSearchShortcutCapture: endQuickSearchShortcutCapture,
        readQuickSearchShortcutCapture: readQuickSearchShortcutCapture,
        isCEP: Boolean(cep && typeof cep.evalScript === "function")
    };
}());
