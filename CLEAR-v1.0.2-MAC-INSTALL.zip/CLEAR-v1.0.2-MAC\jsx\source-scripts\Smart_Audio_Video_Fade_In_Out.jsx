{
    var comp = app.project.activeItem;

    if (!(comp instanceof CompItem)) {
        alert("Open a composition and select one or more layers.");
    } else if (comp.selectedLayers.length === 0) {
        alert("Select at least one audio or video layer.");
    } else {
        var fadeSec = parseFloat(prompt("Fade duration (seconds):", "0.5"));

        if (isNaN(fadeSec) || fadeSec <= 0) {
            alert("Invalid fade duration.");
        } else {
            app.beginUndoGroup("Smart Audio and Video Fade In Out");

            var processedAudio = 0;
            var processedVideo = 0;

            for (var i = 0; i < comp.selectedLayers.length; i++) {
                var layer = comp.selectedLayers[i];
                var inT = layer.inPoint;
                var outT = layer.outPoint;

                if (outT <= inT) {
                    continue;
                }

                var fadeInEnd = inT + fadeSec;
                var fadeOutStart = outT - fadeSec;

                // Prevent fade-in and fade-out from crossing on short layers.
                if (fadeInEnd > fadeOutStart) {
                    fadeInEnd = (inT + outT) / 2;
                    fadeOutStart = fadeInEnd;
                }

                // Video, image, text, shape, solid, or precomp layer:
                // create an opacity fade.
                if (layer.hasVideo) {
                    var transformGroup = layer.property("ADBE Transform Group");
                    var opacity = transformGroup ? transformGroup.property("ADBE Opacity") : null;

                    if (opacity) {
                        while (opacity.numKeys > 0) {
                            opacity.removeKey(1);
                        }

                        opacity.setValueAtTime(inT, 0);
                        opacity.setValueAtTime(fadeInEnd, 100);
                        opacity.setValueAtTime(fadeOutStart, 100);
                        opacity.setValueAtTime(outT, 0);

                        processedVideo++;
                    }
                }

                // Audio layer, or a video layer containing audio:
                // create an Audio Levels fade.
                if (layer.hasAudio) {
                    var audioGroup = layer.property("ADBE Audio Group");
                    var audioLevels = audioGroup ? audioGroup.property("ADBE Audio Levels") : null;

                    if (audioLevels) {
                        while (audioLevels.numKeys > 0) {
                            audioLevels.removeKey(1);
                        }

                        var silent = [-48, -48];
                        var normal = [0, 0];

                        audioLevels.setValueAtTime(inT, silent);
                        audioLevels.setValueAtTime(fadeInEnd, normal);
                        audioLevels.setValueAtTime(fadeOutStart, normal);
                        audioLevels.setValueAtTime(outT, silent);

                        processedAudio++;
                    }
                }
            }

            app.endUndoGroup();

            if (processedAudio === 0 && processedVideo === 0) {
                alert("No compatible audio or video layers were found in the selection.");
            }
        }
    }
}
