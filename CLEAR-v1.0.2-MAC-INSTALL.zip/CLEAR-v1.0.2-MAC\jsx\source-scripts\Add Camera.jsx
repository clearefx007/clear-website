app.beginUndoGroup("Add Camera with Settings");

var comp = app.project.activeItem;

if (comp && comp instanceof CompItem) {
    var selectedLayers = comp.selectedLayers;

    if (selectedLayers.length === 0) {
        alert("Select at least one layer to match the camera timing.");
    } else {

        // Use the first selected layer as reference
        var refLayer = selectedLayers[0];

        // ==== Camera Settings Dialog ====
        var dlg = new Window("dialog", "Camera Settings");

        dlg.orientation = "column";
        dlg.alignChildren = ["fill", "top"];

        // Camera name
        var nameGroup = dlg.add("group");
        nameGroup.add("statictext", undefined, "Camera name:");
        var nameEdit = nameGroup.add("edittext", undefined, "Camera 1");
        nameEdit.characters = 20;

        // Focal length
        var focalGroup = dlg.add("group");
        focalGroup.add("statictext", undefined, "Focal length (mm):");
        var focalEdit = focalGroup.add("edittext", undefined, "35");
        focalEdit.characters = 6;

        // Zoom
        var zoomGroup = dlg.add("group");
        zoomGroup.add("statictext", undefined, "Zoom:");
        var zoomEdit = zoomGroup.add("edittext", undefined, "2000");
        zoomEdit.characters = 6;

        // Buttons
        var btnGroup = dlg.add("group");
        btnGroup.alignment = ["center", "bottom"];
        var okBtn = btnGroup.add("button", undefined, "OK");
        var cancelBtn = btnGroup.add("button", undefined, "Cancel");

        var result = dlg.show();
        if (result == 1) {
            // User pressed OK
            var camName   = nameEdit.text;
            var focalLen  = parseFloat(focalEdit.text);
            var zoomVal   = parseFloat(zoomEdit.text);

            if (isNaN(focalLen)) focalLen = 35;
            if (isNaN(zoomVal))  zoomVal  = 2000;

            // ==== Create Camera ====
            var camPos = [comp.width / 2, comp.height / 2]; // center of comp
            var cam = comp.layers.addCamera(camName, camPos);

            // DO NOT set cam.label (keeps AE default camera color)

            // Set camera options
            var camOptions = cam.property("ADBE Camera Options Group");
            if (camOptions) {
                var zoomProp = camOptions.property("ADBE Camera Zoom");
                if (zoomProp) zoomProp.setValue(zoomVal);

                var focalProp = camOptions.property("ADBE Camera Focal Length");
                if (focalProp) focalProp.setValue(focalLen);
            }

            // Match timing to reference layer (visible part)
            cam.inPoint  = refLayer.inPoint;
            cam.outPoint = refLayer.outPoint;

            // Put the camera above the reference layer
            cam.moveBefore(refLayer);
        }
    }
} else {
    alert("No active composition found.");
}

app.endUndoGroup();
