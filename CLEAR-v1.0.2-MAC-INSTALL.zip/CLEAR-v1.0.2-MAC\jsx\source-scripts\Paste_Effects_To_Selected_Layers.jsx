/*
    Paste Effects To Selected Layers
    --------------------------------
    1. Copy one or more effects in After Effects.
    2. Select all destination layers.
    3. Run this script.

    Stretch checked:
      - Newly pasted effect keyframes are stretched from each layer's
        In Point to Out Point.

    Stretch unchecked:
      - Newly pasted effect keyframes keep their original spacing.
      - Their first keyframe is aligned to each layer's In Point.
*/

(function pasteEffectsToSelectedLayers() {
    var comp = app.project.activeItem;

    if (!(comp instanceof CompItem)) {
        alert("Open a composition and select destination layers.");
        return;
    }

    if (comp.selectedLayers.length === 0) {
        alert("Select at least one destination layer.");
        return;
    }

    var targets = [];
    var i;

    for (i = 0; i < comp.selectedLayers.length; i++) {
        targets.push(comp.selectedLayers[i]);
    }

    var dialog = new Window("dialog", "Paste Copied Effects");
    dialog.orientation = "column";
    dialog.alignChildren = ["left", "top"];
    dialog.spacing = 10;
    dialog.margins = 16;

    dialog.add("statictext", undefined, "Paste the previously copied effect(s) to all selected layers.");

    var stretchCheckbox = dialog.add(
        "checkbox",
        undefined,
        "Stretch keyframes to each layer length"
    );
    stretchCheckbox.value = false;

    dialog.add(
        "statictext",
        undefined,
        "Unticked: keep keyframe spacing and align the first key to the layer In Point."
    );

    var buttons = dialog.add("group");
    buttons.alignment = "right";
    buttons.add("button", undefined, "Cancel", {name: "cancel"});
    buttons.add("button", undefined, "Paste", {name: "ok"});

    if (dialog.show() !== 1) {
        return;
    }

    var shouldStretch = stretchCheckbox.value;
    var pasteCommandId = app.findMenuCommandId("Paste");

    // Fallback command ID for Paste if the localized menu name is unavailable.
    if (!pasteCommandId) {
        pasteCommandId = 20;
    }

    var pastedLayerCount = 0;
    var failedLayers = [];

    app.beginUndoGroup("Paste Effects To Selected Layers");

    try {
        comp.openInViewer();

        clearSelections(comp);

        for (i = 0; i < targets.length; i++) {
            var layer = targets[i];

            if (layer.locked) {
                failedLayers.push(layer.name + " (locked)");
                continue;
            }

            clearSelections(comp);
            layer.selected = true;

            var effects = layer.property("ADBE Effect Parade");
            var beforeCount = effects ? effects.numProperties : 0;

            app.executeCommand(pasteCommandId);

            effects = layer.property("ADBE Effect Parade");
            var afterCount = effects ? effects.numProperties : 0;

            if (!effects || afterCount <= beforeCount) {
                failedLayers.push(layer.name);
                continue;
            }

            pastedLayerCount++;

            // Only modify the newly pasted effects, never pre-existing effects.
            for (var effectIndex = beforeCount + 1; effectIndex <= afterCount; effectIndex++) {
                var pastedEffect = effects.property(effectIndex);

                if (pastedEffect) {
                    retimePropertiesRecursively(
                        pastedEffect,
                        layer.inPoint,
                        layer.outPoint,
                        shouldStretch
                    );
                }
            }
        }
    } catch (error) {
        alert("Unable to paste the copied effects.\n\n" + error.toString());
    } finally {
        clearSelections(comp);

        for (i = 0; i < targets.length; i++) {
            try {
                targets[i].selected = true;
            } catch (selectionError) {
                // Ignore selection restoration errors.
            }
        }

        app.endUndoGroup();
    }

    if (pastedLayerCount === 0) {
        alert(
            "No effects were pasted.\n\n" +
            "Copy one or more effects from the Effect Controls panel, " +
            "select the destination layers, and run the script again."
        );
    } else if (failedLayers.length > 0) {
        alert(
            "Effects pasted to " + pastedLayerCount + " layer(s).\n\n" +
            "Could not paste to:\n- " + failedLayers.join("\n- ")
        );
    }

    function clearSelections(activeComp) {
        var selectedProps;
        var p;
        var l;

        try {
            selectedProps = activeComp.selectedProperties;

            for (p = selectedProps.length - 1; p >= 0; p--) {
                try {
                    selectedProps[p].selected = false;
                } catch (propertySelectionError) {
                    // Some property types cannot be deselected directly.
                }
            }
        } catch (selectedPropertiesError) {
            // Ignore if selectedProperties is unavailable.
        }

        for (l = 1; l <= activeComp.numLayers; l++) {
            try {
                activeComp.layer(l).selected = false;
            } catch (layerSelectionError) {
                // Ignore layers that cannot change selection state.
            }
        }
    }

    function retimePropertiesRecursively(group, layerIn, layerOut, stretch) {
        if (!group) {
            return;
        }

        if (group.propertyType === PropertyType.PROPERTY) {
            retimeProperty(group, layerIn, layerOut, stretch);
            return;
        }

        for (var propertyIndex = 1; propertyIndex <= group.numProperties; propertyIndex++) {
            retimePropertiesRecursively(
                group.property(propertyIndex),
                layerIn,
                layerOut,
                stretch
            );
        }
    }

    function retimeProperty(prop, layerIn, layerOut, stretch) {
        if (!prop.canVaryOverTime || prop.numKeys < 1) {
            return;
        }

        var keys = [];
        var keyIndex;

        for (keyIndex = 1; keyIndex <= prop.numKeys; keyIndex++) {
            keys.push(captureKey(prop, keyIndex));
        }

        var firstTime = keys[0].time;
        var lastTime = keys[keys.length - 1].time;
        var originalSpan = lastTime - firstTime;
        var layerDuration = layerOut - layerIn;

        while (prop.numKeys > 0) {
            prop.removeKey(1);
        }

        for (keyIndex = 0; keyIndex < keys.length; keyIndex++) {
            var newTime;

            if (stretch && keys.length > 1 && originalSpan > 0 && layerDuration > 0) {
                var normalizedTime = (keys[keyIndex].time - firstTime) / originalSpan;
                newTime = layerIn + (normalizedTime * layerDuration);
            } else {
                // Preserve spacing, but align the first keyframe with the layer start.
                newTime = keys[keyIndex].time + (layerIn - firstTime);
            }

            restoreKey(prop, newTime, keys[keyIndex]);
        }
    }

    function captureKey(prop, keyIndex) {
        var keyData = {
            time: prop.keyTime(keyIndex),
            value: prop.keyValue(keyIndex),
            inInterpolation: prop.keyInInterpolationType(keyIndex),
            outInterpolation: prop.keyOutInterpolationType(keyIndex),
            easeIn: null,
            easeOut: null,
            temporalContinuous: null,
            temporalAutoBezier: null,
            spatialContinuous: null,
            spatialAutoBezier: null,
            inSpatialTangent: null,
            outSpatialTangent: null,
            roving: null
        };

        try {
            keyData.easeIn = prop.keyInTemporalEase(keyIndex);
            keyData.easeOut = prop.keyOutTemporalEase(keyIndex);
        } catch (easeError) {}

        try {
            keyData.temporalContinuous = prop.keyTemporalContinuous(keyIndex);
        } catch (temporalContinuousError) {}

        try {
            keyData.temporalAutoBezier = prop.keyTemporalAutoBezier(keyIndex);
        } catch (temporalAutoBezierError) {}

        try {
            if (prop.isSpatial) {
                keyData.spatialContinuous = prop.keySpatialContinuous(keyIndex);
                keyData.spatialAutoBezier = prop.keySpatialAutoBezier(keyIndex);
                keyData.inSpatialTangent = prop.keyInSpatialTangent(keyIndex);
                keyData.outSpatialTangent = prop.keyOutSpatialTangent(keyIndex);
                keyData.roving = prop.keyRoving(keyIndex);
            }
        } catch (spatialError) {}

        return keyData;
    }

    function restoreKey(prop, time, keyData) {
        var newKeyIndex = prop.addKey(time);

        prop.setValueAtKey(newKeyIndex, keyData.value);

        try {
            prop.setInterpolationTypeAtKey(
                newKeyIndex,
                keyData.inInterpolation,
                keyData.outInterpolation
            );
        } catch (interpolationError) {}

        try {
            if (keyData.easeIn !== null && keyData.easeOut !== null) {
                prop.setTemporalEaseAtKey(newKeyIndex, keyData.easeIn, keyData.easeOut);
            }
        } catch (temporalEaseError) {}

        try {
            if (keyData.temporalContinuous !== null) {
                prop.setTemporalContinuousAtKey(newKeyIndex, keyData.temporalContinuous);
            }
        } catch (setTemporalContinuousError) {}

        try {
            if (keyData.temporalAutoBezier !== null) {
                prop.setTemporalAutoBezierAtKey(newKeyIndex, keyData.temporalAutoBezier);
            }
        } catch (setTemporalAutoBezierError) {}

        try {
            if (
                prop.isSpatial &&
                keyData.inSpatialTangent !== null &&
                keyData.outSpatialTangent !== null
            ) {
                prop.setSpatialTangentsAtKey(
                    newKeyIndex,
                    keyData.inSpatialTangent,
                    keyData.outSpatialTangent
                );
            }
        } catch (setSpatialTangentsError) {}

        try {
            if (prop.isSpatial && keyData.spatialContinuous !== null) {
                prop.setSpatialContinuousAtKey(newKeyIndex, keyData.spatialContinuous);
            }
        } catch (setSpatialContinuousError) {}

        try {
            if (prop.isSpatial && keyData.spatialAutoBezier !== null) {
                prop.setSpatialAutoBezierAtKey(newKeyIndex, keyData.spatialAutoBezier);
            }
        } catch (setSpatialAutoBezierError) {}

        try {
            if (prop.isSpatial && keyData.roving !== null) {
                prop.setRovingAtKey(newKeyIndex, keyData.roving);
            }
        } catch (setRovingError) {}
    }
})();
