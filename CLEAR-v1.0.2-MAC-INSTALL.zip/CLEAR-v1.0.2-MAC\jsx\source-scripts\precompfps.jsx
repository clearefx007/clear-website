// PrecomposeSelected_ReplaceOriginals_TrimOnly.jsx
// Precompose each selected layer directly (no duplicate).
// Move all attributes into the precomp, set precomp duration to trimmed length,
// shift inner layers by -segStart so the visible segment is inside the precomp,
// and set the precomp layer in the main comp to the original trimmed in/out.

(function () {
    app.beginUndoGroup("Precompose Selected Layers (replace originals, trim only)");

    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) {
        alert("Open a composition and select one or more layers.");
        return;
    }

    var sel = comp.selectedLayers;
    if (!sel || sel.length === 0) {
        alert("Select at least one layer in the timeline.");
        return;
    }

    function getCompIdMap() {
        var map = {};
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it instanceof CompItem) map[it.id] = it;
        }
        return map;
    }

    function uniqueName(base) {
        var name = base;
        var idx = 1;
        while (true) {
            var found = false;
            for (var i = 1; i <= app.project.numItems; i++) {
                if (app.project.item(i).name === name) { found = true; break; }
            }
            if (!found) return name;
            name = base + "_" + (idx++);
        }
    }

    var indices = [];
    for (var i = 0; i < sel.length; i++) indices.push(sel[i].index);
    indices.sort(function(a,b){return b - a;});

    var compsBefore = getCompIdMap();

    for (var ii = 0; ii < indices.length; ii++) {
        try {
            var idx = indices[ii];
            var layer = comp.layer(idx);
            if (!layer) continue;

            var segStart = layer.inPoint;
            var segEnd = layer.outPoint;
            var segDur = segEnd - segStart;
            if (segDur <= 0) continue;

            var baseName = (layer.name ? layer.name : "Precomp_layer") + "_pre";
            var newName = uniqueName(baseName);

            compsBefore = getCompIdMap();

            comp.layers.precompose([idx], newName, true);

            var compsAfter = getCompIdMap();
            var newComp = null;

            for (var id in compsAfter) {
                if (!compsBefore[id]) {
                    newComp = compsAfter[id];
                    if (newComp && newComp.name === newName) break;
                }
            }

            if (!newComp) {
                for (var p = 1; p <= app.project.numItems; p++) {
                    var it = app.project.item(p);
                    if (it instanceof CompItem && it.name === newName) { newComp = it; break; }
                }
            }

            if (!newComp) continue;

            // ✅ ADDED: match FPS to source layer
            try {
                if (layer.source && layer.source.frameRate)
                    newComp.frameRate = layer.source.frameRate;
            } catch (e) {}

            try {
                newComp.duration = segDur;
            } catch (e) {
                try { newComp.workAreaStart = 0; newComp.workAreaDuration = segDur; } catch (e2) {}
            }

            for (var li = 1; li <= newComp.numLayers; li++) {
                var inner = newComp.layer(li);

                var oldStart = 0;
                try { oldStart = inner.startTime; } catch (e) {}

                try {
                    inner.startTime = oldStart - segStart;
                } catch (err) {
                    try {
                        inner.inPoint -= segStart;
                        inner.outPoint -= segStart;
                    } catch (err2) {}
                }

                try {
                    var tm = inner.property("ADBE Time Remapping");
                    if (tm && tm.numKeys > 0) {
                        var keys = [];
                        for (var k = 1; k <= tm.numKeys; k++)
                            keys.push({t: tm.keyTime(k), v: tm.keyValue(k)});

                        for (var k2 = tm.numKeys; k2 >= 1; k2--) tm.removeKey(k2);

                        for (var k3 = 0; k3 < keys.length; k3++)
                            tm.setValueAtTime(keys[k3].t - segStart, keys[k3].v);
                    }
                } catch (e) {}
            }

            var precompLayer = null;
            for (var L = 1; L <= comp.numLayers; L++) {
                var Lyr = comp.layer(L);
                if (Lyr.source === newComp) { precompLayer = Lyr; break; }
            }

            if (precompLayer) {
                try {
                    precompLayer.startTime = segStart;
                    precompLayer.inPoint = segStart;
                    precompLayer.outPoint = segEnd;
                } catch (e) {}
            }

        } catch (ex) {
            $.writeln("Error processing layer index " + indices[ii] + ": " + ex.toString());
        }
    }

    app.endUndoGroup();
})();
