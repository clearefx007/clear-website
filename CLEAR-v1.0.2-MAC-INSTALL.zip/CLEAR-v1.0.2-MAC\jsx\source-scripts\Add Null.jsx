app.beginUndoGroup("Add Nulls to Selected");

var comp = app.project.activeItem;
if (comp && comp instanceof CompItem) {
    var selectedLayers = comp.selectedLayers;
    
    for (var i = 0; i < selectedLayers.length; i++) {
        var layer = selectedLayers[i];

        // Create a new Null
        var nul = comp.layers.addNull();
        nul.name = "Null " + (i+1);
        
        // Match timing
        nul.inPoint = layer.inPoint;
        nul.outPoint = layer.outPoint;

        // Move it just above the selected layer
        nul.moveBefore(layer);
    }
}

app.endUndoGroup();
