/*
Fit Selected Layers To Comp

Select one or more layers in an active composition, then run this script.
It scales each selected layer so it fits inside the composition while
preserving the layer's aspect ratio.
*/

(function fitSelectedLayersToComp() {
    app.beginUndoGroup("Fit Selected Layers To Comp");

    var comp = app.project.activeItem;

    if (!(comp instanceof CompItem)) {
        alert("Please select or open a composition first.");
        app.endUndoGroup();
        return;
    }

    var selectedLayers = comp.selectedLayers;

    if (selectedLayers.length === 0) {
        alert("Please select at least one layer.");
        app.endUndoGroup();
        return;
    }

    for (var i = 0; i < selectedLayers.length; i++) {
        var layer = selectedLayers[i];

        if (!layer.source || !layer.source.width || !layer.source.height) {
            continue;
        }

        var sourceWidth = layer.source.width;
        var sourceHeight = layer.source.height;

        var scaleX = (comp.width / sourceWidth) * 100;
        var scaleY = (comp.height / sourceHeight) * 100;

        // Use the smaller scale so the whole layer fits inside the comp.
        var fitScale = Math.min(scaleX, scaleY);

        layer.property("Scale").setValue([fitScale, fitScale]);
    }

    app.endUndoGroup();
})();