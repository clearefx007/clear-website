// Reverse the stacking order of selected layers (AE ExtendScript)
(function reverseSelectedLayerOrder(){
    var comp = app.project.activeItem;
    if (!(comp && comp instanceof CompItem)) { alert("Open a comp."); return; }

    var sel = comp.selectedLayers;
    if (!sel || sel.length < 2) { alert("Select at least two layers."); return; }

    app.beginUndoGroup("Reverse Selected Layer Order");

    // Sort by index so sel[0] is the topmost selected layer
    sel.sort(function(a,b){ return a.index - b.index; });

    // Keep the original topmost selected layer as the fixed anchor.
    var anchor = sel[0];

    // Move others, from bottom to top, BEFORE the anchor.
    // This yields the exact reversed order and never moves a layer before itself.
    for (var i = sel.length - 1; i >= 1; i--) {
        sel[i].moveBefore(anchor);
    }

    app.endUndoGroup();
})();
