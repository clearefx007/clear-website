{
    app.beginUndoGroup("Instant Frame PNG Export");

    var comp = app.project.activeItem;

    if (!(comp instanceof CompItem)) {
        alert("Please select a composition.");
    } else {

        // Set fixed folder
        var outputFolder = new Folder("A:/png");

        if (!outputFolder.exists) {
            outputFolder.create();
        }

        // Get project name (without extension)
        var projectName = app.project.file 
            ? app.project.file.name.replace(/\.[^\.]+$/, "") 
            : "Untitled_Project";

        // Auto increment file name
        var num = 1;
        var outputFile;

        while (true) {
            outputFile = new File(outputFolder.fsName + "/" + projectName + "_png" + num + ".png");
            if (!outputFile.exists) break;
            num++;
        }

        // Save current frame instantly
        comp.saveFrameToPng(comp.time, outputFile);

    }

    app.endUndoGroup();
}