// Delete all effects from the selected layer
(function () {
    app.beginUndoGroup("Delete All Effects");

    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) {
        alert("No active composition.");
        return;
    }

    // Check if at least one layer is selected
    if (comp.selectedLayers.length === 0) {
        alert("Select at least one layer.");
        return;
    }

    // Loop through all selected layers
    for (var i = 0; i < comp.selectedLayers.length; i++) {
        var layer = comp.selectedLayers[i];

        // Check if Effects property exists
        var effects = layer.property("ADBE Effect Parade");
        if (effects && effects.numProperties > 0) {

            // Remove effects one by one (reverse order to avoid index shift)
            for (var e = effects.numProperties; e >= 1; e--) {
                effects.property(e).remove();
            }
        }
    }

    app.endUndoGroup();
})();
