CLEAR After Effects Plugin
Version: 1.0.2

Compatibility:
Adobe After Effects 2020 through 2026.

This single EXE installer includes the full CLEAR panel, all SVG icons, JSX tools, Quick Search, J/K Marker Navigation, and Fast Color Picker.

HOW TO INSTALL

1. Close Adobe After Effects.
2. Run:

   CLEAR-Installer-v1.0.2.exe

3. Click:

   Install CLEAR

4. Open Adobe After Effects.
5. Go to:

   Window > Extensions > CLEAR

6. Dock the CLEAR panel wherever you want.


BUG FIXES IN v1.0.2

- Fixed Fast Color Picker missing error on other PCs.
- Fast Color Picker now loads from the installed CLEAR extension folder.
- Quick Search helper is included inside the installer.
- J/K Marker Navigation helper is included inside the installer.
- Updated installer package to include all native helper EXEs.
- Fixed installed package paths so tools do not depend on D:\clear\bin.
- Added Update button linking to the CLEAR website.
- Updated Discord support link.
- Preserves existing favorites, timer data, Quick Colors, and settings during update.


PLUGIN FEATURES

Layer Tools:
- Precompose
- Precompose Individual
- Decompose
- Add Adjustment Layer
- Add Null
- Fit Layer Into Comp
- Top To Bottom
- Link To Parent
- Rotate CW

Effects:
- Paste Effects
- Delete All Effects
- Delete Particular Effect
- Color Audio
- Fade In Out

Text Tools:
- Sentence Case
- Lower Case
- Upper Case
- Split Text

Shape & Design:
- Round Corner
- Fast Color Picker
- Anchor Point Grid
- Align Toolbar
- Dual Center Align
- Quick Colors

Composition:
- Camera
- 3D Toggle
- PNG Render

Workflow Features:
- Quick Search
- J/K Marker Navigation
- Project Session Timer
- Total Project Time Tracking
- Accent Color Setting
- Category View ON/OFF
- Remove and Restore Tools
- Feedback links for Telegram, Instagram, and Discord
- Support page


UPDATE SAFETY

- Existing Quick Search favorite effects are preserved.
- Existing timer data and project time data are preserved.
- Existing Quick Colors/settings are preserved.
- The installer replaces only the CLEAR extension files.


VERSION

CLEAR v1.0.2


SUPPORT

Telegram:
@clearfx007

Instagram:
https://www.instagram.com/clear7.fx/

Discord:
https://discord.gg/WDeZWH8Ees
