CLEAR After Effects Plugin
Version: 1.0.9

Compatibility:
Adobe After Effects 2020 through 2026.

This single EXE installer includes the full CLEAR panel, all SVG icons, JSX tools, Quick Search, J/K Marker Navigation, and Fast Color Picker.

HOW TO INSTALL

1. Close Adobe After Effects.
2. Run:

   CLEAR-Installer-v1.0.9.exe

3. Click:

   Install CLEAR

4. Open Adobe After Effects.
5. Go to:

   Window > Extensions > CLEAR

6. Dock the CLEAR panel wherever you want.


NEW IN v1.0.9



- Arrange Clips places selected clips on composition markers from the playhead.
- Fit To Layer Below matches selected layer timing and playback to the layer directly below.
- Swap Clips exchanges two selected footage or precomp clips while retaining their timeline slots.

OTHER FEATURES

- Quick Replace tool for replacing selected layer footage from a file picker.
- Custom Audio Color setting for choosing the Color Audio layer label color.
- True Duplicate for independent layer, precomp, nested-precomp, and solid copies.
- Quick Import PNG option for rendering and importing a PNG back into the comp.
- Selected Text Color support for Quick Colors and Fast Color Picker.
- Text layers stay selected after selected-text coloring, without forcing text properties open.
- Temporary text animators are removed after selected-text coloring.


PLUGIN FEATURES

Layer Tools:
- Precompose
- Precompose Individual
- Decompose
- True Duplicate
- Add Adjustment Layer
- Add Null
- Fit Layer Into Comp
- Top To Bottom
- Arrange Clips
- Fit To Layer Below
- Swap Clips
- Link To Parent
- Rotate CW

Effects:
- Paste Effects
- Delete All Effects
- Delete Particular Effect
- Color Audio
- Custom Audio Color setting
- Fade In Out

Text Tools:
- Sentence Case
- Lower Case
- Upper Case
- Split Text

Shape & Design:
- Round Corner
- Fast Color Picker
- Selected Text Color support
- Anchor Point Grid
- Align Toolbar
- Dual Center Align
- Quick Colors

Composition:
- Camera
- 3D Toggle
- Quick Replace
- PNG Render
- Quick Import PNG option

Workflow Features:
- Quick Search
- J/K Marker Navigation
- Project Session Timer
- Total Project Time Tracking
- Accent Color Setting
- Category View ON/OFF
- Remove and Restore Tools
- Feedback links for Telegram, Instagram, and Discord
- Support page


UPDATE SAFETY

- Existing Quick Search favorite effects are preserved.
- Existing timer data and project time data are preserved.
- Existing Quick Colors/settings are preserved.
- The installer replaces only the CLEAR extension files.


VERSION

CLEAR v1.0.9


SUPPORT

Telegram:
@clearfx007

Instagram:
https://www.instagram.com/clear.fx7/

Discord:
https://discord.gg/WDeZWH8Ees
